//
// C++ Implementation: OCS
//
// Description:
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "OCS.h"

OCS::OCS ( QWidget *parent ) :QWidget ( parent )
{
	setupUi(this);
	tcp_socket = new QTcpSocket ( this );
	timer = new QTimer;
	connect( tcp_socket,SIGNAL(connected()),this,SLOT(showConnected()));
	connect( tcp_socket,SIGNAL(disconnected()),this,SLOT(showDisconnected()));
	connect ( tcp_socket, SIGNAL ( readyRead() ), this, SLOT ( readData() ) );
	connect ( tcp_socket, SIGNAL ( error ( QAbstractSocket::SocketError ) ),this, SLOT ( showError ( QAbstractSocket::SocketError ) ) );

}

OCS::~OCS()
{
	delete tcp_socket;
}

int OCS::isPackageBroken(QDataStream& in)
{
	quint16 block_size;
	if ( tcp_socket->bytesAvailable() < ( int ) sizeof ( quint16 ) )//You must make sure that enough data is available before attempting to read it using operator>>().
			return 1;
	in >> block_size;
	if ( tcp_socket->bytesAvailable() < block_size )
		return 1;//some error happen here.
	return 0;
}

void OCS::showConnected()
{
	label_status->setText("Net Connected.");
	pushButton_check_az->setEnabled(true);
	pushButton_start_az->setEnabled(true);
	pushButton_stop_az->setEnabled(true);
	pushButton_check_alt->setEnabled(true);
	pushButton_start_alt->setEnabled(true);
	pushButton_stop_alt->setEnabled(true);
	pushButton_check_dero->setEnabled(true);
	pushButton_start_dero->setEnabled(true);
	pushButton_stop_dero->setEnabled(true);
	pushButton_start_track->setEnabled(true);
	pushButton_stop_track->setEnabled(true);
	pushButton_connect->setEnabled(false);
}

void OCS::showDisconnected()
{
	label_status->setText("Net Disconnected.");
	pushButton_check_az->setEnabled(false);
	pushButton_start_az->setEnabled(false);
	pushButton_stop_az->setEnabled(false);
	pushButton_check_alt->setEnabled(false);
	pushButton_start_alt->setEnabled(false);
	pushButton_stop_alt->setEnabled(false);
	pushButton_check_dero->setEnabled(false);
	pushButton_start_dero->setEnabled(false);
	pushButton_stop_dero->setEnabled(false);
	pushButton_start_track->setEnabled(false);
	pushButton_stop_track->setEnabled(false);
	pushButton_connect->setEnabled(true);
}

void OCS::readData()
{
	static int i = 0;
//	QByteArray data = tcp_socket->readAll();//if you want to read all datas one time,use like this.But meantime,you can not use  isPackageBroken to check.
//	QDataStream in ( data/*,QIODevice::ReadOnly */);//decoder...
	QDataStream in ( tcp_socket/*,QIODevice::ReadOnly */);
	in.setVersion ( QDataStream::Qt_4_0 );
//	qDebug("fgfgg");
	if(isPackageBroken(in))
	{
		throw QString("Package Broken.");
	}
	QString str;
	in >> str;
	tableWidget->setItem ( i,0, new QTableWidgetItem ( str) );
	i++;
//	lineEdit_rece->setText ( str/*+"  "+QString::number(i++)*/ );
}

void OCS::on_pushButton_connect_clicked()
{
//	blockSize = 0;
//	tcp_socket->abort();
	tcp_socket->connectToHost ( lineEdit_server->text(),
	                           lineEdit_port->text().toInt() );//by default Read
//	timer->start(0.01);
}

void OCS::on_pushButton_ocs_selfcheck_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::ReadWrite);//encoder....
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",OCS_SELFCHECK);//ocs selfcheck
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
	
}

void OCS::on_pushButton_check_az_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::ReadWrite);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",CHECK_AZ);//check az
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_start_az_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",START_AZ);//start az
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_stop_az_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",STOP_AZ);//start az
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_check_alt_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",CHECK_ALT);//check alt
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_start_alt_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",START_ALT);//start alt
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_stop_alt_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",STOP_ALT);//start alt
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_check_dero_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",CHECK_DERO);//check dero
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_start_dero_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",START_DERO);//start dero
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_stop_dero_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",STOP_DERO);//start dero
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_check_status_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",TCS_STATUS);//
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_start_track_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",START_TRACK);//start track
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::on_pushButton_stop_track_clicked()
{
	QByteArray cmdSend;
	QHash<QString,QString> hash;
	QDataStream out(&cmdSend,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	hash.insert("CMD",STOP_TRACK);//stop track
	out << hash;
	out.device()->seek(0);
	out << ( quint16 ) ( cmdSend.size() - sizeof ( quint16 ) );
	tcp_socket->write(cmdSend);
}

void OCS::showError ( QAbstractSocket::SocketError socketError )
{
	switch ( socketError )
	{
		case QAbstractSocket::RemoteHostClosedError:
			break;
		case QAbstractSocket::HostNotFoundError:
			QMessageBox::information ( this, tr ( "Fortune Client" ),
			                           tr ( "The host was not found. Please check the "
			                                "host name and port settings." ) );
			break;
		case QAbstractSocket::ConnectionRefusedError:
			QMessageBox::information ( this, tr ( "Fortune Client" ),
			                           tr ( "The connection was refused by the peer. "
			                                "Make sure the fortune server is running, "
			                                "and check that the host name and port "
			                                "settings are correct." ) );
			break;
		default:
			QMessageBox::information ( this, tr ( "Fortune Client" ),
			                           tr ( "The following error occurred: %1." )
			                           .arg ( tcp_socket->errorString() ) );
	}

}
