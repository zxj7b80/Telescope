//
// C++ Interface: OCS
//
// Description: 
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef OCS_H
#define OCS_H
#include "ui_OCS.h"
#include <QtGui>
#include <QtNetwork>

#define OCS_SELFCHECK       "2.0.0.1.1"

#define CHECK_AZ            "2.1.0.1.1"
#define START_AZ           "2.1.0.2.1"
#define STOP_AZ            "2.1.0.3.1"
#define CHECK_ALT           "2.2.0.1.1"
#define START_ALT           "2.2.0.2.1"
#define STOP_ALT            "2.2.0.3.1"
#define CHECK_DERO           "2.3.0.1.1"
#define START_DERO           "2.3.0.2.1"
#define STOP_DERO            "2.3.0.3.1"
#define START_TRACK          "2.4.0.1.1"
#define STOP_TRACK            "2.4.0.2.1"
#define TCS_STATUS            "2.5.0.1.1"

class OCS:public QWidget,private Ui::OCS
{
	Q_OBJECT
	public:
		OCS( QWidget *parent=0);
		~OCS();
	private:
		QTcpSocket *tcp_socket;
		QTimer *timer;
		int isPackageBroken(QDataStream&);
	private slots:
		void showConnected();
		void showDisconnected();
		void on_pushButton_connect_clicked();
		void on_pushButton_ocs_selfcheck_clicked();

		void on_pushButton_check_az_clicked();
		void on_pushButton_start_az_clicked();
		void on_pushButton_stop_az_clicked();

		void on_pushButton_check_alt_clicked();
		void on_pushButton_start_alt_clicked();
		void on_pushButton_stop_alt_clicked();

		void on_pushButton_check_dero_clicked();
		void on_pushButton_start_dero_clicked();
		void on_pushButton_stop_dero_clicked();

		void on_pushButton_start_track_clicked();
		void on_pushButton_stop_track_clicked();

		void on_pushButton_check_status_clicked();

		void readData();
		void showError(QAbstractSocket::SocketError socketError);
};
#endif