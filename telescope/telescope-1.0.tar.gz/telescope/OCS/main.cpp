//
// C++ Implementation: main
//
// Description: 
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "OCS.h"
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	OCS *ocs = new OCS();
	ocs->show();
	return app.exec();
}