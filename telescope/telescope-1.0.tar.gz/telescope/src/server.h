//
// C++ Interface: server
//
// Description:
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef SERVER_H
#define SERVER_H
#include <QtGui>
#include <QtNetwork>

class MainWindow;
class Server:public QTcpServer
{
		Q_OBJECT
	public:
		Server ( MainWindow *parent );
		virtual ~Server();
		void writeData(QString data);
	protected:
		void incomingConnection ( int socket_descriptor );
	private:
		MainWindow *m_parent;
		QTcpSocket *tcp_socket;
		int isPackageBroken(QDataStream&);
	private slots:
		void readData();
		
		void showError(QAbstractSocket::SocketError socketError);
};

class ServerThread:public QThread
{
		Q_OBJECT
	public:
		ServerThread ( int socketDescriptor );
		virtual ~ServerThread();
	protected:
		virtual void run();
	private:
		int socket_fd;
};

#endif
