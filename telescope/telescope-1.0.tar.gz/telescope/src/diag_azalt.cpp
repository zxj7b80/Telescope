//
// C++ Implementation: diag_azalt
//
// Description: 
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "diag_azalt.h"
#include "signs.h"

DiagAzalt::DiagAzalt ( MainWindow *parent )
{
	m_parent = parent;
	timer=new QTimer;
	setupUi ( this );
	connect(timer,SIGNAL(timeout()),this,SLOT(updateInterface()));
	timer->start(500);
//	connectDevice();
//	initUi();
}

DiagAzalt::~DiagAzalt()
{
	qDebug ( "diag azalt" );
	timer->deleteLater();
	deleteLater();
}

void DiagAzalt::closeEvent ( QCloseEvent *event )
{
	parentWidget()->hide();
	event->ignore();
}

void DiagAzalt::updateInterface()
{
	
}