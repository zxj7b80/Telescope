/***************************************************************************
 *   Copyright (C) 2009 by donglongchao   *
 *   donglongchao@163.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#ifndef MAIN_WINDOW_H
#define MAIN_WINDOW_H

#include <QtGui>
#include "ui_telescope.h"
#include <memory>//for auto_ptr,not used yet by now.
#include "direct_azalt.h"
class UMAC;
class DirectAzalt;
class DirectM3;
class DirectM2;
class Tracking;
class DiagM2;
class DiagAzalt;
class Terminal;
class Server;

class MainWindow:public QMainWindow,private Ui::MainWindow
{
		Q_OBJECT
	public:
		MainWindow ( QWidget *parent=0 );
		virtual ~MainWindow();
//		ServiceThread *service;
		DirectAzalt *direct_azalt;
//		std::auto_ptr<DirectAzalt> direct_azalt;//don't mix smart_ptr and qt's memory manage.
		DirectM3 *direct_m3;
		DirectM2 *direct_m2;
		Tracking *tracking;
		DiagM2 *diag_m2;
		DiagAzalt *diag_azalt;
		Terminal *terminal;

		Server *server;
		QTimer *timer;

		QStandardItemModel *model_ocs;
		QStandardItemModel *model_tcs;
		
		QString cmd;
		void updateInterface(QHash<QString,QString>);
		void showInfoOCS(QHash<QString,QString>);
	protected:
		virtual void closeEvent ( QCloseEvent *event );
	public slots:
//	private:
//	private slots:

		void startDirectAzalt(QString str="");
		void startDirectM3();
		void startDirectM2();
		void startTracking(QString str="");
		void startDiagM2();
		void startDiagAzalt();
		void startTerminal();

		void on_actionWindows_triggered();
		void on_actionMotif_triggered();
		void on_actionGtk_triggered();
		void on_actionCDE_triggered();
	signals:
		void startDirectAzaltOCS();
		void startTrackingOCS();
};

class MyApplication: public QApplication
{
		Q_OBJECT
	public:
		MyApplication ( int argc, char *argv[] ) : QApplication ( argc, argv ) {}
		bool notify ( QObject *receiver, QEvent *event )
		{
			try
			{
				return QApplication::notify ( receiver, event );
			}
			catch ( QString excepts )
			{
				QMessageBox mb ( QMessageBox::Warning,
				                 tr ( "About to close!!!" ),
				                 tr ( ( excepts+"\n PLease close close this subwindow and check your connection and open this subwindow again." ).toAscii() ),
//						 tr ( "About to close" ),
				                 QMessageBox::Ok );
// 				QString s_temp = "<RelatedCmdCUID=";
// 				s_temp.append(START_ALT);
// 				s_temp.append ( "><StatusCUID=" );
// 				s_temp.append ( s_datetime );
// 				s_temp.append ( "><ExeStatus=DONE><bExeStatus=true>" );
// 				server->writeData(s_temp);
				if ( mb.exec() ==QMessageBox::Ok )
				{
					return false;
				}
			}
			catch ( ... )
			{
				QMessageBox mb ( QMessageBox::Critical,
				                 tr ( "About to close!!!  " ),
				                 tr ( "Unknown excepts occurs.\n The app will quit now." ),
//						 tr ( "About to close" ),
				                 QMessageBox::Ok );
				if ( mb.exec() ==QMessageBox::Ok )
				{
					quit();
				}
			}
		}
};
#endif
