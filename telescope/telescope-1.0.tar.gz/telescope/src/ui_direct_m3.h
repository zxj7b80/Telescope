/********************************************************************************
** Form generated from reading ui file 'direct_m3.ui'
**
** Created: Fri Feb 26 15:05:28 2010
**      by: Qt User Interface Compiler version 4.5.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_DIRECT_M3_H
#define UI_DIRECT_M3_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QScrollArea>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DirectM3
{
public:
    QWidget *scrollAreaWidgetContents;
    QGroupBox *groupBox_16;
    QLineEdit *lineEdit_ro_targetD;
    QLabel *label_9;
    QLineEdit *lineEdit_ro_targetS;
    QLineEdit *lineEdit_ro_targetM;
    QLabel *label_10;
    QLabel *label_14;
    QLabel *label_12;
    QPushButton *pushButton_ro_go;
    QLabel *label_21;
    QGroupBox *groupBox_13;
    QWidget *layoutWidget_9;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_16;
    QPushButton *pushButton_ro_warning;
    QSpacerItem *verticalSpacer_4;
    QPushButton *pushButton_ro_reset;
    QWidget *layoutWidget_4;
    QGridLayout *gridLayout_12;
    QLabel *label_ro_homed;
    QLabel *label_41;
    QLabel *label_ro_soft_limitP;
    QLabel *label_42;
    QLabel *label_ro_brake;
    QLabel *label_44;
    QLabel *label_ro_soft_limitM;
    QLabel *label_45;
    QLabel *label_ro_vel_limit;
    QLabel *label_47;
    QLabel *label_ro_hard_limitP;
    QLabel *label_49;
    QLabel *label_ro_acc_limit;
    QLabel *label_52;
    QLabel *label_ro_hard_limitM;
    QLabel *label_53;
    QLabel *label_ro_ampli1_fault;
    QLabel *label_54;
    QLabel *label_ro_ampli2_fault;
    QLabel *label_55;
    QGroupBox *groupBox_15;
    QWidget *layoutWidget;
    QGridLayout *gridLayout_7;
    QRadioButton *radioButton_ro_acc_default;
    QLabel *label_43;
    QRadioButton *radioButton_ro_acc_spec;
    QLineEdit *lineEdit_ro_acc_spec;
    QGroupBox *groupBox_17;
    QWidget *layoutWidget_13;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_ro_dirM;
    QPushButton *pushButton_ro_dirP;
    QGroupBox *groupBox_20;
    QWidget *layoutWidget_17;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_es_dirM;
    QPushButton *pushButton_es_dirP;
    QPushButton *pushButton_es_stop;
    QGroupBox *groupBox_14;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_6;
    QRadioButton *radioButton_ro_vel_fast;
    QRadioButton *radioButton_ro_vel_mid;
    QRadioButton *radioButton_ro_vel_slow;
    QRadioButton *radioButton_ro_vel_spec;
    QLineEdit *lineEdit_ro_vel_spec;
    QLabel *label_11;
    QGroupBox *groupBox_18;
    QWidget *layoutWidget_14;
    QGridLayout *gridLayout_16;
    QRadioButton *radioButton_ro_step1;
    QPushButton *pushButton_ro_stepM;
    QRadioButton *radioButton_ro_step01;
    QPushButton *pushButton_ro_stepP;
    QRadioButton *radioButton_ro_step001;
    QRadioButton *radioButton_ro_step_spec;
    QLineEdit *lineEdit_ro_step_spec;
    QPushButton *pushButton_ro_stop;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_ro_axis;
    QPushButton *pushButton_ro_home;
    QPushButton *pushButton_ro_park;
    QGroupBox *groupBox;
    QLabel *label;
    QWidget *layoutWidget3;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *pushButton_ro_F2;
    QLabel *label_4;
    QPushButton *pushButton_ro_F3;
    QLabel *label_5;
    QPushButton *pushButton_ro_F4;
    QPushButton *pushButton_ro_F1;
    QGroupBox *groupBox_2;
    QLabel *label_6;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout_2;
    QLabel *label_7;
    QPushButton *pushButton_11;
    QLabel *label_8;
    QPushButton *pushButton_12;
    QGroupBox *groupBox_22;
    QWidget *layoutWidget_19;
    QGridLayout *gridLayout_19;
    QRadioButton *radioButton_es_step1;
    QPushButton *pushButton_es_stepM;
    QRadioButton *radioButton_es_step01;
    QPushButton *pushButton_es_stepP;
    QRadioButton *radioButton_es_step001;
    QRadioButton *radioButton_es_step_spec;
    QLineEdit *lineEdit_es_step_spec;
    QGroupBox *groupBox_21;
    QWidget *layoutWidget5;
    QGridLayout *gridLayout_8;
    QRadioButton *radioButton_es_vel_fast;
    QRadioButton *radioButton_es_vel_mid;
    QRadioButton *radioButton_es_vel_slow;
    QRadioButton *radioButton_es_vel_spec;
    QLineEdit *lineEdit_es_vel_spec;
    QGroupBox *groupBox_19;
    QWidget *layoutWidget_16;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_17;
    QPushButton *pushButton_es_warning;
    QSpacerItem *verticalSpacer_5;
    QPushButton *pushButton_es_reset;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_es_axis;
    QPushButton *pushButton_es_home;
    QPushButton *pushButton_es_park;
    QGroupBox *groupBox_24;
    QWidget *layoutWidget6;
    QGridLayout *gridLayout_9;
    QRadioButton *radioButton_es_acc_default;
    QLabel *label_46;
    QRadioButton *radioButton_es_acc_spec;
    QLineEdit *lineEdit_es_acc_spec;
    QGroupBox *groupBox_23;
    QWidget *layoutWidget7;
    QVBoxLayout *verticalLayout;
    QLabel *label_13;
    QHBoxLayout *horizontalLayout_24;
    QLineEdit *lineEdit_es_target;
    QLabel *label_50;
    QPushButton *pushButton_es_go;
    QGroupBox *groupBox_25;
    QWidget *layoutWidget8;
    QGridLayout *gridLayout_10;
    QRadioButton *radioButton_tr_vel_fast;
    QRadioButton *radioButton_tr_vel_mid;
    QRadioButton *radioButton_tr_vel_slow;
    QRadioButton *radioButton_tr_vel_spec;
    QLineEdit *lineEdit_tr_vel_spec;
    QGroupBox *groupBox_26;
    QWidget *layoutWidget_25;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *pushButton_tr_dirM;
    QPushButton *pushButton_tr_dirP;
    QGroupBox *groupBox_27;
    QWidget *layoutWidget9;
    QVBoxLayout *verticalLayout_2;
    QLabel *label_29;
    QHBoxLayout *horizontalLayout_25;
    QLineEdit *lineEdit_tr_target;
    QLabel *label_51;
    QPushButton *pushButton_tr_go;
    QGroupBox *groupBox_28;
    QWidget *layoutWidget_28;
    QGridLayout *gridLayout_25;
    QRadioButton *radioButton_tr_step1;
    QPushButton *pushButton_tr_stepM;
    QRadioButton *radioButton_tr_step01;
    QPushButton *pushButton_tr_stepP;
    QRadioButton *radioButton_tr_step001;
    QRadioButton *radioButton_tr_step_spec;
    QLineEdit *lineEdit_tr_step_spec;
    QPushButton *pushButton_tr_stop;
    QLabel *label_30;
    QGroupBox *groupBox_29;
    QWidget *layoutWidget_30;
    QVBoxLayout *verticalLayout_10;
    QLabel *label_31;
    QPushButton *pushButton_tr_warning;
    QSpacerItem *verticalSpacer_6;
    QPushButton *pushButton_tr_reset;
    QGroupBox *groupBox_30;
    QWidget *layoutWidget10;
    QGridLayout *gridLayout_11;
    QRadioButton *radioButton_tr_acc_default;
    QLabel *label_48;
    QRadioButton *radioButton_tr_acc_spec;
    QLineEdit *lineEdit_tr_acc_spec;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_tr_axis;
    QPushButton *pushButton_tr_home;
    QPushButton *pushButton_tr_park;
    QWidget *layoutWidget11;
    QGridLayout *gridLayout_3;
    QLabel *label_22;
    QHBoxLayout *horizontalLayout_16;
    QLineEdit *lineEdit_ro_posD;
    QLabel *label_38;
    QHBoxLayout *horizontalLayout_14;
    QLineEdit *lineEdit_pos_posM;
    QLabel *label_33;
    QHBoxLayout *horizontalLayout_15;
    QLineEdit *lineEdit_ro_posS;
    QLabel *label_32;
    QLabel *label_23;
    QHBoxLayout *horizontalLayout_13;
    QLineEdit *lineEdit_ro_vel;
    QLabel *label_37;
    QLabel *label_24;
    QHBoxLayout *horizontalLayout_12;
    QLineEdit *lineEdit_ro_poserr;
    QLabel *label_36;
    QSpacerItem *horizontalSpacer_4;
    QWidget *layoutWidget12;
    QGridLayout *gridLayout_4;
    QLabel *label_18;
    QHBoxLayout *horizontalLayout_7;
    QLineEdit *lineEdit_es_pos;
    QLabel *label_15;
    QLabel *label_19;
    QHBoxLayout *horizontalLayout_9;
    QLineEdit *lineEdit_es_vel;
    QLabel *label_34;
    QLabel *label_20;
    QHBoxLayout *horizontalLayout_8;
    QLineEdit *lineEdit_es_poserr;
    QLabel *label_25;
    QSpacerItem *horizontalSpacer_3;
    QWidget *layoutWidget13;
    QGridLayout *gridLayout_5;
    QLabel *label_26;
    QHBoxLayout *horizontalLayout_11;
    QLineEdit *lineEdit_tr_pos;
    QLabel *label_39;
    QLabel *label_27;
    QHBoxLayout *horizontalLayout_17;
    QLineEdit *lineEdit_tr_vel;
    QLabel *label_40;
    QLabel *label_28;
    QHBoxLayout *horizontalLayout_10;
    QLineEdit *lineEdit_tr_poserr;
    QLabel *label_35;
    QSpacerItem *horizontalSpacer_5;
    QWidget *layoutWidget_5;
    QGridLayout *gridLayout_13;
    QLabel *label_es_homed;
    QLabel *label_56;
    QLabel *label_es_soft_limitP;
    QLabel *label_57;
    QLabel *label_es_brake;
    QLabel *label_58;
    QLabel *label_es_soft_limitM;
    QLabel *label_59;
    QLabel *label_es_vel_limit;
    QLabel *label_60;
    QLabel *label_es_hard_limitP;
    QLabel *label_61;
    QLabel *label_es_acc_limit;
    QLabel *label_62;
    QLabel *label_es_hard_limitM;
    QLabel *label_63;
    QLabel *label_es_ampli1_fault;
    QLabel *label_64;
    QLabel *label_es_ampli2_fault;
    QLabel *label_65;
    QWidget *layoutWidget_6;
    QGridLayout *gridLayout_14;
    QLabel *label_tr_homed;
    QLabel *label_66;
    QLabel *label_tr_soft_limitP;
    QLabel *label_67;
    QLabel *label_tr_brake;
    QLabel *label_68;
    QLabel *label_tr_soft_limitM;
    QLabel *label_69;
    QLabel *label_tr_vel_limit;
    QLabel *label_70;
    QLabel *label_tr_hard_limitP;
    QLabel *label_71;
    QLabel *label_tr_acc_limit;
    QLabel *label_72;
    QLabel *label_tr_hard_limitM;
    QLabel *label_73;
    QLabel *label_tr_ampli1_fault;
    QLabel *label_74;

    void setupUi(QScrollArea *DirectM3)
    {
        if (DirectM3->objectName().isEmpty())
            DirectM3->setObjectName(QString::fromUtf8("DirectM3"));
        DirectM3->resize(1234, 750);
        DirectM3->setFrameShape(QFrame::WinPanel);
        DirectM3->setFrameShadow(QFrame::Sunken);
        DirectM3->setWidgetResizable(false);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1230, 730));
        groupBox_16 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_16->setObjectName(QString::fromUtf8("groupBox_16"));
        groupBox_16->setGeometry(QRect(210, 420, 181, 111));
        lineEdit_ro_targetD = new QLineEdit(groupBox_16);
        lineEdit_ro_targetD->setObjectName(QString::fromUtf8("lineEdit_ro_targetD"));
        lineEdit_ro_targetD->setGeometry(QRect(20, 50, 41, 25));
        label_9 = new QLabel(groupBox_16);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(160, 50, 20, 20));
        lineEdit_ro_targetS = new QLineEdit(groupBox_16);
        lineEdit_ro_targetS->setObjectName(QString::fromUtf8("lineEdit_ro_targetS"));
        lineEdit_ro_targetS->setGeometry(QRect(120, 50, 41, 25));
        lineEdit_ro_targetM = new QLineEdit(groupBox_16);
        lineEdit_ro_targetM->setObjectName(QString::fromUtf8("lineEdit_ro_targetM"));
        lineEdit_ro_targetM->setGeometry(QRect(70, 50, 41, 25));
        label_10 = new QLabel(groupBox_16);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(60, 50, 16, 20));
        label_14 = new QLabel(groupBox_16);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(50, 31, 72, 16));
        label_14->setAlignment(Qt::AlignCenter);
        label_12 = new QLabel(groupBox_16);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(110, 50, 16, 16));
        pushButton_ro_go = new QPushButton(groupBox_16);
        pushButton_ro_go->setObjectName(QString::fromUtf8("pushButton_ro_go"));
        pushButton_ro_go->setGeometry(QRect(53, 79, 81, 24));
        label_21 = new QLabel(scrollAreaWidgetContents);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(564, 0, 121, 31));
        label_21->setTextFormat(Qt::RichText);
        groupBox_13 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_13->setObjectName(QString::fromUtf8("groupBox_13"));
        groupBox_13->setGeometry(QRect(30, 130, 361, 161));
        layoutWidget_9 = new QWidget(groupBox_13);
        layoutWidget_9->setObjectName(QString::fromUtf8("layoutWidget_9"));
        layoutWidget_9->setGeometry(QRect(259, 32, 64, 105));
        verticalLayout_5 = new QVBoxLayout(layoutWidget_9);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_16 = new QLabel(layoutWidget_9);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        verticalLayout_5->addWidget(label_16);

        pushButton_ro_warning = new QPushButton(layoutWidget_9);
        pushButton_ro_warning->setObjectName(QString::fromUtf8("pushButton_ro_warning"));
        pushButton_ro_warning->setEnabled(false);

        verticalLayout_5->addWidget(pushButton_ro_warning);

        verticalSpacer_4 = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_4);

        pushButton_ro_reset = new QPushButton(layoutWidget_9);
        pushButton_ro_reset->setObjectName(QString::fromUtf8("pushButton_ro_reset"));

        verticalLayout_5->addWidget(pushButton_ro_reset);

        layoutWidget_4 = new QWidget(groupBox_13);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(10, 30, 231, 131));
        gridLayout_12 = new QGridLayout(layoutWidget_4);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        gridLayout_12->setContentsMargins(0, 0, 0, 0);
        label_ro_homed = new QLabel(layoutWidget_4);
        label_ro_homed->setObjectName(QString::fromUtf8("label_ro_homed"));

        gridLayout_12->addWidget(label_ro_homed, 0, 0, 1, 1);

        label_41 = new QLabel(layoutWidget_4);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        gridLayout_12->addWidget(label_41, 0, 1, 1, 1);

        label_ro_soft_limitP = new QLabel(layoutWidget_4);
        label_ro_soft_limitP->setObjectName(QString::fromUtf8("label_ro_soft_limitP"));

        gridLayout_12->addWidget(label_ro_soft_limitP, 0, 2, 1, 1);

        label_42 = new QLabel(layoutWidget_4);
        label_42->setObjectName(QString::fromUtf8("label_42"));

        gridLayout_12->addWidget(label_42, 0, 3, 1, 1);

        label_ro_brake = new QLabel(layoutWidget_4);
        label_ro_brake->setObjectName(QString::fromUtf8("label_ro_brake"));

        gridLayout_12->addWidget(label_ro_brake, 1, 0, 1, 1);

        label_44 = new QLabel(layoutWidget_4);
        label_44->setObjectName(QString::fromUtf8("label_44"));

        gridLayout_12->addWidget(label_44, 1, 1, 1, 1);

        label_ro_soft_limitM = new QLabel(layoutWidget_4);
        label_ro_soft_limitM->setObjectName(QString::fromUtf8("label_ro_soft_limitM"));

        gridLayout_12->addWidget(label_ro_soft_limitM, 1, 2, 1, 1);

        label_45 = new QLabel(layoutWidget_4);
        label_45->setObjectName(QString::fromUtf8("label_45"));

        gridLayout_12->addWidget(label_45, 1, 3, 1, 1);

        label_ro_vel_limit = new QLabel(layoutWidget_4);
        label_ro_vel_limit->setObjectName(QString::fromUtf8("label_ro_vel_limit"));

        gridLayout_12->addWidget(label_ro_vel_limit, 2, 0, 1, 1);

        label_47 = new QLabel(layoutWidget_4);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        gridLayout_12->addWidget(label_47, 2, 1, 1, 1);

        label_ro_hard_limitP = new QLabel(layoutWidget_4);
        label_ro_hard_limitP->setObjectName(QString::fromUtf8("label_ro_hard_limitP"));

        gridLayout_12->addWidget(label_ro_hard_limitP, 2, 2, 1, 1);

        label_49 = new QLabel(layoutWidget_4);
        label_49->setObjectName(QString::fromUtf8("label_49"));

        gridLayout_12->addWidget(label_49, 2, 3, 1, 1);

        label_ro_acc_limit = new QLabel(layoutWidget_4);
        label_ro_acc_limit->setObjectName(QString::fromUtf8("label_ro_acc_limit"));

        gridLayout_12->addWidget(label_ro_acc_limit, 3, 0, 1, 1);

        label_52 = new QLabel(layoutWidget_4);
        label_52->setObjectName(QString::fromUtf8("label_52"));

        gridLayout_12->addWidget(label_52, 3, 1, 1, 1);

        label_ro_hard_limitM = new QLabel(layoutWidget_4);
        label_ro_hard_limitM->setObjectName(QString::fromUtf8("label_ro_hard_limitM"));

        gridLayout_12->addWidget(label_ro_hard_limitM, 3, 2, 1, 1);

        label_53 = new QLabel(layoutWidget_4);
        label_53->setObjectName(QString::fromUtf8("label_53"));

        gridLayout_12->addWidget(label_53, 3, 3, 1, 1);

        label_ro_ampli1_fault = new QLabel(layoutWidget_4);
        label_ro_ampli1_fault->setObjectName(QString::fromUtf8("label_ro_ampli1_fault"));

        gridLayout_12->addWidget(label_ro_ampli1_fault, 4, 0, 1, 1);

        label_54 = new QLabel(layoutWidget_4);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        gridLayout_12->addWidget(label_54, 4, 1, 1, 1);

        label_ro_ampli2_fault = new QLabel(layoutWidget_4);
        label_ro_ampli2_fault->setObjectName(QString::fromUtf8("label_ro_ampli2_fault"));

        gridLayout_12->addWidget(label_ro_ampli2_fault, 4, 2, 1, 1);

        label_55 = new QLabel(layoutWidget_4);
        label_55->setObjectName(QString::fromUtf8("label_55"));

        gridLayout_12->addWidget(label_55, 4, 3, 1, 1);

        groupBox_15 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_15->setObjectName(QString::fromUtf8("groupBox_15"));
        groupBox_15->setGeometry(QRect(210, 290, 181, 131));
        layoutWidget = new QWidget(groupBox_15);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(12, 40, 151, 81));
        gridLayout_7 = new QGridLayout(layoutWidget);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        gridLayout_7->setContentsMargins(0, 0, 0, 0);
        radioButton_ro_acc_default = new QRadioButton(layoutWidget);
        radioButton_ro_acc_default->setObjectName(QString::fromUtf8("radioButton_ro_acc_default"));

        gridLayout_7->addWidget(radioButton_ro_acc_default, 0, 0, 1, 1);

        label_43 = new QLabel(layoutWidget);
        label_43->setObjectName(QString::fromUtf8("label_43"));

        gridLayout_7->addWidget(label_43, 0, 1, 1, 1);

        radioButton_ro_acc_spec = new QRadioButton(layoutWidget);
        radioButton_ro_acc_spec->setObjectName(QString::fromUtf8("radioButton_ro_acc_spec"));

        gridLayout_7->addWidget(radioButton_ro_acc_spec, 1, 0, 1, 1);

        lineEdit_ro_acc_spec = new QLineEdit(layoutWidget);
        lineEdit_ro_acc_spec->setObjectName(QString::fromUtf8("lineEdit_ro_acc_spec"));
        lineEdit_ro_acc_spec->setEnabled(false);
        lineEdit_ro_acc_spec->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_ro_acc_spec->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_ro_acc_spec->setReadOnly(false);

        gridLayout_7->addWidget(lineEdit_ro_acc_spec, 1, 1, 1, 1);

        groupBox_17 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_17->setObjectName(QString::fromUtf8("groupBox_17"));
        groupBox_17->setGeometry(QRect(210, 530, 181, 101));
        layoutWidget_13 = new QWidget(groupBox_17);
        layoutWidget_13->setObjectName(QString::fromUtf8("layoutWidget_13"));
        layoutWidget_13->setGeometry(QRect(20, 40, 141, 61));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget_13);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_ro_dirM = new QPushButton(layoutWidget_13);
        pushButton_ro_dirM->setObjectName(QString::fromUtf8("pushButton_ro_dirM"));

        horizontalLayout_3->addWidget(pushButton_ro_dirM);

        pushButton_ro_dirP = new QPushButton(layoutWidget_13);
        pushButton_ro_dirP->setObjectName(QString::fromUtf8("pushButton_ro_dirP"));

        horizontalLayout_3->addWidget(pushButton_ro_dirP);

        groupBox_20 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_20->setObjectName(QString::fromUtf8("groupBox_20"));
        groupBox_20->setGeometry(QRect(620, 530, 181, 101));
        layoutWidget_17 = new QWidget(groupBox_20);
        layoutWidget_17->setObjectName(QString::fromUtf8("layoutWidget_17"));
        layoutWidget_17->setGeometry(QRect(20, 40, 141, 61));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_17);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton_es_dirM = new QPushButton(layoutWidget_17);
        pushButton_es_dirM->setObjectName(QString::fromUtf8("pushButton_es_dirM"));

        horizontalLayout_4->addWidget(pushButton_es_dirM);

        pushButton_es_dirP = new QPushButton(layoutWidget_17);
        pushButton_es_dirP->setObjectName(QString::fromUtf8("pushButton_es_dirP"));

        horizontalLayout_4->addWidget(pushButton_es_dirP);

        pushButton_es_stop = new QPushButton(scrollAreaWidgetContents);
        pushButton_es_stop->setObjectName(QString::fromUtf8("pushButton_es_stop"));
        pushButton_es_stop->setGeometry(QRect(670, 630, 71, 61));
        groupBox_14 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_14->setObjectName(QString::fromUtf8("groupBox_14"));
        groupBox_14->setGeometry(QRect(30, 290, 181, 141));
        layoutWidget1 = new QWidget(groupBox_14);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(15, 26, 151, 102));
        gridLayout_6 = new QGridLayout(layoutWidget1);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        radioButton_ro_vel_fast = new QRadioButton(layoutWidget1);
        radioButton_ro_vel_fast->setObjectName(QString::fromUtf8("radioButton_ro_vel_fast"));

        gridLayout_6->addWidget(radioButton_ro_vel_fast, 0, 0, 1, 1);

        radioButton_ro_vel_mid = new QRadioButton(layoutWidget1);
        radioButton_ro_vel_mid->setObjectName(QString::fromUtf8("radioButton_ro_vel_mid"));
        radioButton_ro_vel_mid->setChecked(true);

        gridLayout_6->addWidget(radioButton_ro_vel_mid, 1, 0, 1, 1);

        radioButton_ro_vel_slow = new QRadioButton(layoutWidget1);
        radioButton_ro_vel_slow->setObjectName(QString::fromUtf8("radioButton_ro_vel_slow"));

        gridLayout_6->addWidget(radioButton_ro_vel_slow, 2, 0, 1, 1);

        radioButton_ro_vel_spec = new QRadioButton(layoutWidget1);
        radioButton_ro_vel_spec->setObjectName(QString::fromUtf8("radioButton_ro_vel_spec"));

        gridLayout_6->addWidget(radioButton_ro_vel_spec, 3, 0, 1, 1);

        lineEdit_ro_vel_spec = new QLineEdit(layoutWidget1);
        lineEdit_ro_vel_spec->setObjectName(QString::fromUtf8("lineEdit_ro_vel_spec"));
        lineEdit_ro_vel_spec->setEnabled(false);
        lineEdit_ro_vel_spec->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_ro_vel_spec->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_ro_vel_spec->setReadOnly(false);

        gridLayout_6->addWidget(lineEdit_ro_vel_spec, 3, 1, 1, 1);

        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(150, 0, 131, 31));
        label_11->setTextFormat(Qt::AutoText);
        label_11->setScaledContents(false);
        groupBox_18 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        groupBox_18->setGeometry(QRect(30, 580, 181, 131));
        layoutWidget_14 = new QWidget(groupBox_18);
        layoutWidget_14->setObjectName(QString::fromUtf8("layoutWidget_14"));
        layoutWidget_14->setGeometry(QRect(10, 20, 153, 102));
        gridLayout_16 = new QGridLayout(layoutWidget_14);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        gridLayout_16->setContentsMargins(0, 0, 0, 0);
        radioButton_ro_step1 = new QRadioButton(layoutWidget_14);
        radioButton_ro_step1->setObjectName(QString::fromUtf8("radioButton_ro_step1"));

        gridLayout_16->addWidget(radioButton_ro_step1, 0, 0, 1, 1);

        pushButton_ro_stepM = new QPushButton(layoutWidget_14);
        pushButton_ro_stepM->setObjectName(QString::fromUtf8("pushButton_ro_stepM"));

        gridLayout_16->addWidget(pushButton_ro_stepM, 0, 1, 2, 1);

        radioButton_ro_step01 = new QRadioButton(layoutWidget_14);
        radioButton_ro_step01->setObjectName(QString::fromUtf8("radioButton_ro_step01"));

        gridLayout_16->addWidget(radioButton_ro_step01, 1, 0, 2, 1);

        pushButton_ro_stepP = new QPushButton(layoutWidget_14);
        pushButton_ro_stepP->setObjectName(QString::fromUtf8("pushButton_ro_stepP"));

        gridLayout_16->addWidget(pushButton_ro_stepP, 2, 1, 2, 1);

        radioButton_ro_step001 = new QRadioButton(layoutWidget_14);
        radioButton_ro_step001->setObjectName(QString::fromUtf8("radioButton_ro_step001"));

        gridLayout_16->addWidget(radioButton_ro_step001, 3, 0, 1, 1);

        radioButton_ro_step_spec = new QRadioButton(layoutWidget_14);
        radioButton_ro_step_spec->setObjectName(QString::fromUtf8("radioButton_ro_step_spec"));

        gridLayout_16->addWidget(radioButton_ro_step_spec, 4, 0, 1, 1);

        lineEdit_ro_step_spec = new QLineEdit(layoutWidget_14);
        lineEdit_ro_step_spec->setObjectName(QString::fromUtf8("lineEdit_ro_step_spec"));
        lineEdit_ro_step_spec->setEnabled(false);

        gridLayout_16->addWidget(lineEdit_ro_step_spec, 4, 1, 1, 1);

        pushButton_ro_stop = new QPushButton(scrollAreaWidgetContents);
        pushButton_ro_stop->setObjectName(QString::fromUtf8("pushButton_ro_stop"));
        pushButton_ro_stop->setGeometry(QRect(260, 630, 71, 61));
        layoutWidget2 = new QWidget(scrollAreaWidgetContents);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(40, 90, 341, 41));
        horizontalLayout = new QHBoxLayout(layoutWidget2);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_ro_axis = new QPushButton(layoutWidget2);
        pushButton_ro_axis->setObjectName(QString::fromUtf8("pushButton_ro_axis"));

        horizontalLayout->addWidget(pushButton_ro_axis);

        pushButton_ro_home = new QPushButton(layoutWidget2);
        pushButton_ro_home->setObjectName(QString::fromUtf8("pushButton_ro_home"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton_ro_home->sizePolicy().hasHeightForWidth());
        pushButton_ro_home->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButton_ro_home);

        pushButton_ro_park = new QPushButton(layoutWidget2);
        pushButton_ro_park->setObjectName(QString::fromUtf8("pushButton_ro_park"));
        sizePolicy.setHeightForWidth(pushButton_ro_park->sizePolicy().hasHeightForWidth());
        pushButton_ro_park->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButton_ro_park);

        groupBox = new QGroupBox(scrollAreaWidgetContents);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(30, 420, 181, 161));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(12, 21, 54, 16));
        layoutWidget3 = new QWidget(groupBox);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(10, 40, 161, 110));
        gridLayout = new QGridLayout(layoutWidget3);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget3);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        label_3 = new QLabel(layoutWidget3);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_3, 1, 0, 1, 1);

        pushButton_ro_F2 = new QPushButton(layoutWidget3);
        pushButton_ro_F2->setObjectName(QString::fromUtf8("pushButton_ro_F2"));

        gridLayout->addWidget(pushButton_ro_F2, 1, 1, 1, 1);

        label_4 = new QLabel(layoutWidget3);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        pushButton_ro_F3 = new QPushButton(layoutWidget3);
        pushButton_ro_F3->setObjectName(QString::fromUtf8("pushButton_ro_F3"));

        gridLayout->addWidget(pushButton_ro_F3, 2, 1, 1, 1);

        label_5 = new QLabel(layoutWidget3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_5, 3, 0, 1, 1);

        pushButton_ro_F4 = new QPushButton(layoutWidget3);
        pushButton_ro_F4->setObjectName(QString::fromUtf8("pushButton_ro_F4"));

        gridLayout->addWidget(pushButton_ro_F4, 3, 1, 1, 1);

        pushButton_ro_F1 = new QPushButton(layoutWidget3);
        pushButton_ro_F1->setObjectName(QString::fromUtf8("pushButton_ro_F1"));

        gridLayout->addWidget(pushButton_ro_F1, 0, 1, 1, 1);

        groupBox_2 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(440, 420, 181, 151));
        label_6 = new QLabel(groupBox_2);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(11, 20, 54, 16));
        layoutWidget4 = new QWidget(groupBox_2);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(11, 40, 164, 101));
        gridLayout_2 = new QGridLayout(layoutWidget4);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label_7 = new QLabel(layoutWidget4);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_7, 0, 0, 1, 1);

        pushButton_11 = new QPushButton(layoutWidget4);
        pushButton_11->setObjectName(QString::fromUtf8("pushButton_11"));

        gridLayout_2->addWidget(pushButton_11, 0, 1, 1, 1);

        label_8 = new QLabel(layoutWidget4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_8, 1, 0, 1, 1);

        pushButton_12 = new QPushButton(layoutWidget4);
        pushButton_12->setObjectName(QString::fromUtf8("pushButton_12"));

        gridLayout_2->addWidget(pushButton_12, 1, 1, 1, 1);

        groupBox_22 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_22->setObjectName(QString::fromUtf8("groupBox_22"));
        groupBox_22->setGeometry(QRect(440, 570, 181, 131));
        layoutWidget_19 = new QWidget(groupBox_22);
        layoutWidget_19->setObjectName(QString::fromUtf8("layoutWidget_19"));
        layoutWidget_19->setGeometry(QRect(10, 20, 153, 102));
        gridLayout_19 = new QGridLayout(layoutWidget_19);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        gridLayout_19->setContentsMargins(0, 0, 0, 0);
        radioButton_es_step1 = new QRadioButton(layoutWidget_19);
        radioButton_es_step1->setObjectName(QString::fromUtf8("radioButton_es_step1"));

        gridLayout_19->addWidget(radioButton_es_step1, 0, 0, 1, 1);

        pushButton_es_stepM = new QPushButton(layoutWidget_19);
        pushButton_es_stepM->setObjectName(QString::fromUtf8("pushButton_es_stepM"));

        gridLayout_19->addWidget(pushButton_es_stepM, 0, 1, 2, 1);

        radioButton_es_step01 = new QRadioButton(layoutWidget_19);
        radioButton_es_step01->setObjectName(QString::fromUtf8("radioButton_es_step01"));

        gridLayout_19->addWidget(radioButton_es_step01, 1, 0, 2, 1);

        pushButton_es_stepP = new QPushButton(layoutWidget_19);
        pushButton_es_stepP->setObjectName(QString::fromUtf8("pushButton_es_stepP"));

        gridLayout_19->addWidget(pushButton_es_stepP, 2, 1, 2, 1);

        radioButton_es_step001 = new QRadioButton(layoutWidget_19);
        radioButton_es_step001->setObjectName(QString::fromUtf8("radioButton_es_step001"));

        gridLayout_19->addWidget(radioButton_es_step001, 3, 0, 1, 1);

        radioButton_es_step_spec = new QRadioButton(layoutWidget_19);
        radioButton_es_step_spec->setObjectName(QString::fromUtf8("radioButton_es_step_spec"));

        gridLayout_19->addWidget(radioButton_es_step_spec, 4, 0, 1, 1);

        lineEdit_es_step_spec = new QLineEdit(layoutWidget_19);
        lineEdit_es_step_spec->setObjectName(QString::fromUtf8("lineEdit_es_step_spec"));
        lineEdit_es_step_spec->setEnabled(false);

        gridLayout_19->addWidget(lineEdit_es_step_spec, 4, 1, 1, 1);

        groupBox_21 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_21->setObjectName(QString::fromUtf8("groupBox_21"));
        groupBox_21->setGeometry(QRect(440, 290, 181, 141));
        layoutWidget5 = new QWidget(groupBox_21);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(10, 24, 161, 102));
        gridLayout_8 = new QGridLayout(layoutWidget5);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        radioButton_es_vel_fast = new QRadioButton(layoutWidget5);
        radioButton_es_vel_fast->setObjectName(QString::fromUtf8("radioButton_es_vel_fast"));

        gridLayout_8->addWidget(radioButton_es_vel_fast, 0, 0, 1, 1);

        radioButton_es_vel_mid = new QRadioButton(layoutWidget5);
        radioButton_es_vel_mid->setObjectName(QString::fromUtf8("radioButton_es_vel_mid"));

        gridLayout_8->addWidget(radioButton_es_vel_mid, 1, 0, 1, 1);

        radioButton_es_vel_slow = new QRadioButton(layoutWidget5);
        radioButton_es_vel_slow->setObjectName(QString::fromUtf8("radioButton_es_vel_slow"));

        gridLayout_8->addWidget(radioButton_es_vel_slow, 2, 0, 1, 1);

        radioButton_es_vel_spec = new QRadioButton(layoutWidget5);
        radioButton_es_vel_spec->setObjectName(QString::fromUtf8("radioButton_es_vel_spec"));

        gridLayout_8->addWidget(radioButton_es_vel_spec, 3, 0, 1, 1);

        lineEdit_es_vel_spec = new QLineEdit(layoutWidget5);
        lineEdit_es_vel_spec->setObjectName(QString::fromUtf8("lineEdit_es_vel_spec"));
        lineEdit_es_vel_spec->setEnabled(false);
        lineEdit_es_vel_spec->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_es_vel_spec->setReadOnly(false);

        gridLayout_8->addWidget(lineEdit_es_vel_spec, 3, 1, 1, 1);

        groupBox_19 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_19->setObjectName(QString::fromUtf8("groupBox_19"));
        groupBox_19->setGeometry(QRect(440, 130, 361, 151));
        layoutWidget_16 = new QWidget(groupBox_19);
        layoutWidget_16->setObjectName(QString::fromUtf8("layoutWidget_16"));
        layoutWidget_16->setGeometry(QRect(259, 32, 64, 105));
        verticalLayout_7 = new QVBoxLayout(layoutWidget_16);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_17 = new QLabel(layoutWidget_16);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_7->addWidget(label_17);

        pushButton_es_warning = new QPushButton(layoutWidget_16);
        pushButton_es_warning->setObjectName(QString::fromUtf8("pushButton_es_warning"));
        pushButton_es_warning->setEnabled(false);

        verticalLayout_7->addWidget(pushButton_es_warning);

        verticalSpacer_5 = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_5);

        pushButton_es_reset = new QPushButton(layoutWidget_16);
        pushButton_es_reset->setObjectName(QString::fromUtf8("pushButton_es_reset"));

        verticalLayout_7->addWidget(pushButton_es_reset);

        layoutWidget_2 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(450, 90, 341, 41));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_2 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        pushButton_es_axis = new QPushButton(layoutWidget_2);
        pushButton_es_axis->setObjectName(QString::fromUtf8("pushButton_es_axis"));

        horizontalLayout_2->addWidget(pushButton_es_axis);

        pushButton_es_home = new QPushButton(layoutWidget_2);
        pushButton_es_home->setObjectName(QString::fromUtf8("pushButton_es_home"));
        sizePolicy.setHeightForWidth(pushButton_es_home->sizePolicy().hasHeightForWidth());
        pushButton_es_home->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(pushButton_es_home);

        pushButton_es_park = new QPushButton(layoutWidget_2);
        pushButton_es_park->setObjectName(QString::fromUtf8("pushButton_es_park"));
        sizePolicy.setHeightForWidth(pushButton_es_park->sizePolicy().hasHeightForWidth());
        pushButton_es_park->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(pushButton_es_park);

        groupBox_24 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_24->setObjectName(QString::fromUtf8("groupBox_24"));
        groupBox_24->setGeometry(QRect(620, 290, 181, 131));
        layoutWidget6 = new QWidget(groupBox_24);
        layoutWidget6->setObjectName(QString::fromUtf8("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(10, 40, 161, 81));
        gridLayout_9 = new QGridLayout(layoutWidget6);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        radioButton_es_acc_default = new QRadioButton(layoutWidget6);
        radioButton_es_acc_default->setObjectName(QString::fromUtf8("radioButton_es_acc_default"));

        gridLayout_9->addWidget(radioButton_es_acc_default, 0, 0, 1, 1);

        label_46 = new QLabel(layoutWidget6);
        label_46->setObjectName(QString::fromUtf8("label_46"));

        gridLayout_9->addWidget(label_46, 0, 1, 1, 1);

        radioButton_es_acc_spec = new QRadioButton(layoutWidget6);
        radioButton_es_acc_spec->setObjectName(QString::fromUtf8("radioButton_es_acc_spec"));

        gridLayout_9->addWidget(radioButton_es_acc_spec, 1, 0, 1, 1);

        lineEdit_es_acc_spec = new QLineEdit(layoutWidget6);
        lineEdit_es_acc_spec->setObjectName(QString::fromUtf8("lineEdit_es_acc_spec"));
        lineEdit_es_acc_spec->setEnabled(false);
        lineEdit_es_acc_spec->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_es_acc_spec->setReadOnly(false);

        gridLayout_9->addWidget(lineEdit_es_acc_spec, 1, 1, 1, 1);

        groupBox_23 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_23->setObjectName(QString::fromUtf8("groupBox_23"));
        groupBox_23->setGeometry(QRect(620, 420, 181, 111));
        layoutWidget7 = new QWidget(groupBox_23);
        layoutWidget7->setObjectName(QString::fromUtf8("layoutWidget7"));
        layoutWidget7->setGeometry(QRect(40, 31, 121, 76));
        verticalLayout = new QVBoxLayout(layoutWidget7);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_13 = new QLabel(layoutWidget7);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label_13);

        horizontalLayout_24 = new QHBoxLayout();
        horizontalLayout_24->setObjectName(QString::fromUtf8("horizontalLayout_24"));
        lineEdit_es_target = new QLineEdit(layoutWidget7);
        lineEdit_es_target->setObjectName(QString::fromUtf8("lineEdit_es_target"));
        lineEdit_es_target->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_es_target->setReadOnly(false);

        horizontalLayout_24->addWidget(lineEdit_es_target);

        label_50 = new QLabel(layoutWidget7);
        label_50->setObjectName(QString::fromUtf8("label_50"));

        horizontalLayout_24->addWidget(label_50);


        verticalLayout->addLayout(horizontalLayout_24);

        pushButton_es_go = new QPushButton(layoutWidget7);
        pushButton_es_go->setObjectName(QString::fromUtf8("pushButton_es_go"));

        verticalLayout->addWidget(pushButton_es_go);

        groupBox_25 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_25->setObjectName(QString::fromUtf8("groupBox_25"));
        groupBox_25->setGeometry(QRect(850, 290, 181, 141));
        layoutWidget8 = new QWidget(groupBox_25);
        layoutWidget8->setObjectName(QString::fromUtf8("layoutWidget8"));
        layoutWidget8->setGeometry(QRect(10, 24, 161, 102));
        gridLayout_10 = new QGridLayout(layoutWidget8);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        gridLayout_10->setContentsMargins(0, 0, 0, 0);
        radioButton_tr_vel_fast = new QRadioButton(layoutWidget8);
        radioButton_tr_vel_fast->setObjectName(QString::fromUtf8("radioButton_tr_vel_fast"));

        gridLayout_10->addWidget(radioButton_tr_vel_fast, 0, 0, 1, 1);

        radioButton_tr_vel_mid = new QRadioButton(layoutWidget8);
        radioButton_tr_vel_mid->setObjectName(QString::fromUtf8("radioButton_tr_vel_mid"));
        radioButton_tr_vel_mid->setChecked(true);

        gridLayout_10->addWidget(radioButton_tr_vel_mid, 1, 0, 1, 1);

        radioButton_tr_vel_slow = new QRadioButton(layoutWidget8);
        radioButton_tr_vel_slow->setObjectName(QString::fromUtf8("radioButton_tr_vel_slow"));

        gridLayout_10->addWidget(radioButton_tr_vel_slow, 2, 0, 1, 1);

        radioButton_tr_vel_spec = new QRadioButton(layoutWidget8);
        radioButton_tr_vel_spec->setObjectName(QString::fromUtf8("radioButton_tr_vel_spec"));

        gridLayout_10->addWidget(radioButton_tr_vel_spec, 3, 0, 1, 1);

        lineEdit_tr_vel_spec = new QLineEdit(layoutWidget8);
        lineEdit_tr_vel_spec->setObjectName(QString::fromUtf8("lineEdit_tr_vel_spec"));
        lineEdit_tr_vel_spec->setEnabled(false);
        lineEdit_tr_vel_spec->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tr_vel_spec->setReadOnly(false);

        gridLayout_10->addWidget(lineEdit_tr_vel_spec, 3, 1, 1, 1);

        groupBox_26 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_26->setObjectName(QString::fromUtf8("groupBox_26"));
        groupBox_26->setGeometry(QRect(1030, 420, 181, 111));
        layoutWidget_25 = new QWidget(groupBox_26);
        layoutWidget_25->setObjectName(QString::fromUtf8("layoutWidget_25"));
        layoutWidget_25->setGeometry(QRect(20, 40, 141, 61));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget_25);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButton_tr_dirM = new QPushButton(layoutWidget_25);
        pushButton_tr_dirM->setObjectName(QString::fromUtf8("pushButton_tr_dirM"));

        horizontalLayout_5->addWidget(pushButton_tr_dirM);

        pushButton_tr_dirP = new QPushButton(layoutWidget_25);
        pushButton_tr_dirP->setObjectName(QString::fromUtf8("pushButton_tr_dirP"));

        horizontalLayout_5->addWidget(pushButton_tr_dirP);

        groupBox_27 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_27->setObjectName(QString::fromUtf8("groupBox_27"));
        groupBox_27->setGeometry(QRect(850, 420, 181, 111));
        layoutWidget9 = new QWidget(groupBox_27);
        layoutWidget9->setObjectName(QString::fromUtf8("layoutWidget9"));
        layoutWidget9->setGeometry(QRect(40, 26, 121, 81));
        verticalLayout_2 = new QVBoxLayout(layoutWidget9);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_29 = new QLabel(layoutWidget9);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_29);

        horizontalLayout_25 = new QHBoxLayout();
        horizontalLayout_25->setObjectName(QString::fromUtf8("horizontalLayout_25"));
        lineEdit_tr_target = new QLineEdit(layoutWidget9);
        lineEdit_tr_target->setObjectName(QString::fromUtf8("lineEdit_tr_target"));
        lineEdit_tr_target->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tr_target->setReadOnly(false);

        horizontalLayout_25->addWidget(lineEdit_tr_target);

        label_51 = new QLabel(layoutWidget9);
        label_51->setObjectName(QString::fromUtf8("label_51"));

        horizontalLayout_25->addWidget(label_51);


        verticalLayout_2->addLayout(horizontalLayout_25);

        pushButton_tr_go = new QPushButton(layoutWidget9);
        pushButton_tr_go->setObjectName(QString::fromUtf8("pushButton_tr_go"));

        verticalLayout_2->addWidget(pushButton_tr_go);

        groupBox_28 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_28->setObjectName(QString::fromUtf8("groupBox_28"));
        groupBox_28->setGeometry(QRect(850, 530, 181, 131));
        layoutWidget_28 = new QWidget(groupBox_28);
        layoutWidget_28->setObjectName(QString::fromUtf8("layoutWidget_28"));
        layoutWidget_28->setGeometry(QRect(10, 20, 153, 102));
        gridLayout_25 = new QGridLayout(layoutWidget_28);
        gridLayout_25->setObjectName(QString::fromUtf8("gridLayout_25"));
        gridLayout_25->setContentsMargins(0, 0, 0, 0);
        radioButton_tr_step1 = new QRadioButton(layoutWidget_28);
        radioButton_tr_step1->setObjectName(QString::fromUtf8("radioButton_tr_step1"));

        gridLayout_25->addWidget(radioButton_tr_step1, 0, 0, 1, 1);

        pushButton_tr_stepM = new QPushButton(layoutWidget_28);
        pushButton_tr_stepM->setObjectName(QString::fromUtf8("pushButton_tr_stepM"));

        gridLayout_25->addWidget(pushButton_tr_stepM, 0, 1, 2, 1);

        radioButton_tr_step01 = new QRadioButton(layoutWidget_28);
        radioButton_tr_step01->setObjectName(QString::fromUtf8("radioButton_tr_step01"));

        gridLayout_25->addWidget(radioButton_tr_step01, 1, 0, 2, 1);

        pushButton_tr_stepP = new QPushButton(layoutWidget_28);
        pushButton_tr_stepP->setObjectName(QString::fromUtf8("pushButton_tr_stepP"));

        gridLayout_25->addWidget(pushButton_tr_stepP, 2, 1, 2, 1);

        radioButton_tr_step001 = new QRadioButton(layoutWidget_28);
        radioButton_tr_step001->setObjectName(QString::fromUtf8("radioButton_tr_step001"));

        gridLayout_25->addWidget(radioButton_tr_step001, 3, 0, 1, 1);

        radioButton_tr_step_spec = new QRadioButton(layoutWidget_28);
        radioButton_tr_step_spec->setObjectName(QString::fromUtf8("radioButton_tr_step_spec"));

        gridLayout_25->addWidget(radioButton_tr_step_spec, 4, 0, 1, 1);

        lineEdit_tr_step_spec = new QLineEdit(layoutWidget_28);
        lineEdit_tr_step_spec->setObjectName(QString::fromUtf8("lineEdit_tr_step_spec"));
        lineEdit_tr_step_spec->setEnabled(false);

        gridLayout_25->addWidget(lineEdit_tr_step_spec, 4, 1, 1, 1);

        pushButton_tr_stop = new QPushButton(scrollAreaWidgetContents);
        pushButton_tr_stop->setObjectName(QString::fromUtf8("pushButton_tr_stop"));
        pushButton_tr_stop->setGeometry(QRect(1080, 560, 71, 61));
        label_30 = new QLabel(scrollAreaWidgetContents);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(964, 0, 161, 31));
        label_30->setTextFormat(Qt::AutoText);
        label_30->setScaledContents(false);
        groupBox_29 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_29->setObjectName(QString::fromUtf8("groupBox_29"));
        groupBox_29->setGeometry(QRect(850, 130, 361, 161));
        layoutWidget_30 = new QWidget(groupBox_29);
        layoutWidget_30->setObjectName(QString::fromUtf8("layoutWidget_30"));
        layoutWidget_30->setGeometry(QRect(259, 32, 64, 105));
        verticalLayout_10 = new QVBoxLayout(layoutWidget_30);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        label_31 = new QLabel(layoutWidget_30);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        verticalLayout_10->addWidget(label_31);

        pushButton_tr_warning = new QPushButton(layoutWidget_30);
        pushButton_tr_warning->setObjectName(QString::fromUtf8("pushButton_tr_warning"));
        pushButton_tr_warning->setEnabled(false);

        verticalLayout_10->addWidget(pushButton_tr_warning);

        verticalSpacer_6 = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_10->addItem(verticalSpacer_6);

        pushButton_tr_reset = new QPushButton(layoutWidget_30);
        pushButton_tr_reset->setObjectName(QString::fromUtf8("pushButton_tr_reset"));

        verticalLayout_10->addWidget(pushButton_tr_reset);

        groupBox_30 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_30->setObjectName(QString::fromUtf8("groupBox_30"));
        groupBox_30->setGeometry(QRect(1030, 290, 181, 131));
        layoutWidget10 = new QWidget(groupBox_30);
        layoutWidget10->setObjectName(QString::fromUtf8("layoutWidget10"));
        layoutWidget10->setGeometry(QRect(10, 41, 161, 81));
        gridLayout_11 = new QGridLayout(layoutWidget10);
        gridLayout_11->setObjectName(QString::fromUtf8("gridLayout_11"));
        gridLayout_11->setContentsMargins(0, 0, 0, 0);
        radioButton_tr_acc_default = new QRadioButton(layoutWidget10);
        radioButton_tr_acc_default->setObjectName(QString::fromUtf8("radioButton_tr_acc_default"));

        gridLayout_11->addWidget(radioButton_tr_acc_default, 0, 0, 1, 1);

        label_48 = new QLabel(layoutWidget10);
        label_48->setObjectName(QString::fromUtf8("label_48"));

        gridLayout_11->addWidget(label_48, 0, 1, 1, 1);

        radioButton_tr_acc_spec = new QRadioButton(layoutWidget10);
        radioButton_tr_acc_spec->setObjectName(QString::fromUtf8("radioButton_tr_acc_spec"));

        gridLayout_11->addWidget(radioButton_tr_acc_spec, 1, 0, 1, 1);

        lineEdit_tr_acc_spec = new QLineEdit(layoutWidget10);
        lineEdit_tr_acc_spec->setObjectName(QString::fromUtf8("lineEdit_tr_acc_spec"));
        lineEdit_tr_acc_spec->setEnabled(false);
        lineEdit_tr_acc_spec->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tr_acc_spec->setReadOnly(false);

        gridLayout_11->addWidget(lineEdit_tr_acc_spec, 1, 1, 1, 1);

        layoutWidget_3 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(860, 90, 341, 41));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_6 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_6);

        pushButton_tr_axis = new QPushButton(layoutWidget_3);
        pushButton_tr_axis->setObjectName(QString::fromUtf8("pushButton_tr_axis"));

        horizontalLayout_6->addWidget(pushButton_tr_axis);

        pushButton_tr_home = new QPushButton(layoutWidget_3);
        pushButton_tr_home->setObjectName(QString::fromUtf8("pushButton_tr_home"));
        sizePolicy.setHeightForWidth(pushButton_tr_home->sizePolicy().hasHeightForWidth());
        pushButton_tr_home->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(pushButton_tr_home);

        pushButton_tr_park = new QPushButton(layoutWidget_3);
        pushButton_tr_park->setObjectName(QString::fromUtf8("pushButton_tr_park"));
        sizePolicy.setHeightForWidth(pushButton_tr_park->sizePolicy().hasHeightForWidth());
        pushButton_tr_park->setSizePolicy(sizePolicy);

        horizontalLayout_6->addWidget(pushButton_tr_park);

        layoutWidget11 = new QWidget(scrollAreaWidgetContents);
        layoutWidget11->setObjectName(QString::fromUtf8("layoutWidget11"));
        layoutWidget11->setGeometry(QRect(10, 30, 421, 60));
        gridLayout_3 = new QGridLayout(layoutWidget11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        label_22 = new QLabel(layoutWidget11);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout_3->addWidget(label_22, 0, 0, 1, 1);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        lineEdit_ro_posD = new QLineEdit(layoutWidget11);
        lineEdit_ro_posD->setObjectName(QString::fromUtf8("lineEdit_ro_posD"));
        lineEdit_ro_posD->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_ro_posD->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_ro_posD->setReadOnly(true);

        horizontalLayout_16->addWidget(lineEdit_ro_posD);

        label_38 = new QLabel(layoutWidget11);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        horizontalLayout_16->addWidget(label_38);


        gridLayout_3->addLayout(horizontalLayout_16, 0, 1, 1, 1);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        lineEdit_pos_posM = new QLineEdit(layoutWidget11);
        lineEdit_pos_posM->setObjectName(QString::fromUtf8("lineEdit_pos_posM"));
        lineEdit_pos_posM->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_pos_posM->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_pos_posM->setReadOnly(true);

        horizontalLayout_14->addWidget(lineEdit_pos_posM);

        label_33 = new QLabel(layoutWidget11);
        label_33->setObjectName(QString::fromUtf8("label_33"));

        horizontalLayout_14->addWidget(label_33);


        gridLayout_3->addLayout(horizontalLayout_14, 0, 2, 1, 1);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        lineEdit_ro_posS = new QLineEdit(layoutWidget11);
        lineEdit_ro_posS->setObjectName(QString::fromUtf8("lineEdit_ro_posS"));
        lineEdit_ro_posS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_ro_posS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_ro_posS->setReadOnly(true);

        horizontalLayout_15->addWidget(lineEdit_ro_posS);

        label_32 = new QLabel(layoutWidget11);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        horizontalLayout_15->addWidget(label_32);


        gridLayout_3->addLayout(horizontalLayout_15, 0, 3, 1, 1);

        label_23 = new QLabel(layoutWidget11);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout_3->addWidget(label_23, 0, 4, 1, 1);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        lineEdit_ro_vel = new QLineEdit(layoutWidget11);
        lineEdit_ro_vel->setObjectName(QString::fromUtf8("lineEdit_ro_vel"));
        lineEdit_ro_vel->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_ro_vel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_ro_vel->setReadOnly(false);

        horizontalLayout_13->addWidget(lineEdit_ro_vel);

        label_37 = new QLabel(layoutWidget11);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        horizontalLayout_13->addWidget(label_37);


        gridLayout_3->addLayout(horizontalLayout_13, 0, 5, 1, 1);

        label_24 = new QLabel(layoutWidget11);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout_3->addWidget(label_24, 1, 0, 1, 1);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        lineEdit_ro_poserr = new QLineEdit(layoutWidget11);
        lineEdit_ro_poserr->setObjectName(QString::fromUtf8("lineEdit_ro_poserr"));
        lineEdit_ro_poserr->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_ro_poserr->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_ro_poserr->setReadOnly(true);

        horizontalLayout_12->addWidget(lineEdit_ro_poserr);

        label_36 = new QLabel(layoutWidget11);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        horizontalLayout_12->addWidget(label_36);


        gridLayout_3->addLayout(horizontalLayout_12, 1, 1, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(128, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_4, 1, 4, 1, 2);

        layoutWidget12 = new QWidget(scrollAreaWidgetContents);
        layoutWidget12->setObjectName(QString::fromUtf8("layoutWidget12"));
        layoutWidget12->setGeometry(QRect(450, 30, 371, 60));
        gridLayout_4 = new QGridLayout(layoutWidget12);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        label_18 = new QLabel(layoutWidget12);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_4->addWidget(label_18, 0, 0, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        lineEdit_es_pos = new QLineEdit(layoutWidget12);
        lineEdit_es_pos->setObjectName(QString::fromUtf8("lineEdit_es_pos"));
        lineEdit_es_pos->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_es_pos->setReadOnly(true);

        horizontalLayout_7->addWidget(lineEdit_es_pos);

        label_15 = new QLabel(layoutWidget12);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        horizontalLayout_7->addWidget(label_15);


        gridLayout_4->addLayout(horizontalLayout_7, 0, 1, 1, 1);

        label_19 = new QLabel(layoutWidget12);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_4->addWidget(label_19, 0, 2, 1, 1);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        lineEdit_es_vel = new QLineEdit(layoutWidget12);
        lineEdit_es_vel->setObjectName(QString::fromUtf8("lineEdit_es_vel"));
        lineEdit_es_vel->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_es_vel->setReadOnly(true);

        horizontalLayout_9->addWidget(lineEdit_es_vel);

        label_34 = new QLabel(layoutWidget12);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        horizontalLayout_9->addWidget(label_34);


        gridLayout_4->addLayout(horizontalLayout_9, 0, 3, 1, 1);

        label_20 = new QLabel(layoutWidget12);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_4->addWidget(label_20, 1, 0, 1, 1);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        lineEdit_es_poserr = new QLineEdit(layoutWidget12);
        lineEdit_es_poserr->setObjectName(QString::fromUtf8("lineEdit_es_poserr"));
        lineEdit_es_poserr->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_es_poserr->setReadOnly(true);

        horizontalLayout_8->addWidget(lineEdit_es_poserr);

        label_25 = new QLabel(layoutWidget12);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        horizontalLayout_8->addWidget(label_25);


        gridLayout_4->addLayout(horizontalLayout_8, 1, 1, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_4->addItem(horizontalSpacer_3, 1, 2, 1, 2);

        layoutWidget13 = new QWidget(scrollAreaWidgetContents);
        layoutWidget13->setObjectName(QString::fromUtf8("layoutWidget13"));
        layoutWidget13->setGeometry(QRect(860, 30, 341, 60));
        gridLayout_5 = new QGridLayout(layoutWidget13);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        label_26 = new QLabel(layoutWidget13);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout_5->addWidget(label_26, 0, 0, 1, 1);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        lineEdit_tr_pos = new QLineEdit(layoutWidget13);
        lineEdit_tr_pos->setObjectName(QString::fromUtf8("lineEdit_tr_pos"));
        lineEdit_tr_pos->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tr_pos->setReadOnly(true);

        horizontalLayout_11->addWidget(lineEdit_tr_pos);

        label_39 = new QLabel(layoutWidget13);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        horizontalLayout_11->addWidget(label_39);


        gridLayout_5->addLayout(horizontalLayout_11, 0, 1, 1, 1);

        label_27 = new QLabel(layoutWidget13);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        gridLayout_5->addWidget(label_27, 0, 2, 1, 1);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        lineEdit_tr_vel = new QLineEdit(layoutWidget13);
        lineEdit_tr_vel->setObjectName(QString::fromUtf8("lineEdit_tr_vel"));
        lineEdit_tr_vel->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tr_vel->setReadOnly(true);

        horizontalLayout_17->addWidget(lineEdit_tr_vel);

        label_40 = new QLabel(layoutWidget13);
        label_40->setObjectName(QString::fromUtf8("label_40"));

        horizontalLayout_17->addWidget(label_40);


        gridLayout_5->addLayout(horizontalLayout_17, 0, 3, 1, 1);

        label_28 = new QLabel(layoutWidget13);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        gridLayout_5->addWidget(label_28, 1, 0, 1, 1);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        lineEdit_tr_poserr = new QLineEdit(layoutWidget13);
        lineEdit_tr_poserr->setObjectName(QString::fromUtf8("lineEdit_tr_poserr"));
        lineEdit_tr_poserr->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tr_poserr->setReadOnly(true);

        horizontalLayout_10->addWidget(lineEdit_tr_poserr);

        label_35 = new QLabel(layoutWidget13);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        horizontalLayout_10->addWidget(label_35);


        gridLayout_5->addLayout(horizontalLayout_10, 1, 1, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_5->addItem(horizontalSpacer_5, 1, 2, 1, 2);

        layoutWidget_5 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_5->setObjectName(QString::fromUtf8("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(450, 160, 231, 131));
        gridLayout_13 = new QGridLayout(layoutWidget_5);
        gridLayout_13->setObjectName(QString::fromUtf8("gridLayout_13"));
        gridLayout_13->setContentsMargins(0, 0, 0, 0);
        label_es_homed = new QLabel(layoutWidget_5);
        label_es_homed->setObjectName(QString::fromUtf8("label_es_homed"));

        gridLayout_13->addWidget(label_es_homed, 0, 0, 1, 1);

        label_56 = new QLabel(layoutWidget_5);
        label_56->setObjectName(QString::fromUtf8("label_56"));

        gridLayout_13->addWidget(label_56, 0, 1, 1, 1);

        label_es_soft_limitP = new QLabel(layoutWidget_5);
        label_es_soft_limitP->setObjectName(QString::fromUtf8("label_es_soft_limitP"));

        gridLayout_13->addWidget(label_es_soft_limitP, 0, 2, 1, 1);

        label_57 = new QLabel(layoutWidget_5);
        label_57->setObjectName(QString::fromUtf8("label_57"));

        gridLayout_13->addWidget(label_57, 0, 3, 1, 1);

        label_es_brake = new QLabel(layoutWidget_5);
        label_es_brake->setObjectName(QString::fromUtf8("label_es_brake"));

        gridLayout_13->addWidget(label_es_brake, 1, 0, 1, 1);

        label_58 = new QLabel(layoutWidget_5);
        label_58->setObjectName(QString::fromUtf8("label_58"));

        gridLayout_13->addWidget(label_58, 1, 1, 1, 1);

        label_es_soft_limitM = new QLabel(layoutWidget_5);
        label_es_soft_limitM->setObjectName(QString::fromUtf8("label_es_soft_limitM"));

        gridLayout_13->addWidget(label_es_soft_limitM, 1, 2, 1, 1);

        label_59 = new QLabel(layoutWidget_5);
        label_59->setObjectName(QString::fromUtf8("label_59"));

        gridLayout_13->addWidget(label_59, 1, 3, 1, 1);

        label_es_vel_limit = new QLabel(layoutWidget_5);
        label_es_vel_limit->setObjectName(QString::fromUtf8("label_es_vel_limit"));

        gridLayout_13->addWidget(label_es_vel_limit, 2, 0, 1, 1);

        label_60 = new QLabel(layoutWidget_5);
        label_60->setObjectName(QString::fromUtf8("label_60"));

        gridLayout_13->addWidget(label_60, 2, 1, 1, 1);

        label_es_hard_limitP = new QLabel(layoutWidget_5);
        label_es_hard_limitP->setObjectName(QString::fromUtf8("label_es_hard_limitP"));

        gridLayout_13->addWidget(label_es_hard_limitP, 2, 2, 1, 1);

        label_61 = new QLabel(layoutWidget_5);
        label_61->setObjectName(QString::fromUtf8("label_61"));

        gridLayout_13->addWidget(label_61, 2, 3, 1, 1);

        label_es_acc_limit = new QLabel(layoutWidget_5);
        label_es_acc_limit->setObjectName(QString::fromUtf8("label_es_acc_limit"));

        gridLayout_13->addWidget(label_es_acc_limit, 3, 0, 1, 1);

        label_62 = new QLabel(layoutWidget_5);
        label_62->setObjectName(QString::fromUtf8("label_62"));

        gridLayout_13->addWidget(label_62, 3, 1, 1, 1);

        label_es_hard_limitM = new QLabel(layoutWidget_5);
        label_es_hard_limitM->setObjectName(QString::fromUtf8("label_es_hard_limitM"));

        gridLayout_13->addWidget(label_es_hard_limitM, 3, 2, 1, 1);

        label_63 = new QLabel(layoutWidget_5);
        label_63->setObjectName(QString::fromUtf8("label_63"));

        gridLayout_13->addWidget(label_63, 3, 3, 1, 1);

        label_es_ampli1_fault = new QLabel(layoutWidget_5);
        label_es_ampli1_fault->setObjectName(QString::fromUtf8("label_es_ampli1_fault"));

        gridLayout_13->addWidget(label_es_ampli1_fault, 4, 0, 1, 1);

        label_64 = new QLabel(layoutWidget_5);
        label_64->setObjectName(QString::fromUtf8("label_64"));

        gridLayout_13->addWidget(label_64, 4, 1, 1, 1);

        label_es_ampli2_fault = new QLabel(layoutWidget_5);
        label_es_ampli2_fault->setObjectName(QString::fromUtf8("label_es_ampli2_fault"));

        gridLayout_13->addWidget(label_es_ampli2_fault, 4, 2, 1, 1);

        label_65 = new QLabel(layoutWidget_5);
        label_65->setObjectName(QString::fromUtf8("label_65"));

        gridLayout_13->addWidget(label_65, 4, 3, 1, 1);

        layoutWidget_6 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_6->setObjectName(QString::fromUtf8("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(860, 160, 231, 131));
        gridLayout_14 = new QGridLayout(layoutWidget_6);
        gridLayout_14->setObjectName(QString::fromUtf8("gridLayout_14"));
        gridLayout_14->setContentsMargins(0, 0, 0, 0);
        label_tr_homed = new QLabel(layoutWidget_6);
        label_tr_homed->setObjectName(QString::fromUtf8("label_tr_homed"));

        gridLayout_14->addWidget(label_tr_homed, 0, 0, 1, 1);

        label_66 = new QLabel(layoutWidget_6);
        label_66->setObjectName(QString::fromUtf8("label_66"));

        gridLayout_14->addWidget(label_66, 0, 1, 1, 1);

        label_tr_soft_limitP = new QLabel(layoutWidget_6);
        label_tr_soft_limitP->setObjectName(QString::fromUtf8("label_tr_soft_limitP"));

        gridLayout_14->addWidget(label_tr_soft_limitP, 0, 2, 1, 1);

        label_67 = new QLabel(layoutWidget_6);
        label_67->setObjectName(QString::fromUtf8("label_67"));

        gridLayout_14->addWidget(label_67, 0, 3, 1, 1);

        label_tr_brake = new QLabel(layoutWidget_6);
        label_tr_brake->setObjectName(QString::fromUtf8("label_tr_brake"));

        gridLayout_14->addWidget(label_tr_brake, 1, 0, 1, 1);

        label_68 = new QLabel(layoutWidget_6);
        label_68->setObjectName(QString::fromUtf8("label_68"));

        gridLayout_14->addWidget(label_68, 1, 1, 1, 1);

        label_tr_soft_limitM = new QLabel(layoutWidget_6);
        label_tr_soft_limitM->setObjectName(QString::fromUtf8("label_tr_soft_limitM"));

        gridLayout_14->addWidget(label_tr_soft_limitM, 1, 2, 1, 1);

        label_69 = new QLabel(layoutWidget_6);
        label_69->setObjectName(QString::fromUtf8("label_69"));

        gridLayout_14->addWidget(label_69, 1, 3, 1, 1);

        label_tr_vel_limit = new QLabel(layoutWidget_6);
        label_tr_vel_limit->setObjectName(QString::fromUtf8("label_tr_vel_limit"));

        gridLayout_14->addWidget(label_tr_vel_limit, 2, 0, 1, 1);

        label_70 = new QLabel(layoutWidget_6);
        label_70->setObjectName(QString::fromUtf8("label_70"));

        gridLayout_14->addWidget(label_70, 2, 1, 1, 1);

        label_tr_hard_limitP = new QLabel(layoutWidget_6);
        label_tr_hard_limitP->setObjectName(QString::fromUtf8("label_tr_hard_limitP"));

        gridLayout_14->addWidget(label_tr_hard_limitP, 2, 2, 1, 1);

        label_71 = new QLabel(layoutWidget_6);
        label_71->setObjectName(QString::fromUtf8("label_71"));

        gridLayout_14->addWidget(label_71, 2, 3, 1, 1);

        label_tr_acc_limit = new QLabel(layoutWidget_6);
        label_tr_acc_limit->setObjectName(QString::fromUtf8("label_tr_acc_limit"));

        gridLayout_14->addWidget(label_tr_acc_limit, 3, 0, 1, 1);

        label_72 = new QLabel(layoutWidget_6);
        label_72->setObjectName(QString::fromUtf8("label_72"));

        gridLayout_14->addWidget(label_72, 3, 1, 1, 1);

        label_tr_hard_limitM = new QLabel(layoutWidget_6);
        label_tr_hard_limitM->setObjectName(QString::fromUtf8("label_tr_hard_limitM"));

        gridLayout_14->addWidget(label_tr_hard_limitM, 3, 2, 1, 1);

        label_73 = new QLabel(layoutWidget_6);
        label_73->setObjectName(QString::fromUtf8("label_73"));

        gridLayout_14->addWidget(label_73, 3, 3, 1, 1);

        label_tr_ampli1_fault = new QLabel(layoutWidget_6);
        label_tr_ampli1_fault->setObjectName(QString::fromUtf8("label_tr_ampli1_fault"));

        gridLayout_14->addWidget(label_tr_ampli1_fault, 4, 0, 1, 1);

        label_74 = new QLabel(layoutWidget_6);
        label_74->setObjectName(QString::fromUtf8("label_74"));

        gridLayout_14->addWidget(label_74, 4, 1, 1, 1);

        DirectM3->setWidget(scrollAreaWidgetContents);

        retranslateUi(DirectM3);
        QObject::connect(radioButton_ro_step_spec, SIGNAL(toggled(bool)), lineEdit_ro_step_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_es_step_spec, SIGNAL(toggled(bool)), lineEdit_es_step_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_tr_step_spec, SIGNAL(toggled(bool)), lineEdit_tr_step_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_ro_vel_spec, SIGNAL(toggled(bool)), lineEdit_ro_vel_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_ro_acc_spec, SIGNAL(toggled(bool)), lineEdit_ro_acc_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_es_vel_spec, SIGNAL(toggled(bool)), lineEdit_es_vel_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_es_acc_spec, SIGNAL(toggled(bool)), lineEdit_es_acc_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_tr_vel_spec, SIGNAL(toggled(bool)), lineEdit_tr_vel_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_tr_acc_spec, SIGNAL(toggled(bool)), lineEdit_tr_acc_spec, SLOT(setEnabled(bool)));

        QMetaObject::connectSlotsByName(DirectM3);
    } // setupUi

    void retranslateUi(QScrollArea *DirectM3)
    {
        DirectM3->setWindowTitle(QApplication::translate("DirectM3", "Direct M3", 0, QApplication::UnicodeUTF8));
        groupBox_16->setTitle(QApplication::translate("DirectM3", "Positionning", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("DirectM3", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("DirectM3", "\302\260", 0, QApplication::UnicodeUTF8));
        label_14->setText(QApplication::translate("DirectM3", "target point", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("DirectM3", "\342\200\262", 0, QApplication::UnicodeUTF8));
        pushButton_ro_go->setText(QApplication::translate("DirectM3", "Go", 0, QApplication::UnicodeUTF8));
        label_21->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600; color:#ff0000;\">ESCAPE</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        groupBox_13->setTitle(QApplication::translate("DirectM3", "Rotation status", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("DirectM3", "  Warning", 0, QApplication::UnicodeUTF8));
        pushButton_ro_warning->setText(QApplication::translate("DirectM3", "15", 0, QApplication::UnicodeUTF8));
        pushButton_ro_reset->setText(QApplication::translate("DirectM3", "Reset", 0, QApplication::UnicodeUTF8));
        label_ro_homed->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_homed->setText(QString());
        label_41->setText(QApplication::translate("DirectM3", "Homed", 0, QApplication::UnicodeUTF8));
        label_ro_soft_limitP->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_soft_limitP->setText(QString());
        label_42->setText(QApplication::translate("DirectM3", "Soft limit +", 0, QApplication::UnicodeUTF8));
        label_ro_brake->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_brake->setText(QString());
        label_44->setText(QApplication::translate("DirectM3", "Brake on", 0, QApplication::UnicodeUTF8));
        label_ro_soft_limitM->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_soft_limitM->setText(QString());
        label_45->setText(QApplication::translate("DirectM3", "Soft limit -", 0, QApplication::UnicodeUTF8));
        label_ro_vel_limit->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_vel_limit->setText(QString());
        label_47->setText(QApplication::translate("DirectM3", "Vel limit reached", 0, QApplication::UnicodeUTF8));
        label_ro_hard_limitP->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_hard_limitP->setText(QString());
        label_49->setText(QApplication::translate("DirectM3", "Hard limit +", 0, QApplication::UnicodeUTF8));
        label_ro_acc_limit->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_acc_limit->setText(QString());
        label_52->setText(QApplication::translate("DirectM3", "Acc limit reached", 0, QApplication::UnicodeUTF8));
        label_ro_hard_limitM->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_hard_limitM->setText(QString());
        label_53->setText(QApplication::translate("DirectM3", "Hard limit -", 0, QApplication::UnicodeUTF8));
        label_ro_ampli1_fault->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_ampli1_fault->setText(QString());
        label_54->setText(QApplication::translate("DirectM3", "Ampli1 fault", 0, QApplication::UnicodeUTF8));
        label_ro_ampli2_fault->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_ro_ampli2_fault->setText(QString());
        label_55->setText(QApplication::translate("DirectM3", "Ampli2 fault", 0, QApplication::UnicodeUTF8));
        groupBox_15->setTitle(QApplication::translate("DirectM3", "Acceleration ( \342\200\263/s)", 0, QApplication::UnicodeUTF8));
        radioButton_ro_acc_default->setText(QApplication::translate("DirectM3", "Default", 0, QApplication::UnicodeUTF8));
        label_43->setText(QApplication::translate("DirectM3", "000 ", 0, QApplication::UnicodeUTF8));
        radioButton_ro_acc_spec->setText(QApplication::translate("DirectM3", "Default", 0, QApplication::UnicodeUTF8));
        lineEdit_ro_acc_spec->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        groupBox_17->setTitle(QApplication::translate("DirectM3", "Continuous", 0, QApplication::UnicodeUTF8));
        pushButton_ro_dirM->setText(QApplication::translate("DirectM3", "- Dir", 0, QApplication::UnicodeUTF8));
        pushButton_ro_dirP->setText(QApplication::translate("DirectM3", "+ Dir", 0, QApplication::UnicodeUTF8));
        groupBox_20->setTitle(QApplication::translate("DirectM3", "Continuous", 0, QApplication::UnicodeUTF8));
        pushButton_es_dirM->setText(QApplication::translate("DirectM3", "- Dir", 0, QApplication::UnicodeUTF8));
        pushButton_es_dirP->setText(QApplication::translate("DirectM3", "+ Dir", 0, QApplication::UnicodeUTF8));
        pushButton_es_stop->setText(QApplication::translate("DirectM3", "STOP", 0, QApplication::UnicodeUTF8));
        groupBox_14->setTitle(QApplication::translate("DirectM3", "Velocity ( \342\200\263/s)", 0, QApplication::UnicodeUTF8));
        radioButton_ro_vel_fast->setText(QApplication::translate("DirectM3", "Fast", 0, QApplication::UnicodeUTF8));
        radioButton_ro_vel_mid->setText(QApplication::translate("DirectM3", "Mid", 0, QApplication::UnicodeUTF8));
        radioButton_ro_vel_slow->setText(QApplication::translate("DirectM3", "Slow", 0, QApplication::UnicodeUTF8));
        radioButton_ro_vel_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        lineEdit_ro_vel_spec->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600; color:#ff0000;\">ROTATION</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        groupBox_18->setTitle(QApplication::translate("DirectM3", "Step(Deg)", 0, QApplication::UnicodeUTF8));
        radioButton_ro_step1->setText(QApplication::translate("DirectM3", "1", 0, QApplication::UnicodeUTF8));
        pushButton_ro_stepM->setText(QApplication::translate("DirectM3", "Step -", 0, QApplication::UnicodeUTF8));
        radioButton_ro_step01->setText(QApplication::translate("DirectM3", "0.1", 0, QApplication::UnicodeUTF8));
        pushButton_ro_stepP->setText(QApplication::translate("DirectM3", "Step +", 0, QApplication::UnicodeUTF8));
        radioButton_ro_step001->setText(QApplication::translate("DirectM3", "0.01", 0, QApplication::UnicodeUTF8));
        radioButton_ro_step_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        pushButton_ro_stop->setText(QApplication::translate("DirectM3", "STOP", 0, QApplication::UnicodeUTF8));
        pushButton_ro_axis->setText(QApplication::translate("DirectM3", "Axis\n"
"Enabled", 0, QApplication::UnicodeUTF8));
        pushButton_ro_home->setText(QApplication::translate("DirectM3", "Home", 0, QApplication::UnicodeUTF8));
        pushButton_ro_park->setText(QApplication::translate("DirectM3", "Park", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("DirectM3", "Foci", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DirectM3", "Position", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DirectM3", "90", 0, QApplication::UnicodeUTF8));
        pushButton_ro_F2->setText(QApplication::translate("DirectM3", "Position Foc 2", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DirectM3", "180", 0, QApplication::UnicodeUTF8));
        pushButton_ro_F3->setText(QApplication::translate("DirectM3", "Position Foc 3", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("DirectM3", "270", 0, QApplication::UnicodeUTF8));
        pushButton_ro_F4->setText(QApplication::translate("DirectM3", "Position Foc 4", 0, QApplication::UnicodeUTF8));
        pushButton_ro_F1->setText(QApplication::translate("DirectM3", "Position Foc 1", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("DirectM3", "Foci", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("DirectM3", "Position", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("DirectM3", "12.79", 0, QApplication::UnicodeUTF8));
        pushButton_11->setText(QApplication::translate("DirectM3", "Position\n"
"ON", 0, QApplication::UnicodeUTF8));
        label_8->setText(QApplication::translate("DirectM3", "220.55", 0, QApplication::UnicodeUTF8));
        pushButton_12->setText(QApplication::translate("DirectM3", "Position\n"
"ESCAPE", 0, QApplication::UnicodeUTF8));
        groupBox_22->setTitle(QApplication::translate("DirectM3", "Step (mm)", 0, QApplication::UnicodeUTF8));
        radioButton_es_step1->setText(QApplication::translate("DirectM3", "1", 0, QApplication::UnicodeUTF8));
        pushButton_es_stepM->setText(QApplication::translate("DirectM3", "Step -", 0, QApplication::UnicodeUTF8));
        radioButton_es_step01->setText(QApplication::translate("DirectM3", "0.1", 0, QApplication::UnicodeUTF8));
        pushButton_es_stepP->setText(QApplication::translate("DirectM3", "Step +", 0, QApplication::UnicodeUTF8));
        radioButton_es_step001->setText(QApplication::translate("DirectM3", "0.01", 0, QApplication::UnicodeUTF8));
        radioButton_es_step_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_21->setTitle(QApplication::translate("DirectM3", "Velocity (mm/s)", 0, QApplication::UnicodeUTF8));
        radioButton_es_vel_fast->setText(QApplication::translate("DirectM3", "Fast", 0, QApplication::UnicodeUTF8));
        radioButton_es_vel_mid->setText(QApplication::translate("DirectM3", "Mid", 0, QApplication::UnicodeUTF8));
        radioButton_es_vel_slow->setText(QApplication::translate("DirectM3", "Slow", 0, QApplication::UnicodeUTF8));
        radioButton_es_vel_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_19->setTitle(QApplication::translate("DirectM3", "Escape status", 0, QApplication::UnicodeUTF8));
        label_17->setText(QApplication::translate("DirectM3", "  Warning", 0, QApplication::UnicodeUTF8));
        pushButton_es_warning->setText(QApplication::translate("DirectM3", "15", 0, QApplication::UnicodeUTF8));
        pushButton_es_reset->setText(QApplication::translate("DirectM3", "Reset", 0, QApplication::UnicodeUTF8));
        pushButton_es_axis->setText(QApplication::translate("DirectM3", "Axis\n"
"Enabled", 0, QApplication::UnicodeUTF8));
        pushButton_es_home->setText(QApplication::translate("DirectM3", "Home", 0, QApplication::UnicodeUTF8));
        pushButton_es_park->setText(QApplication::translate("DirectM3", "Park", 0, QApplication::UnicodeUTF8));
        groupBox_24->setTitle(QApplication::translate("DirectM3", "Acceleration (mm/s\302\262)", 0, QApplication::UnicodeUTF8));
        radioButton_es_acc_default->setText(QApplication::translate("DirectM3", "Default", 0, QApplication::UnicodeUTF8));
        label_46->setText(QApplication::translate("DirectM3", "TextLabel", 0, QApplication::UnicodeUTF8));
        radioButton_es_acc_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_23->setTitle(QApplication::translate("DirectM3", "Positionning", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("DirectM3", "target point", 0, QApplication::UnicodeUTF8));
        label_50->setText(QApplication::translate("DirectM3", "mm", 0, QApplication::UnicodeUTF8));
        pushButton_es_go->setText(QApplication::translate("DirectM3", "Go", 0, QApplication::UnicodeUTF8));
        groupBox_25->setTitle(QApplication::translate("DirectM3", "Velocity (mm/s)", 0, QApplication::UnicodeUTF8));
        radioButton_tr_vel_fast->setText(QApplication::translate("DirectM3", "Fast", 0, QApplication::UnicodeUTF8));
        radioButton_tr_vel_mid->setText(QApplication::translate("DirectM3", "Mid", 0, QApplication::UnicodeUTF8));
        radioButton_tr_vel_slow->setText(QApplication::translate("DirectM3", "Slow", 0, QApplication::UnicodeUTF8));
        radioButton_tr_vel_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_26->setTitle(QApplication::translate("DirectM3", "Continuous", 0, QApplication::UnicodeUTF8));
        pushButton_tr_dirM->setText(QApplication::translate("DirectM3", "- Dir", 0, QApplication::UnicodeUTF8));
        pushButton_tr_dirP->setText(QApplication::translate("DirectM3", "+ Dir", 0, QApplication::UnicodeUTF8));
        groupBox_27->setTitle(QApplication::translate("DirectM3", "Positionning", 0, QApplication::UnicodeUTF8));
        label_29->setText(QApplication::translate("DirectM3", "target point", 0, QApplication::UnicodeUTF8));
        label_51->setText(QApplication::translate("DirectM3", "mm", 0, QApplication::UnicodeUTF8));
        pushButton_tr_go->setText(QApplication::translate("DirectM3", "Go", 0, QApplication::UnicodeUTF8));
        groupBox_28->setTitle(QApplication::translate("DirectM3", "Step (mm)", 0, QApplication::UnicodeUTF8));
        radioButton_tr_step1->setText(QApplication::translate("DirectM3", "1", 0, QApplication::UnicodeUTF8));
        pushButton_tr_stepM->setText(QApplication::translate("DirectM3", "Step -", 0, QApplication::UnicodeUTF8));
        radioButton_tr_step01->setText(QApplication::translate("DirectM3", "0.1", 0, QApplication::UnicodeUTF8));
        pushButton_tr_stepP->setText(QApplication::translate("DirectM3", "Step +", 0, QApplication::UnicodeUTF8));
        radioButton_tr_step001->setText(QApplication::translate("DirectM3", "0.01", 0, QApplication::UnicodeUTF8));
        radioButton_tr_step_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        pushButton_tr_stop->setText(QApplication::translate("DirectM3", "STOP", 0, QApplication::UnicodeUTF8));
        label_30->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600; color:#ff0000;\">TRANSLATION</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        groupBox_29->setTitle(QApplication::translate("DirectM3", "Rotation status", 0, QApplication::UnicodeUTF8));
        label_31->setText(QApplication::translate("DirectM3", "  Warning", 0, QApplication::UnicodeUTF8));
        pushButton_tr_warning->setText(QApplication::translate("DirectM3", "15", 0, QApplication::UnicodeUTF8));
        pushButton_tr_reset->setText(QApplication::translate("DirectM3", "Reset", 0, QApplication::UnicodeUTF8));
        groupBox_30->setTitle(QApplication::translate("DirectM3", "Acceleration (mm/s\302\262)", 0, QApplication::UnicodeUTF8));
        radioButton_tr_acc_default->setText(QApplication::translate("DirectM3", "Default", 0, QApplication::UnicodeUTF8));
        label_48->setText(QApplication::translate("DirectM3", "TextLabel", 0, QApplication::UnicodeUTF8));
        radioButton_tr_acc_spec->setText(QApplication::translate("DirectM3", "Specified", 0, QApplication::UnicodeUTF8));
        pushButton_tr_axis->setText(QApplication::translate("DirectM3", "Axis\n"
"Enabled", 0, QApplication::UnicodeUTF8));
        pushButton_tr_home->setText(QApplication::translate("DirectM3", "Home", 0, QApplication::UnicodeUTF8));
        pushButton_tr_park->setText(QApplication::translate("DirectM3", "Park", 0, QApplication::UnicodeUTF8));
        label_22->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Position:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_ro_posD->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_38->setText(QApplication::translate("DirectM3", "\302\260", 0, QApplication::UnicodeUTF8));
        lineEdit_pos_posM->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_33->setText(QApplication::translate("DirectM3", "\342\200\262", 0, QApplication::UnicodeUTF8));
        lineEdit_ro_posS->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_32->setText(QApplication::translate("DirectM3", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_23->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Velocity:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_ro_vel->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_37->setText(QApplication::translate("DirectM3", "\"/s", 0, QApplication::UnicodeUTF8));
        label_24->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Pos error:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_ro_poserr->setText(QApplication::translate("DirectM3", "0", 0, QApplication::UnicodeUTF8));
        label_36->setText(QApplication::translate("DirectM3", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_18->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Position:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_15->setText(QApplication::translate("DirectM3", "mm", 0, QApplication::UnicodeUTF8));
        label_19->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Velocity:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_34->setText(QApplication::translate("DirectM3", "mm/s", 0, QApplication::UnicodeUTF8));
        label_20->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Pos error:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_25->setText(QApplication::translate("DirectM3", "mm", 0, QApplication::UnicodeUTF8));
        label_26->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Position:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_39->setText(QApplication::translate("DirectM3", "mm", 0, QApplication::UnicodeUTF8));
        label_27->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Velocity:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_40->setText(QApplication::translate("DirectM3", "mm/s", 0, QApplication::UnicodeUTF8));
        label_28->setText(QApplication::translate("DirectM3", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Pos error:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_35->setText(QApplication::translate("DirectM3", "mm", 0, QApplication::UnicodeUTF8));
        label_es_homed->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_es_homed->setText(QString());
        label_56->setText(QApplication::translate("DirectM3", "Homed", 0, QApplication::UnicodeUTF8));
        label_es_soft_limitP->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_soft_limitP->setText(QString());
        label_57->setText(QApplication::translate("DirectM3", "Soft limit +", 0, QApplication::UnicodeUTF8));
        label_es_brake->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_es_brake->setText(QString());
        label_58->setText(QApplication::translate("DirectM3", "Brake on", 0, QApplication::UnicodeUTF8));
        label_es_soft_limitM->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_soft_limitM->setText(QString());
        label_59->setText(QApplication::translate("DirectM3", "Soft limit -", 0, QApplication::UnicodeUTF8));
        label_es_vel_limit->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_vel_limit->setText(QString());
        label_60->setText(QApplication::translate("DirectM3", "Vel limit reached", 0, QApplication::UnicodeUTF8));
        label_es_hard_limitP->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_hard_limitP->setText(QString());
        label_61->setText(QApplication::translate("DirectM3", "Hard limit +", 0, QApplication::UnicodeUTF8));
        label_es_acc_limit->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_acc_limit->setText(QString());
        label_62->setText(QApplication::translate("DirectM3", "Acc limit reached", 0, QApplication::UnicodeUTF8));
        label_es_hard_limitM->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_hard_limitM->setText(QString());
        label_63->setText(QApplication::translate("DirectM3", "Hard limit -", 0, QApplication::UnicodeUTF8));
        label_es_ampli1_fault->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_ampli1_fault->setText(QString());
        label_64->setText(QApplication::translate("DirectM3", "Ampli1 fault", 0, QApplication::UnicodeUTF8));
        label_es_ampli2_fault->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_es_ampli2_fault->setText(QString());
        label_65->setText(QApplication::translate("DirectM3", "Ampli2 fault", 0, QApplication::UnicodeUTF8));
        label_tr_homed->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_homed->setText(QString());
        label_66->setText(QApplication::translate("DirectM3", "Homed", 0, QApplication::UnicodeUTF8));
        label_tr_soft_limitP->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_soft_limitP->setText(QString());
        label_67->setText(QApplication::translate("DirectM3", "Soft limit +", 0, QApplication::UnicodeUTF8));
        label_tr_brake->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_brake->setText(QString());
        label_68->setText(QApplication::translate("DirectM3", "Brake on", 0, QApplication::UnicodeUTF8));
        label_tr_soft_limitM->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_soft_limitM->setText(QString());
        label_69->setText(QApplication::translate("DirectM3", "Soft limit -", 0, QApplication::UnicodeUTF8));
        label_tr_vel_limit->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_vel_limit->setText(QString());
        label_70->setText(QApplication::translate("DirectM3", "Vel limit reached", 0, QApplication::UnicodeUTF8));
        label_tr_hard_limitP->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_hard_limitP->setText(QString());
        label_71->setText(QApplication::translate("DirectM3", "Hard limit +", 0, QApplication::UnicodeUTF8));
        label_tr_acc_limit->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_acc_limit->setText(QString());
        label_72->setText(QApplication::translate("DirectM3", "Acc limit reached", 0, QApplication::UnicodeUTF8));
        label_tr_hard_limitM->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_hard_limitM->setText(QString());
        label_73->setText(QApplication::translate("DirectM3", "Hard limit -", 0, QApplication::UnicodeUTF8));
        label_tr_ampli1_fault->setStyleSheet(QApplication::translate("DirectM3", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tr_ampli1_fault->setText(QString());
        label_74->setText(QApplication::translate("DirectM3", "Ampli1 fault", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(DirectM3);
    } // retranslateUi

};

namespace Ui {
    class DirectM3: public Ui_DirectM3 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIRECT_M3_H
