/***************************************************************************
 *   Copyright (C) 2009 by donglongchao   *
 *   donglongchao@163.com   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include "main_window.h"
#include "direct_azalt.h"
#include "direct_m3.h"
#include "direct_m2.h"
#include "tracking.h"
#include "diag_m2.h"
#include "diag_azalt.h"
#include "terminal.h"
#include "UMAC.h"
#include "server.h"
#include "signs.h"

MainWindow::MainWindow ( QWidget *parent ) :QMainWindow ( parent )
{
	setupUi ( this );
	setAttribute ( Qt::WA_DeleteOnClose );//very important to avoid memory leak

	direct_azalt = NULL;
	tracking = NULL;
	timer = new QTimer;
	server = new Server(this);
	if(!server->listen(QHostAddress::LocalHost,5001))
		qDebug("Server start error!");
//	connect(server, SIGNAL(newConnection()), this, SLOT(onComingConnection()));

	SMySetting::instance_p()->beginGroup ( "main_window" );
	resize ( SMySetting::instance_p()->value ( "size" ).toSize() );
	move ( SMySetting::instance_p()->value ( "pos" ).toPoint() );
	SMySetting::instance_p()->endGroup();

//	model_ocs = new QStandardItemModel(10,2,this);
//	
// 	for(int row = 0;row < 10;++row)
// 		for(int column = 0;column < 2;++column)
// 		{
// 		QStandardItem *item = new QStandardItem(QString("0"));
// 		model_ocs->setItem(row,column,item);
// 		}
	model_ocs = new QStandardItemModel(0,0,this);
	tableView_ocs->setModel(model_ocs);

	QStringList ocs_head = QStringList();
	ocs_head  << "Time" << "Received Data (Etherent)";
	model_ocs->setHorizontalHeaderLabels(ocs_head);
	tableView_ocs->setColumnWidth(1,800);
	tableView_ocs->setColumnWidth(0,200);

//	model_tcs = new QStandardItemModel(10,9,this);
// 	for(int row = 0;row < 10;++row)
// 		for(int column = 0;column < 10;++column)
// 		{
// 		QStandardItem *item = new QStandardItem(QString("0"));
// 		model_tcs->setItem(row,column,item);
// 		}
	model_tcs = new QStandardItemModel(0,0,this);
	tableView_tcs->setModel(model_tcs);
	
	QStringList tcs_head = QStringList();
	tcs_head << "Time"<< "AZ Target" << "Position" << "Error" << "ALT Target" << "Position" << "Error" << "DERO Target" << "Position" << "Error";
	model_tcs->setHorizontalHeaderLabels(tcs_head);
	tableView_tcs->setColumnWidth(0,200);
	connect ( this,SIGNAL ( startDirectAzaltOCS() ), actionAz_Alt,SIGNAL ( triggered() ) );
	connect ( this,SIGNAL ( startTrackingOCS() ), actionTracking,SIGNAL ( triggered() ) );
	connect ( actionAz_Alt,SIGNAL ( triggered() ),this,SLOT ( startDirectAzalt() ) );
	connect ( actionM3,SIGNAL ( triggered() ),this,SLOT ( startDirectM3() ) );
	connect ( actionM2,SIGNAL ( triggered() ),this,SLOT ( startDirectM2() ) );
	connect ( actionTracking,SIGNAL ( triggered() ),this,SLOT ( startTracking() ) );
	connect ( actionM2_D,SIGNAL ( triggered() ),this,SLOT ( startDiagM2() ) );
	connect ( actionAz_Alt_D,SIGNAL ( triggered() ),this,SLOT ( startDiagAzalt() ) );
	connect ( actionTerminal,SIGNAL ( triggered() ),this,SLOT ( startTerminal() ) );
}

MainWindow::~MainWindow()
{
	qDebug("MainWindow");
	deleteLater();
	timer->deleteLater();
	server->deleteLater();
//	service->exit(0);usleep(0);//important ,to wait the destrocurtor of service
//	service->deleteLater();
//	service->wait();
}

void MainWindow::closeEvent ( QCloseEvent *event )
{
	QMessageBox mb ( QMessageBox::Question,tr ( "About to close" ),
	                 tr ( "Do you want to close?      " ),
	                 QMessageBox::Yes |QMessageBox::No |QMessageBox::Cancel );
	if ( mb.exec() == QMessageBox::Yes )
	{
		SMySetting::instance_p()->beginGroup ( "main_window" );
		SMySetting::instance_p()->setValue ( "size",size() );
		SMySetting::instance_p()->setValue ( "pos",pos() );
		SMySetting::instance_p()->endGroup();
		return;
	}
	event->ignore();
}

void MainWindow::updateInterface(QHash<QString,QString> info_track)
{
	QDateTime dt=QDateTime::currentDateTime();
	QString dtstr;
	dtstr=dt.toString ( "yyyy-MM-dd hh:mm:ss" );

	QList<QStandardItem*> items_tcs;
	qDebug() <<info_track["AZ_TARGET"];
	items_tcs << new QStandardItem(dtstr) << new QStandardItem(info_track["AZ_TARGET"]) << new QStandardItem(info_track["AZ_POSITION"]) << new QStandardItem(info_track["AZ_ERROR"]) << new QStandardItem(info_track["ALT_TARGET"]) << new QStandardItem(info_track["ALT_POSITION"]) << new QStandardItem(info_track["ALT_ERROR"]);
	model_tcs->appendRow(items_tcs);
//	QModelIndex index = model_tcs->index(model_tcs->rowCount(),model_tcs->columnCount());
//	qDebug() << index.column();
//	tableView_tcs->setCurrentIndex(model_tcs->index(model_tcs->rowCount()-1,0));

	tableView_tcs->scrollTo(model_tcs->index(model_tcs->rowCount()-1,0)/*,QAbstractItemView::PositionAtBottom*/);
}

void MainWindow::showInfoOCS(QHash<QString,QString> infoOCS)
{
	QDateTime dt=QDateTime::currentDateTime();
	QString dtstr;
	dtstr=dt.toString ( "yyyy-MM-dd hh:mm:ss" );
	cmd=infoOCS["CMD"];
	QList<QStandardItem*> items_ocs;
	items_ocs << new QStandardItem(dtstr) << new QStandardItem(cmd);
	model_ocs->appendRow(items_ocs);	
	tableView_ocs->scrollToBottom();
	if(cmd==CHECK_AZ || cmd==START_AZ || cmd==STOP_AZ || cmd==CHECK_ALT || cmd==START_ALT || cmd==STOP_ALT)
		{emit startDirectAzaltOCS();
		return direct_azalt->cmdOCS(infoOCS);}
	else if (cmd==CHECK_DERO || cmd==START_DERO || cmd==STOP_DERO)
		return ;
	else if(cmd==START_TRACK || cmd==STOP_TRACK)
		{emit startTrackingOCS();emit startDirectAzaltOCS();
		return tracking->cmdOCS(infoOCS);}
	else qDebug("Invalid cmd");
}

void MainWindow::startDirectAzalt(QString str)
{
//
	try
	{
//		std::auto_ptr<DirectAzalt> temp(new DirectAzalt ( this ));
//		direct_azalt = temp;
		direct_azalt = new DirectAzalt ( this );
	}
	catch ( QString excepts )
	{
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
		                 tr ( excepts.toAscii() ),
		                 QMessageBox::Ok );

		QString s_temp;
		QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );

		s_temp = QString("<RelatedCmdCUID=")+cmd;
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=START><bExeStatus=true>" );
		server->writeData(s_temp);
		
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( direct_azalt/*.get()*/ );
	direct_azalt->show();
	disconnect ( actionAz_Alt,SIGNAL ( triggered() ),this,SLOT ( startDirectAzalt() ) );
	connect ( actionAz_Alt,SIGNAL ( triggered() ),direct_azalt->parentWidget(),SLOT ( showNormal() ) );
}
void MainWindow::startDirectM3()
{
	try
	{
		direct_m3 = new DirectM3 ( this );
	}
	catch ( QString excepts )
	{
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
	                         tr ( excepts.toAscii() ),
//		                 tr ( "unknown error or excepts" ),
		                 QMessageBox::Ok );
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( direct_m3 );
	direct_m3->show();
	disconnect ( actionM3,SIGNAL ( triggered() ),this,SLOT ( startDirectM3() ) );
	connect ( actionM3,SIGNAL ( triggered() ),direct_m3->parentWidget(),SLOT ( showNormal() ) );
}

void MainWindow::startDirectM2()
{
//
	try
	{
		direct_m2 = new DirectM2 ( this );
	}
	catch ( QString excepts )
	{
		qDebug() << "catch";
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
		                 tr ( excepts.toAscii() ),
		                 QMessageBox::Ok );
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( direct_m2 );
	direct_m2->show();
	disconnect ( actionM2,SIGNAL ( triggered() ),this,SLOT ( startDirectM2() ) );
	connect ( actionM2,SIGNAL ( triggered() ),direct_m2->parentWidget(),SLOT ( showNormal() ) );
}

void MainWindow::startTracking(QString str)
{
//
	try
	{
		tracking = new Tracking ( this );
	}
	catch ( QString excepts )
	{
		qDebug() << "catch";
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
		                 tr ( excepts.toAscii() ),
		                 QMessageBox::Ok );
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( tracking );
	tracking->show();
	disconnect ( actionTracking,SIGNAL ( triggered() ),this,SLOT ( startTracking() ) );
	connect ( actionTracking,SIGNAL ( triggered() ),tracking->parentWidget(),SLOT ( showNormal() ) );
}

void MainWindow::startDiagM2()
{
//
	try
	{
		diag_m2 = new DiagM2 ( this );
	}
	catch ( QString excepts )
	{
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
		                 tr ( excepts.toAscii() ),
		                 QMessageBox::Ok );
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( diag_m2 );
	diag_m2->show();
	disconnect ( actionM2_D,SIGNAL ( triggered() ),this,SLOT ( startDiagM2() ) );
	connect ( actionM2_D,SIGNAL ( triggered() ),diag_m2->parentWidget(),SLOT ( showNormal() ) );
}

void MainWindow::startDiagAzalt()
{
//
	try
	{
		diag_azalt = new DiagAzalt ( this );
	}
	catch ( QString excepts )
	{
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
		                 tr ( excepts.toAscii() ),
		                 QMessageBox::Ok );
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( diag_azalt );
	diag_azalt->show();
	disconnect ( actionAz_Alt_D,SIGNAL ( triggered() ),this,SLOT ( startDiagAzalt() ) );
	connect ( actionAz_Alt_D,SIGNAL ( triggered() ),diag_azalt->parentWidget(),SLOT ( showNormal() ) );
}

void MainWindow::startTerminal()
{
//
	try
	{
		terminal = new Terminal ( this );
	}
	catch ( QString excepts )
	{
		QMessageBox mb ( QMessageBox::Warning,
		                 tr ( "About to close" ),
		                 tr ( excepts.toAscii() ),
		                 QMessageBox::Ok );
		if ( mb.exec() ==QMessageBox::Ok )
			return;
	}
	mdiArea->addSubWindow ( terminal );
	terminal->show();
	disconnect ( actionTerminal,SIGNAL ( triggered() ),this,SLOT ( startTerminal() ) );
	connect ( actionTerminal,SIGNAL ( triggered() ),terminal->parentWidget(),SLOT ( showNormal() ) );
}

void MainWindow::on_actionWindows_triggered()
{
	timer->start(10);
	QApplication::setStyle(new QWindowsStyle);
}

void MainWindow::on_actionMotif_triggered()
{
	QApplication::setStyle(new QMotifStyle);
}

void MainWindow::on_actionGtk_triggered()
{
	QApplication::setStyle(new QGtkStyle);
}

void MainWindow::on_actionCDE_triggered()
{
	QApplication::setStyle(new QCDEStyle);
}

