//
// C++ Implementation: server
//
// Description:
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "server.h"
#include "main_window.h"

Server::Server(MainWindow *parent)
{
	m_parent = parent;
	tcp_socket = new QTcpSocket(this);
//	connect( tcp_socket,SIGNAL(connected()),this,SLOT(showConnected()));
	connect ( tcp_socket, SIGNAL ( readyRead() ), this, SLOT ( readData() ) );
	connect ( tcp_socket, SIGNAL ( error ( QAbstractSocket::SocketError ) ),this, SLOT ( showError ( QAbstractSocket::SocketError ) ) );
//	connect(parent->timer,SIGNAL(timeout()),this,SLOT(writeData()));
}

Server::~Server()
{
	delete tcp_socket;
}

int Server::isPackageBroken(QDataStream& in)
{
	quint16 block_size;
	if ( tcp_socket->bytesAvailable() < ( int ) sizeof ( quint16 ) )//You must make sure that enough data is available before attempting to read it using operator>>().
			return 1;
	in >> block_size;
	qDebug() << block_size;
	if ( tcp_socket->bytesAvailable() < block_size )
		return 1;//some error happen here.
	return 0;
}

void Server::incomingConnection ( int socket_descriptor )
{
	tcp_socket->setSocketDescriptor (  socket_descriptor);
	qDebug("server incoming");
//	ServerThread *thread = new ServerThread ( socketDescriptor );
//	connect ( thread, SIGNAL ( finished() ), thread, SLOT ( deleteLater() ) );
//	thread->start();
}
void Server::readData()
{
	QHash<QString,QString> hash;
//	QByteArray data = tcp_socket->readAll();
//	QDataStream in ( &data ,QIODevice::ReadOnly );
	QDataStream in ( tcp_socket /*,QIODevice::ReadWrite */);
	in.setVersion ( QDataStream::Qt_4_0 );
	if(isPackageBroken(in))
	{
		throw QString("Package Broken.");
	}
	
	in >> hash;
	qDebug() << hash["CMD"];
	
	m_parent->showInfoOCS(hash);
}

void Server::writeData(QString data)
{
	static int i = 0;
	QByteArray response;
	QDataStream out(&response,QIODevice::WriteOnly);
	out.setVersion ( QDataStream::Qt_4_0 );
	out << (quint16)0;
	out << data;
	out.device()->seek(0);
	out << ( quint16 ) ( response.size() - sizeof ( quint16 ) );
	tcp_socket->write(response);
}

void Server::showError ( QAbstractSocket::SocketError socketError )
{
	switch ( socketError )
	{
		case QAbstractSocket::RemoteHostClosedError:
			break;
		case QAbstractSocket::HostNotFoundError:
			QMessageBox::information ( m_parent, tr ( "Fortune Client" ),
			                           tr ( "The host was not found. Please check the "
			                                "host name and port settings." ) );
			break;
		case QAbstractSocket::ConnectionRefusedError:
			QMessageBox::information ( m_parent, tr ( "Fortune Client" ),
			                           tr ( "The connection was refused by the peer. "
			                                "Make sure the fortune server is running, "
			                                "and check that the host name and port "
			                                "settings are correct." ) );
			break;
		default:
			QMessageBox::information ( m_parent, tr ( "Fortune Client" ),
			                           tr ( "The following error occurred: %1." )
			                           .arg ( tcp_socket->errorString() ) );
	}

}

ServerThread::ServerThread ( int socketDescriptor ) :socket_fd ( socketDescriptor )
{

}

ServerThread::~ServerThread()
{

}

void ServerThread::run()
{	
	QString str;
	qDebug("bg");
	QTcpSocket tcpSocket;
	if ( !tcpSocket.setSocketDescriptor ( socket_fd ) )
	{
		return;
	}

	QByteArray block;
	block = tcpSocket.readAll();
	QDataStream out ( &block, QIODevice::ReadWrite );
	out.setVersion ( QDataStream::Qt_4_0 );
// 	out << ( quint16 ) 5;
// 	out << QString("This is message....ddd");
// 	out.device()->seek ( 0 );
// 	qDebug() << block.size();
// 	out << ( quint16 ) ( block.size() - sizeof ( quint16 ) );
// 	tcpSocket.write ( block );
// 	tcpSocket.disconnectFromHost();
// 	tcpSocket.waitForDisconnected();
	out >> str;
	qDebug() << str;

}
