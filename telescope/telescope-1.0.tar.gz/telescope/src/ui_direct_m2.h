/********************************************************************************
** Form generated from reading ui file 'direct_m2.ui'
**
** Created: Fri Feb 26 15:05:28 2010
**      by: Qt User Interface Compiler version 4.5.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_DIRECT_M2_H
#define UI_DIRECT_M2_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QRadioButton>
#include <QtGui/QScrollArea>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DirectM2
{
public:
    QWidget *scrollAreaWidgetContents;
    QGroupBox *groupBox_16;
    QPushButton *pushButton_tz_go;
    QLabel *label_12;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_22;
    QLineEdit *lineEdit_tz_target;
    QLabel *label_10;
    QLabel *label_21;
    QGroupBox *groupBox_13;
    QWidget *layoutWidget_9;
    QVBoxLayout *verticalLayout_5;
    QLabel *label_16;
    QPushButton *pushButton_tz_warning;
    QSpacerItem *verticalSpacer_4;
    QPushButton *pushButton_tz_reset;
    QWidget *layoutWidget_5;
    QGridLayout *gridLayout_12;
    QLabel *label_tz_homed;
    QLabel *label_41;
    QLabel *label_tz_soft_limitP;
    QLabel *label_42;
    QLabel *label_tz_brake;
    QLabel *label_44;
    QLabel *label_tz_soft_limitM;
    QLabel *label_45;
    QLabel *label_tz_vel_limit;
    QLabel *label_47;
    QLabel *label_tz_hard_limitP;
    QLabel *label_49;
    QLabel *label_tz_acc_limit;
    QLabel *label_52;
    QLabel *label_tz_hard_limitM;
    QLabel *label_53;
    QGroupBox *groupBox_15;
    QWidget *layoutWidget1;
    QGridLayout *gridLayout_5;
    QRadioButton *radioButton_tz_acc_default;
    QLabel *label_43;
    QRadioButton *radioButton_tz_acc_spec;
    QLineEdit *lineEdit_tz_acc_spec;
    QGroupBox *groupBox_17;
    QWidget *layoutWidget_13;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_tz_dirM;
    QPushButton *pushButton_tz_dirP;
    QGroupBox *groupBox_20;
    QWidget *layoutWidget_17;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *pushButton_alpha1_dirM;
    QPushButton *pushButton_alpha1_dirP;
    QPushButton *pushButton_alpha1_stop;
    QGroupBox *groupBox_14;
    QWidget *layoutWidget2;
    QGridLayout *gridLayout_4;
    QRadioButton *radioButton_tz_vel_fast;
    QRadioButton *radioButton_tz_vel_mid;
    QRadioButton *radioButton_tz_vel_slow;
    QRadioButton *radioButton_tz_vel_spec;
    QLineEdit *lineEdit_tz_vel_spec;
    QLabel *label_11;
    QGroupBox *groupBox_18;
    QWidget *layoutWidget_14;
    QGridLayout *gridLayout_16;
    QRadioButton *radioButton_tz_step1;
    QPushButton *pushButton_tz_stepM;
    QRadioButton *radioButton_tz_step01;
    QPushButton *pushButton_tz_stepP;
    QRadioButton *radioButton_tz_step001;
    QRadioButton *radioButton_tz_step_spec;
    QLineEdit *lineEdit_tz_step_spec;
    QPushButton *pushButton_tz_stop;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *pushButton_tz_axis;
    QPushButton *pushButton_tz_home;
    QPushButton *pushButton_tz_park;
    QGroupBox *groupBox_22;
    QWidget *layoutWidget_19;
    QGridLayout *gridLayout_19;
    QRadioButton *radioButton_alpha1_step1;
    QPushButton *pushButton_alpha1_stepM;
    QRadioButton *radioButton_alpha1_step01;
    QPushButton *pushButton_alpha1_stepP;
    QRadioButton *radioButton_alpha1_step001;
    QRadioButton *radioButton_alpha1_step_spec;
    QLineEdit *lineEdit_alpha1_step_spec;
    QGroupBox *groupBox_21;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout_6;
    QRadioButton *radioButton_alpha1_vel_fast;
    QRadioButton *radioButton_alpha1_vel_mid;
    QRadioButton *radioButton_alpha1_vel_slow;
    QRadioButton *radioButton_alpha1_vel_spec;
    QLineEdit *lineEdit_alpha1_vel_spec;
    QGroupBox *groupBox_19;
    QWidget *layoutWidget_16;
    QVBoxLayout *verticalLayout_7;
    QLabel *label_17;
    QPushButton *pushButton_alpha1_warning;
    QSpacerItem *verticalSpacer_5;
    QPushButton *pushButton_alpha1_reset;
    QWidget *layoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_2;
    QPushButton *pushButton_alpha1_axis;
    QPushButton *pushButton_alpha1_home_2;
    QPushButton *pushButton_alpha1_park_2;
    QGroupBox *groupBox_24;
    QWidget *layoutWidget5;
    QGridLayout *gridLayout_7;
    QRadioButton *radioButton_alpha1_acc_default;
    QLabel *label_46;
    QRadioButton *radioButton_alpha1_acc_spec;
    QLineEdit *lineEdit_alpha1_acc_spec;
    QGroupBox *groupBox_23;
    QLineEdit *lineEdit_alpha1_targetM;
    QLineEdit *lineEdit_alpha1_targetS;
    QLabel *label_2;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_13;
    QPushButton *pushButton_alpha1_go;
    QLineEdit *lineEdit_alpha1_targetD;
    QGroupBox *groupBox_25;
    QWidget *layoutWidget_25;
    QVBoxLayout *verticalLayout_9;
    QLabel *label_25;
    QPushButton *pushButton_alpha2_warning;
    QSpacerItem *verticalSpacer_6;
    QPushButton *pushButton_alpha2_reset;
    QPushButton *pushButton_alpha2_stop;
    QGroupBox *groupBox_26;
    QWidget *layoutWidget_27;
    QGridLayout *gridLayout_25;
    QRadioButton *radioButton_alpha2_step1;
    QPushButton *pushButton_alpha2_stepM;
    QRadioButton *radioButton_alpha2_step01;
    QPushButton *pushButton_alpha2_stepP;
    QRadioButton *radioButton_alpha2_step001;
    QRadioButton *radioButton_alpha2_step_spec;
    QLineEdit *lineEdit_alpha2_step_spec;
    QGroupBox *groupBox_27;
    QWidget *layoutWidget6;
    QGridLayout *gridLayout_8;
    QRadioButton *radioButton_alpha2_vel_fast;
    QRadioButton *radioButton_alpha2_vel_mid;
    QRadioButton *radioButton_alpha2_vel_slow;
    QRadioButton *radioButton_alpha2_vel_spec;
    QLineEdit *lineEdit_alpha2_vel_spec;
    QWidget *layoutWidget_3;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_6;
    QPushButton *pushButton_alpha2_axis;
    QPushButton *pushButton_alpha2_home;
    QPushButton *pushButton_alpha2_park;
    QGroupBox *groupBox_28;
    QWidget *layoutWidget_29;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButton_alpha2_dirM;
    QPushButton *pushButton_alpha2_dirP;
    QGroupBox *groupBox_29;
    QWidget *layoutWidget7;
    QGridLayout *gridLayout_9;
    QRadioButton *radioButton_alpha2_acc_default;
    QLabel *label_48;
    QRadioButton *radioButton_alpha2_acc_spec;
    QLineEdit *lineEdit_alpha2_acc_spec;
    QGroupBox *groupBox_30;
    QLineEdit *lineEdit_alpha2_targetD;
    QLabel *label_4;
    QLineEdit *lineEdit_alpha2_targetS;
    QLineEdit *lineEdit_alpha2_targetM;
    QLabel *label_5;
    QLabel *label_14;
    QLabel *label_6;
    QPushButton *pushButton_alpha2_go;
    QLabel *label_29;
    QWidget *layoutWidget8;
    QGridLayout *gridLayout;
    QLabel *label_22;
    QHBoxLayout *horizontalLayout_7;
    QLineEdit *lineEdit_tz_pos;
    QLabel *label_7;
    QLabel *label_23;
    QHBoxLayout *horizontalLayout_9;
    QLineEdit *lineEdit_tz_vel;
    QLabel *label_9;
    QLabel *label_24;
    QHBoxLayout *horizontalLayout_8;
    QLineEdit *lineEdit_tz_poserr;
    QLabel *label_8;
    QSpacerItem *horizontalSpacer_4;
    QWidget *layoutWidget9;
    QGridLayout *gridLayout_2;
    QLabel *label_18;
    QHBoxLayout *horizontalLayout_10;
    QLineEdit *lineEdit_alpha1_posM;
    QLabel *label_37;
    QHBoxLayout *horizontalLayout_11;
    QLineEdit *lineEdit_alpha1_posS;
    QLabel *label_35;
    QLabel *label_19;
    QHBoxLayout *horizontalLayout_15;
    QLineEdit *lineEdit_alpha1_velS;
    QLabel *label_31;
    QLabel *label_20;
    QHBoxLayout *horizontalLayout_12;
    QLineEdit *lineEdit_alpha1_poserrS;
    QLabel *label_34;
    QSpacerItem *horizontalSpacer_3;
    QWidget *layoutWidget_4;
    QGridLayout *gridLayout_3;
    QLabel *label_26;
    QHBoxLayout *horizontalLayout_13;
    QLineEdit *lineEdit_alpha2_posM;
    QLabel *label_38;
    QHBoxLayout *horizontalLayout_14;
    QLineEdit *lineEdit_alpha2_posS;
    QLabel *label_36;
    QLabel *label_27;
    QHBoxLayout *horizontalLayout_16;
    QLineEdit *lineEdit_alpha2_velS;
    QLabel *label_32;
    QLabel *label_28;
    QHBoxLayout *horizontalLayout_17;
    QLineEdit *lineEdit_alpha2_poserrS;
    QLabel *label_39;
    QSpacerItem *horizontalSpacer_5;
    QWidget *layoutWidget_6;
    QGridLayout *gridLayout_15;
    QLabel *label_alpha1_homed;
    QLabel *label_54;
    QLabel *label_alpha1_soft_limitP;
    QLabel *label_55;
    QLabel *label_alpha1_soft_limitM;
    QLabel *label_75;
    QLabel *label_alpha1_vel_limit;
    QLabel *label_76;
    QLabel *label_alpha1_hard_limitP;
    QLabel *label_77;
    QLabel *label_alpha1_acc_limit;
    QLabel *label_78;
    QLabel *label_alpha1_hard_limitM;
    QLabel *label_79;
    QWidget *layoutWidget_7;
    QGridLayout *gridLayout_17;
    QLabel *label_alpha2_homed;
    QLabel *label_80;
    QLabel *label_alpha2_soft_limitP;
    QLabel *label_81;
    QLabel *label_alpha2_soft_limitM;
    QLabel *label_83;
    QLabel *label_alpha2_vel_limit;
    QLabel *label_84;
    QLabel *label_alpha2_hard_limitP;
    QLabel *label_85;
    QLabel *label_alpha2_acc_limit;
    QLabel *label_86;
    QLabel *label_alpha2_hard_limitM;
    QLabel *label_87;

    void setupUi(QScrollArea *DirectM2)
    {
        if (DirectM2->objectName().isEmpty())
            DirectM2->setObjectName(QString::fromUtf8("DirectM2"));
        DirectM2->resize(1208, 745);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/icon/star.png"), QSize(), QIcon::Normal, QIcon::Off);
        DirectM2->setWindowIcon(icon);
        DirectM2->setFrameShape(QFrame::WinPanel);
        DirectM2->setFrameShadow(QFrame::Sunken);
        DirectM2->setWidgetResizable(false);
        scrollAreaWidgetContents = new QWidget();
        scrollAreaWidgetContents->setObjectName(QString::fromUtf8("scrollAreaWidgetContents"));
        scrollAreaWidgetContents->setGeometry(QRect(0, 0, 1200, 700));
        groupBox_16 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_16->setObjectName(QString::fromUtf8("groupBox_16"));
        groupBox_16->setGeometry(QRect(30, 430, 181, 111));
        pushButton_tz_go = new QPushButton(groupBox_16);
        pushButton_tz_go->setObjectName(QString::fromUtf8("pushButton_tz_go"));
        pushButton_tz_go->setGeometry(QRect(60, 79, 51, 31));
        label_12 = new QLabel(groupBox_16);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(50, 31, 72, 16));
        label_12->setAlignment(Qt::AlignCenter);
        layoutWidget = new QWidget(groupBox_16);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(41, 50, 91, 27));
        horizontalLayout_22 = new QHBoxLayout(layoutWidget);
        horizontalLayout_22->setObjectName(QString::fromUtf8("horizontalLayout_22"));
        horizontalLayout_22->setContentsMargins(0, 0, 0, 0);
        lineEdit_tz_target = new QLineEdit(layoutWidget);
        lineEdit_tz_target->setObjectName(QString::fromUtf8("lineEdit_tz_target"));

        horizontalLayout_22->addWidget(lineEdit_tz_target);

        label_10 = new QLabel(layoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        horizontalLayout_22->addWidget(label_10);

        label_21 = new QLabel(scrollAreaWidgetContents);
        label_21->setObjectName(QString::fromUtf8("label_21"));
        label_21->setGeometry(QRect(570, 0, 91, 31));
        label_21->setTextFormat(Qt::RichText);
        groupBox_13 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_13->setObjectName(QString::fromUtf8("groupBox_13"));
        groupBox_13->setGeometry(QRect(30, 140, 351, 151));
        layoutWidget_9 = new QWidget(groupBox_13);
        layoutWidget_9->setObjectName(QString::fromUtf8("layoutWidget_9"));
        layoutWidget_9->setGeometry(QRect(270, 32, 64, 105));
        verticalLayout_5 = new QVBoxLayout(layoutWidget_9);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        label_16 = new QLabel(layoutWidget_9);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        verticalLayout_5->addWidget(label_16);

        pushButton_tz_warning = new QPushButton(layoutWidget_9);
        pushButton_tz_warning->setObjectName(QString::fromUtf8("pushButton_tz_warning"));
        pushButton_tz_warning->setEnabled(false);

        verticalLayout_5->addWidget(pushButton_tz_warning);

        verticalSpacer_4 = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_5->addItem(verticalSpacer_4);

        pushButton_tz_reset = new QPushButton(layoutWidget_9);
        pushButton_tz_reset->setObjectName(QString::fromUtf8("pushButton_tz_reset"));

        verticalLayout_5->addWidget(pushButton_tz_reset);

        layoutWidget_5 = new QWidget(groupBox_13);
        layoutWidget_5->setObjectName(QString::fromUtf8("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(10, 30, 231, 111));
        gridLayout_12 = new QGridLayout(layoutWidget_5);
        gridLayout_12->setObjectName(QString::fromUtf8("gridLayout_12"));
        gridLayout_12->setContentsMargins(0, 0, 0, 0);
        label_tz_homed = new QLabel(layoutWidget_5);
        label_tz_homed->setObjectName(QString::fromUtf8("label_tz_homed"));

        gridLayout_12->addWidget(label_tz_homed, 0, 0, 1, 1);

        label_41 = new QLabel(layoutWidget_5);
        label_41->setObjectName(QString::fromUtf8("label_41"));

        gridLayout_12->addWidget(label_41, 0, 1, 1, 1);

        label_tz_soft_limitP = new QLabel(layoutWidget_5);
        label_tz_soft_limitP->setObjectName(QString::fromUtf8("label_tz_soft_limitP"));

        gridLayout_12->addWidget(label_tz_soft_limitP, 0, 2, 1, 1);

        label_42 = new QLabel(layoutWidget_5);
        label_42->setObjectName(QString::fromUtf8("label_42"));

        gridLayout_12->addWidget(label_42, 0, 3, 1, 1);

        label_tz_brake = new QLabel(layoutWidget_5);
        label_tz_brake->setObjectName(QString::fromUtf8("label_tz_brake"));

        gridLayout_12->addWidget(label_tz_brake, 1, 0, 1, 1);

        label_44 = new QLabel(layoutWidget_5);
        label_44->setObjectName(QString::fromUtf8("label_44"));

        gridLayout_12->addWidget(label_44, 1, 1, 1, 1);

        label_tz_soft_limitM = new QLabel(layoutWidget_5);
        label_tz_soft_limitM->setObjectName(QString::fromUtf8("label_tz_soft_limitM"));

        gridLayout_12->addWidget(label_tz_soft_limitM, 1, 2, 1, 1);

        label_45 = new QLabel(layoutWidget_5);
        label_45->setObjectName(QString::fromUtf8("label_45"));

        gridLayout_12->addWidget(label_45, 1, 3, 1, 1);

        label_tz_vel_limit = new QLabel(layoutWidget_5);
        label_tz_vel_limit->setObjectName(QString::fromUtf8("label_tz_vel_limit"));

        gridLayout_12->addWidget(label_tz_vel_limit, 2, 0, 1, 1);

        label_47 = new QLabel(layoutWidget_5);
        label_47->setObjectName(QString::fromUtf8("label_47"));

        gridLayout_12->addWidget(label_47, 2, 1, 1, 1);

        label_tz_hard_limitP = new QLabel(layoutWidget_5);
        label_tz_hard_limitP->setObjectName(QString::fromUtf8("label_tz_hard_limitP"));

        gridLayout_12->addWidget(label_tz_hard_limitP, 2, 2, 1, 1);

        label_49 = new QLabel(layoutWidget_5);
        label_49->setObjectName(QString::fromUtf8("label_49"));

        gridLayout_12->addWidget(label_49, 2, 3, 1, 1);

        label_tz_acc_limit = new QLabel(layoutWidget_5);
        label_tz_acc_limit->setObjectName(QString::fromUtf8("label_tz_acc_limit"));

        gridLayout_12->addWidget(label_tz_acc_limit, 3, 0, 1, 1);

        label_52 = new QLabel(layoutWidget_5);
        label_52->setObjectName(QString::fromUtf8("label_52"));

        gridLayout_12->addWidget(label_52, 3, 1, 1, 1);

        label_tz_hard_limitM = new QLabel(layoutWidget_5);
        label_tz_hard_limitM->setObjectName(QString::fromUtf8("label_tz_hard_limitM"));

        gridLayout_12->addWidget(label_tz_hard_limitM, 3, 2, 1, 1);

        label_53 = new QLabel(layoutWidget_5);
        label_53->setObjectName(QString::fromUtf8("label_53"));

        gridLayout_12->addWidget(label_53, 3, 3, 1, 1);

        groupBox_15 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_15->setObjectName(QString::fromUtf8("groupBox_15"));
        groupBox_15->setGeometry(QRect(210, 290, 171, 131));
        layoutWidget1 = new QWidget(groupBox_15);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        layoutWidget1->setGeometry(QRect(12, 40, 151, 81));
        gridLayout_5 = new QGridLayout(layoutWidget1);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        radioButton_tz_acc_default = new QRadioButton(layoutWidget1);
        radioButton_tz_acc_default->setObjectName(QString::fromUtf8("radioButton_tz_acc_default"));

        gridLayout_5->addWidget(radioButton_tz_acc_default, 0, 0, 1, 1);

        label_43 = new QLabel(layoutWidget1);
        label_43->setObjectName(QString::fromUtf8("label_43"));

        gridLayout_5->addWidget(label_43, 0, 1, 1, 1);

        radioButton_tz_acc_spec = new QRadioButton(layoutWidget1);
        radioButton_tz_acc_spec->setObjectName(QString::fromUtf8("radioButton_tz_acc_spec"));

        gridLayout_5->addWidget(radioButton_tz_acc_spec, 1, 0, 1, 1);

        lineEdit_tz_acc_spec = new QLineEdit(layoutWidget1);
        lineEdit_tz_acc_spec->setObjectName(QString::fromUtf8("lineEdit_tz_acc_spec"));
        lineEdit_tz_acc_spec->setEnabled(false);
        lineEdit_tz_acc_spec->setCursor(QCursor(Qt::IBeamCursor));
        lineEdit_tz_acc_spec->setReadOnly(false);

        gridLayout_5->addWidget(lineEdit_tz_acc_spec, 1, 1, 1, 1);

        groupBox_17 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_17->setObjectName(QString::fromUtf8("groupBox_17"));
        groupBox_17->setGeometry(QRect(210, 430, 171, 111));
        layoutWidget_13 = new QWidget(groupBox_17);
        layoutWidget_13->setObjectName(QString::fromUtf8("layoutWidget_13"));
        layoutWidget_13->setGeometry(QRect(20, 40, 141, 61));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget_13);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_tz_dirM = new QPushButton(layoutWidget_13);
        pushButton_tz_dirM->setObjectName(QString::fromUtf8("pushButton_tz_dirM"));

        horizontalLayout_3->addWidget(pushButton_tz_dirM);

        pushButton_tz_dirP = new QPushButton(layoutWidget_13);
        pushButton_tz_dirP->setObjectName(QString::fromUtf8("pushButton_tz_dirP"));

        horizontalLayout_3->addWidget(pushButton_tz_dirP);

        groupBox_20 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_20->setObjectName(QString::fromUtf8("groupBox_20"));
        groupBox_20->setGeometry(QRect(610, 430, 171, 111));
        layoutWidget_17 = new QWidget(groupBox_20);
        layoutWidget_17->setObjectName(QString::fromUtf8("layoutWidget_17"));
        layoutWidget_17->setGeometry(QRect(20, 40, 141, 61));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget_17);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        pushButton_alpha1_dirM = new QPushButton(layoutWidget_17);
        pushButton_alpha1_dirM->setObjectName(QString::fromUtf8("pushButton_alpha1_dirM"));

        horizontalLayout_4->addWidget(pushButton_alpha1_dirM);

        pushButton_alpha1_dirP = new QPushButton(layoutWidget_17);
        pushButton_alpha1_dirP->setObjectName(QString::fromUtf8("pushButton_alpha1_dirP"));

        horizontalLayout_4->addWidget(pushButton_alpha1_dirP);

        pushButton_alpha1_stop = new QPushButton(scrollAreaWidgetContents);
        pushButton_alpha1_stop->setObjectName(QString::fromUtf8("pushButton_alpha1_stop"));
        pushButton_alpha1_stop->setGeometry(QRect(660, 580, 71, 61));
        groupBox_14 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_14->setObjectName(QString::fromUtf8("groupBox_14"));
        groupBox_14->setGeometry(QRect(30, 290, 181, 141));
        layoutWidget2 = new QWidget(groupBox_14);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(12, 24, 161, 102));
        gridLayout_4 = new QGridLayout(layoutWidget2);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        radioButton_tz_vel_fast = new QRadioButton(layoutWidget2);
        radioButton_tz_vel_fast->setObjectName(QString::fromUtf8("radioButton_tz_vel_fast"));

        gridLayout_4->addWidget(radioButton_tz_vel_fast, 0, 0, 1, 1);

        radioButton_tz_vel_mid = new QRadioButton(layoutWidget2);
        radioButton_tz_vel_mid->setObjectName(QString::fromUtf8("radioButton_tz_vel_mid"));
        radioButton_tz_vel_mid->setChecked(true);

        gridLayout_4->addWidget(radioButton_tz_vel_mid, 1, 0, 1, 1);

        radioButton_tz_vel_slow = new QRadioButton(layoutWidget2);
        radioButton_tz_vel_slow->setObjectName(QString::fromUtf8("radioButton_tz_vel_slow"));

        gridLayout_4->addWidget(radioButton_tz_vel_slow, 2, 0, 1, 1);

        radioButton_tz_vel_spec = new QRadioButton(layoutWidget2);
        radioButton_tz_vel_spec->setObjectName(QString::fromUtf8("radioButton_tz_vel_spec"));

        gridLayout_4->addWidget(radioButton_tz_vel_spec, 3, 0, 1, 1);

        lineEdit_tz_vel_spec = new QLineEdit(layoutWidget2);
        lineEdit_tz_vel_spec->setObjectName(QString::fromUtf8("lineEdit_tz_vel_spec"));
        lineEdit_tz_vel_spec->setEnabled(false);
        lineEdit_tz_vel_spec->setCursor(QCursor(Qt::IBeamCursor));
        lineEdit_tz_vel_spec->setMaxLength(6);
        lineEdit_tz_vel_spec->setReadOnly(false);

        gridLayout_4->addWidget(lineEdit_tz_vel_spec, 3, 1, 1, 1);

        label_11 = new QLabel(scrollAreaWidgetContents);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(130, 0, 161, 31));
        label_11->setTextFormat(Qt::AutoText);
        label_11->setScaledContents(false);
        groupBox_18 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        groupBox_18->setGeometry(QRect(30, 550, 181, 131));
        layoutWidget_14 = new QWidget(groupBox_18);
        layoutWidget_14->setObjectName(QString::fromUtf8("layoutWidget_14"));
        layoutWidget_14->setGeometry(QRect(10, 20, 153, 102));
        gridLayout_16 = new QGridLayout(layoutWidget_14);
        gridLayout_16->setObjectName(QString::fromUtf8("gridLayout_16"));
        gridLayout_16->setContentsMargins(0, 0, 0, 0);
        radioButton_tz_step1 = new QRadioButton(layoutWidget_14);
        radioButton_tz_step1->setObjectName(QString::fromUtf8("radioButton_tz_step1"));

        gridLayout_16->addWidget(radioButton_tz_step1, 0, 0, 1, 1);

        pushButton_tz_stepM = new QPushButton(layoutWidget_14);
        pushButton_tz_stepM->setObjectName(QString::fromUtf8("pushButton_tz_stepM"));

        gridLayout_16->addWidget(pushButton_tz_stepM, 0, 1, 2, 1);

        radioButton_tz_step01 = new QRadioButton(layoutWidget_14);
        radioButton_tz_step01->setObjectName(QString::fromUtf8("radioButton_tz_step01"));

        gridLayout_16->addWidget(radioButton_tz_step01, 1, 0, 2, 1);

        pushButton_tz_stepP = new QPushButton(layoutWidget_14);
        pushButton_tz_stepP->setObjectName(QString::fromUtf8("pushButton_tz_stepP"));

        gridLayout_16->addWidget(pushButton_tz_stepP, 2, 1, 2, 1);

        radioButton_tz_step001 = new QRadioButton(layoutWidget_14);
        radioButton_tz_step001->setObjectName(QString::fromUtf8("radioButton_tz_step001"));

        gridLayout_16->addWidget(radioButton_tz_step001, 3, 0, 1, 1);

        radioButton_tz_step_spec = new QRadioButton(layoutWidget_14);
        radioButton_tz_step_spec->setObjectName(QString::fromUtf8("radioButton_tz_step_spec"));

        gridLayout_16->addWidget(radioButton_tz_step_spec, 4, 0, 1, 1);

        lineEdit_tz_step_spec = new QLineEdit(layoutWidget_14);
        lineEdit_tz_step_spec->setObjectName(QString::fromUtf8("lineEdit_tz_step_spec"));
        lineEdit_tz_step_spec->setEnabled(false);

        gridLayout_16->addWidget(lineEdit_tz_step_spec, 4, 1, 1, 1);

        pushButton_tz_stop = new QPushButton(scrollAreaWidgetContents);
        pushButton_tz_stop->setObjectName(QString::fromUtf8("pushButton_tz_stop"));
        pushButton_tz_stop->setGeometry(QRect(270, 580, 71, 61));
        layoutWidget3 = new QWidget(scrollAreaWidgetContents);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(30, 100, 351, 41));
        horizontalLayout = new QHBoxLayout(layoutWidget3);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        pushButton_tz_axis = new QPushButton(layoutWidget3);
        pushButton_tz_axis->setObjectName(QString::fromUtf8("pushButton_tz_axis"));

        horizontalLayout->addWidget(pushButton_tz_axis);

        pushButton_tz_home = new QPushButton(layoutWidget3);
        pushButton_tz_home->setObjectName(QString::fromUtf8("pushButton_tz_home"));
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButton_tz_home->sizePolicy().hasHeightForWidth());
        pushButton_tz_home->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButton_tz_home);

        pushButton_tz_park = new QPushButton(layoutWidget3);
        pushButton_tz_park->setObjectName(QString::fromUtf8("pushButton_tz_park"));
        sizePolicy.setHeightForWidth(pushButton_tz_park->sizePolicy().hasHeightForWidth());
        pushButton_tz_park->setSizePolicy(sizePolicy);

        horizontalLayout->addWidget(pushButton_tz_park);

        groupBox_22 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_22->setObjectName(QString::fromUtf8("groupBox_22"));
        groupBox_22->setGeometry(QRect(430, 550, 181, 131));
        layoutWidget_19 = new QWidget(groupBox_22);
        layoutWidget_19->setObjectName(QString::fromUtf8("layoutWidget_19"));
        layoutWidget_19->setGeometry(QRect(10, 20, 153, 102));
        gridLayout_19 = new QGridLayout(layoutWidget_19);
        gridLayout_19->setObjectName(QString::fromUtf8("gridLayout_19"));
        gridLayout_19->setContentsMargins(0, 0, 0, 0);
        radioButton_alpha1_step1 = new QRadioButton(layoutWidget_19);
        radioButton_alpha1_step1->setObjectName(QString::fromUtf8("radioButton_alpha1_step1"));

        gridLayout_19->addWidget(radioButton_alpha1_step1, 0, 0, 1, 1);

        pushButton_alpha1_stepM = new QPushButton(layoutWidget_19);
        pushButton_alpha1_stepM->setObjectName(QString::fromUtf8("pushButton_alpha1_stepM"));

        gridLayout_19->addWidget(pushButton_alpha1_stepM, 0, 1, 2, 1);

        radioButton_alpha1_step01 = new QRadioButton(layoutWidget_19);
        radioButton_alpha1_step01->setObjectName(QString::fromUtf8("radioButton_alpha1_step01"));

        gridLayout_19->addWidget(radioButton_alpha1_step01, 1, 0, 2, 1);

        pushButton_alpha1_stepP = new QPushButton(layoutWidget_19);
        pushButton_alpha1_stepP->setObjectName(QString::fromUtf8("pushButton_alpha1_stepP"));

        gridLayout_19->addWidget(pushButton_alpha1_stepP, 2, 1, 2, 1);

        radioButton_alpha1_step001 = new QRadioButton(layoutWidget_19);
        radioButton_alpha1_step001->setObjectName(QString::fromUtf8("radioButton_alpha1_step001"));

        gridLayout_19->addWidget(radioButton_alpha1_step001, 3, 0, 1, 1);

        radioButton_alpha1_step_spec = new QRadioButton(layoutWidget_19);
        radioButton_alpha1_step_spec->setObjectName(QString::fromUtf8("radioButton_alpha1_step_spec"));

        gridLayout_19->addWidget(radioButton_alpha1_step_spec, 4, 0, 1, 1);

        lineEdit_alpha1_step_spec = new QLineEdit(layoutWidget_19);
        lineEdit_alpha1_step_spec->setObjectName(QString::fromUtf8("lineEdit_alpha1_step_spec"));
        lineEdit_alpha1_step_spec->setEnabled(false);

        gridLayout_19->addWidget(lineEdit_alpha1_step_spec, 4, 1, 1, 1);

        groupBox_21 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_21->setObjectName(QString::fromUtf8("groupBox_21"));
        groupBox_21->setGeometry(QRect(430, 290, 181, 131));
        layoutWidget4 = new QWidget(groupBox_21);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(10, 26, 161, 102));
        gridLayout_6 = new QGridLayout(layoutWidget4);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        gridLayout_6->setContentsMargins(0, 0, 0, 0);
        radioButton_alpha1_vel_fast = new QRadioButton(layoutWidget4);
        radioButton_alpha1_vel_fast->setObjectName(QString::fromUtf8("radioButton_alpha1_vel_fast"));

        gridLayout_6->addWidget(radioButton_alpha1_vel_fast, 0, 0, 1, 1);

        radioButton_alpha1_vel_mid = new QRadioButton(layoutWidget4);
        radioButton_alpha1_vel_mid->setObjectName(QString::fromUtf8("radioButton_alpha1_vel_mid"));

        gridLayout_6->addWidget(radioButton_alpha1_vel_mid, 1, 0, 1, 1);

        radioButton_alpha1_vel_slow = new QRadioButton(layoutWidget4);
        radioButton_alpha1_vel_slow->setObjectName(QString::fromUtf8("radioButton_alpha1_vel_slow"));

        gridLayout_6->addWidget(radioButton_alpha1_vel_slow, 2, 0, 1, 1);

        radioButton_alpha1_vel_spec = new QRadioButton(layoutWidget4);
        radioButton_alpha1_vel_spec->setObjectName(QString::fromUtf8("radioButton_alpha1_vel_spec"));

        gridLayout_6->addWidget(radioButton_alpha1_vel_spec, 3, 0, 1, 1);

        lineEdit_alpha1_vel_spec = new QLineEdit(layoutWidget4);
        lineEdit_alpha1_vel_spec->setObjectName(QString::fromUtf8("lineEdit_alpha1_vel_spec"));
        lineEdit_alpha1_vel_spec->setEnabled(false);
        lineEdit_alpha1_vel_spec->setCursor(QCursor(Qt::IBeamCursor));
        lineEdit_alpha1_vel_spec->setReadOnly(false);

        gridLayout_6->addWidget(lineEdit_alpha1_vel_spec, 3, 1, 1, 1);

        groupBox_19 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_19->setObjectName(QString::fromUtf8("groupBox_19"));
        groupBox_19->setGeometry(QRect(430, 140, 351, 151));
        layoutWidget_16 = new QWidget(groupBox_19);
        layoutWidget_16->setObjectName(QString::fromUtf8("layoutWidget_16"));
        layoutWidget_16->setGeometry(QRect(270, 32, 64, 105));
        verticalLayout_7 = new QVBoxLayout(layoutWidget_16);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        label_17 = new QLabel(layoutWidget_16);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        verticalLayout_7->addWidget(label_17);

        pushButton_alpha1_warning = new QPushButton(layoutWidget_16);
        pushButton_alpha1_warning->setObjectName(QString::fromUtf8("pushButton_alpha1_warning"));
        pushButton_alpha1_warning->setEnabled(false);

        verticalLayout_7->addWidget(pushButton_alpha1_warning);

        verticalSpacer_5 = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_7->addItem(verticalSpacer_5);

        pushButton_alpha1_reset = new QPushButton(layoutWidget_16);
        pushButton_alpha1_reset->setObjectName(QString::fromUtf8("pushButton_alpha1_reset"));

        verticalLayout_7->addWidget(pushButton_alpha1_reset);

        layoutWidget_2 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(430, 100, 341, 41));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget_2);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_2 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_2);

        pushButton_alpha1_axis = new QPushButton(layoutWidget_2);
        pushButton_alpha1_axis->setObjectName(QString::fromUtf8("pushButton_alpha1_axis"));

        horizontalLayout_2->addWidget(pushButton_alpha1_axis);

        pushButton_alpha1_home_2 = new QPushButton(layoutWidget_2);
        pushButton_alpha1_home_2->setObjectName(QString::fromUtf8("pushButton_alpha1_home_2"));
        sizePolicy.setHeightForWidth(pushButton_alpha1_home_2->sizePolicy().hasHeightForWidth());
        pushButton_alpha1_home_2->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(pushButton_alpha1_home_2);

        pushButton_alpha1_park_2 = new QPushButton(layoutWidget_2);
        pushButton_alpha1_park_2->setObjectName(QString::fromUtf8("pushButton_alpha1_park_2"));
        sizePolicy.setHeightForWidth(pushButton_alpha1_park_2->sizePolicy().hasHeightForWidth());
        pushButton_alpha1_park_2->setSizePolicy(sizePolicy);

        horizontalLayout_2->addWidget(pushButton_alpha1_park_2);

        groupBox_24 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_24->setObjectName(QString::fromUtf8("groupBox_24"));
        groupBox_24->setGeometry(QRect(610, 290, 171, 131));
        layoutWidget5 = new QWidget(groupBox_24);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(12, 40, 151, 81));
        gridLayout_7 = new QGridLayout(layoutWidget5);
        gridLayout_7->setObjectName(QString::fromUtf8("gridLayout_7"));
        gridLayout_7->setContentsMargins(0, 0, 0, 0);
        radioButton_alpha1_acc_default = new QRadioButton(layoutWidget5);
        radioButton_alpha1_acc_default->setObjectName(QString::fromUtf8("radioButton_alpha1_acc_default"));

        gridLayout_7->addWidget(radioButton_alpha1_acc_default, 0, 0, 1, 1);

        label_46 = new QLabel(layoutWidget5);
        label_46->setObjectName(QString::fromUtf8("label_46"));

        gridLayout_7->addWidget(label_46, 0, 1, 1, 1);

        radioButton_alpha1_acc_spec = new QRadioButton(layoutWidget5);
        radioButton_alpha1_acc_spec->setObjectName(QString::fromUtf8("radioButton_alpha1_acc_spec"));

        gridLayout_7->addWidget(radioButton_alpha1_acc_spec, 1, 0, 1, 1);

        lineEdit_alpha1_acc_spec = new QLineEdit(layoutWidget5);
        lineEdit_alpha1_acc_spec->setObjectName(QString::fromUtf8("lineEdit_alpha1_acc_spec"));
        lineEdit_alpha1_acc_spec->setEnabled(false);
        lineEdit_alpha1_acc_spec->setCursor(QCursor(Qt::IBeamCursor));
        lineEdit_alpha1_acc_spec->setReadOnly(false);

        gridLayout_7->addWidget(lineEdit_alpha1_acc_spec, 1, 1, 1, 1);

        groupBox_23 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_23->setObjectName(QString::fromUtf8("groupBox_23"));
        groupBox_23->setGeometry(QRect(430, 430, 181, 111));
        lineEdit_alpha1_targetM = new QLineEdit(groupBox_23);
        lineEdit_alpha1_targetM->setObjectName(QString::fromUtf8("lineEdit_alpha1_targetM"));
        lineEdit_alpha1_targetM->setGeometry(QRect(50, 47, 51, 25));
        lineEdit_alpha1_targetM->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha1_targetS = new QLineEdit(groupBox_23);
        lineEdit_alpha1_targetS->setObjectName(QString::fromUtf8("lineEdit_alpha1_targetS"));
        lineEdit_alpha1_targetS->setGeometry(QRect(110, 47, 51, 25));
        lineEdit_alpha1_targetS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_2 = new QLabel(groupBox_23);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(40, 47, 16, 16));
        label = new QLabel(groupBox_23);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 43, 16, 20));
        label_3 = new QLabel(groupBox_23);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(160, 47, 16, 16));
        label_13 = new QLabel(groupBox_23);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(60, 31, 72, 16));
        label_13->setAlignment(Qt::AlignCenter);
        pushButton_alpha1_go = new QPushButton(groupBox_23);
        pushButton_alpha1_go->setObjectName(QString::fromUtf8("pushButton_alpha1_go"));
        pushButton_alpha1_go->setGeometry(QRect(70, 79, 51, 31));
        lineEdit_alpha1_targetD = new QLineEdit(groupBox_23);
        lineEdit_alpha1_targetD->setObjectName(QString::fromUtf8("lineEdit_alpha1_targetD"));
        lineEdit_alpha1_targetD->setEnabled(false);
        lineEdit_alpha1_targetD->setGeometry(QRect(20, 47, 21, 25));
        lineEdit_alpha1_targetD->setMaxLength(3);
        lineEdit_alpha1_targetD->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        groupBox_25 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_25->setObjectName(QString::fromUtf8("groupBox_25"));
        groupBox_25->setGeometry(QRect(830, 140, 351, 141));
        layoutWidget_25 = new QWidget(groupBox_25);
        layoutWidget_25->setObjectName(QString::fromUtf8("layoutWidget_25"));
        layoutWidget_25->setGeometry(QRect(270, 32, 64, 105));
        verticalLayout_9 = new QVBoxLayout(layoutWidget_25);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        verticalLayout_9->setContentsMargins(0, 0, 0, 0);
        label_25 = new QLabel(layoutWidget_25);
        label_25->setObjectName(QString::fromUtf8("label_25"));

        verticalLayout_9->addWidget(label_25);

        pushButton_alpha2_warning = new QPushButton(layoutWidget_25);
        pushButton_alpha2_warning->setObjectName(QString::fromUtf8("pushButton_alpha2_warning"));
        pushButton_alpha2_warning->setEnabled(false);

        verticalLayout_9->addWidget(pushButton_alpha2_warning);

        verticalSpacer_6 = new QSpacerItem(20, 28, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_9->addItem(verticalSpacer_6);

        pushButton_alpha2_reset = new QPushButton(layoutWidget_25);
        pushButton_alpha2_reset->setObjectName(QString::fromUtf8("pushButton_alpha2_reset"));

        verticalLayout_9->addWidget(pushButton_alpha2_reset);

        pushButton_alpha2_stop = new QPushButton(scrollAreaWidgetContents);
        pushButton_alpha2_stop->setObjectName(QString::fromUtf8("pushButton_alpha2_stop"));
        pushButton_alpha2_stop->setGeometry(QRect(1060, 580, 71, 61));
        groupBox_26 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_26->setObjectName(QString::fromUtf8("groupBox_26"));
        groupBox_26->setGeometry(QRect(830, 550, 181, 131));
        layoutWidget_27 = new QWidget(groupBox_26);
        layoutWidget_27->setObjectName(QString::fromUtf8("layoutWidget_27"));
        layoutWidget_27->setGeometry(QRect(10, 20, 153, 102));
        gridLayout_25 = new QGridLayout(layoutWidget_27);
        gridLayout_25->setObjectName(QString::fromUtf8("gridLayout_25"));
        gridLayout_25->setContentsMargins(0, 0, 0, 0);
        radioButton_alpha2_step1 = new QRadioButton(layoutWidget_27);
        radioButton_alpha2_step1->setObjectName(QString::fromUtf8("radioButton_alpha2_step1"));

        gridLayout_25->addWidget(radioButton_alpha2_step1, 0, 0, 1, 1);

        pushButton_alpha2_stepM = new QPushButton(layoutWidget_27);
        pushButton_alpha2_stepM->setObjectName(QString::fromUtf8("pushButton_alpha2_stepM"));

        gridLayout_25->addWidget(pushButton_alpha2_stepM, 0, 1, 2, 1);

        radioButton_alpha2_step01 = new QRadioButton(layoutWidget_27);
        radioButton_alpha2_step01->setObjectName(QString::fromUtf8("radioButton_alpha2_step01"));

        gridLayout_25->addWidget(radioButton_alpha2_step01, 1, 0, 2, 1);

        pushButton_alpha2_stepP = new QPushButton(layoutWidget_27);
        pushButton_alpha2_stepP->setObjectName(QString::fromUtf8("pushButton_alpha2_stepP"));

        gridLayout_25->addWidget(pushButton_alpha2_stepP, 2, 1, 2, 1);

        radioButton_alpha2_step001 = new QRadioButton(layoutWidget_27);
        radioButton_alpha2_step001->setObjectName(QString::fromUtf8("radioButton_alpha2_step001"));

        gridLayout_25->addWidget(radioButton_alpha2_step001, 3, 0, 1, 1);

        radioButton_alpha2_step_spec = new QRadioButton(layoutWidget_27);
        radioButton_alpha2_step_spec->setObjectName(QString::fromUtf8("radioButton_alpha2_step_spec"));

        gridLayout_25->addWidget(radioButton_alpha2_step_spec, 4, 0, 1, 1);

        lineEdit_alpha2_step_spec = new QLineEdit(layoutWidget_27);
        lineEdit_alpha2_step_spec->setObjectName(QString::fromUtf8("lineEdit_alpha2_step_spec"));
        lineEdit_alpha2_step_spec->setEnabled(false);

        gridLayout_25->addWidget(lineEdit_alpha2_step_spec, 4, 1, 1, 1);

        groupBox_27 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_27->setObjectName(QString::fromUtf8("groupBox_27"));
        groupBox_27->setGeometry(QRect(830, 290, 181, 131));
        layoutWidget6 = new QWidget(groupBox_27);
        layoutWidget6->setObjectName(QString::fromUtf8("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(12, 23, 161, 102));
        gridLayout_8 = new QGridLayout(layoutWidget6);
        gridLayout_8->setObjectName(QString::fromUtf8("gridLayout_8"));
        gridLayout_8->setContentsMargins(0, 0, 0, 0);
        radioButton_alpha2_vel_fast = new QRadioButton(layoutWidget6);
        radioButton_alpha2_vel_fast->setObjectName(QString::fromUtf8("radioButton_alpha2_vel_fast"));

        gridLayout_8->addWidget(radioButton_alpha2_vel_fast, 0, 0, 1, 1);

        radioButton_alpha2_vel_mid = new QRadioButton(layoutWidget6);
        radioButton_alpha2_vel_mid->setObjectName(QString::fromUtf8("radioButton_alpha2_vel_mid"));

        gridLayout_8->addWidget(radioButton_alpha2_vel_mid, 1, 0, 1, 1);

        radioButton_alpha2_vel_slow = new QRadioButton(layoutWidget6);
        radioButton_alpha2_vel_slow->setObjectName(QString::fromUtf8("radioButton_alpha2_vel_slow"));

        gridLayout_8->addWidget(radioButton_alpha2_vel_slow, 2, 0, 1, 1);

        radioButton_alpha2_vel_spec = new QRadioButton(layoutWidget6);
        radioButton_alpha2_vel_spec->setObjectName(QString::fromUtf8("radioButton_alpha2_vel_spec"));

        gridLayout_8->addWidget(radioButton_alpha2_vel_spec, 3, 0, 1, 1);

        lineEdit_alpha2_vel_spec = new QLineEdit(layoutWidget6);
        lineEdit_alpha2_vel_spec->setObjectName(QString::fromUtf8("lineEdit_alpha2_vel_spec"));
        lineEdit_alpha2_vel_spec->setEnabled(false);
        lineEdit_alpha2_vel_spec->setCursor(QCursor(Qt::IBeamCursor));
        lineEdit_alpha2_vel_spec->setReadOnly(false);

        gridLayout_8->addWidget(lineEdit_alpha2_vel_spec, 3, 1, 1, 1);

        layoutWidget_3 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(830, 100, 341, 41));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget_3);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        horizontalSpacer_6 = new QSpacerItem(88, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_6);

        pushButton_alpha2_axis = new QPushButton(layoutWidget_3);
        pushButton_alpha2_axis->setObjectName(QString::fromUtf8("pushButton_alpha2_axis"));

        horizontalLayout_5->addWidget(pushButton_alpha2_axis);

        pushButton_alpha2_home = new QPushButton(layoutWidget_3);
        pushButton_alpha2_home->setObjectName(QString::fromUtf8("pushButton_alpha2_home"));
        sizePolicy.setHeightForWidth(pushButton_alpha2_home->sizePolicy().hasHeightForWidth());
        pushButton_alpha2_home->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(pushButton_alpha2_home);

        pushButton_alpha2_park = new QPushButton(layoutWidget_3);
        pushButton_alpha2_park->setObjectName(QString::fromUtf8("pushButton_alpha2_park"));
        sizePolicy.setHeightForWidth(pushButton_alpha2_park->sizePolicy().hasHeightForWidth());
        pushButton_alpha2_park->setSizePolicy(sizePolicy);

        horizontalLayout_5->addWidget(pushButton_alpha2_park);

        groupBox_28 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_28->setObjectName(QString::fromUtf8("groupBox_28"));
        groupBox_28->setGeometry(QRect(1010, 430, 171, 111));
        layoutWidget_29 = new QWidget(groupBox_28);
        layoutWidget_29->setObjectName(QString::fromUtf8("layoutWidget_29"));
        layoutWidget_29->setGeometry(QRect(20, 40, 141, 61));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget_29);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        pushButton_alpha2_dirM = new QPushButton(layoutWidget_29);
        pushButton_alpha2_dirM->setObjectName(QString::fromUtf8("pushButton_alpha2_dirM"));

        horizontalLayout_6->addWidget(pushButton_alpha2_dirM);

        pushButton_alpha2_dirP = new QPushButton(layoutWidget_29);
        pushButton_alpha2_dirP->setObjectName(QString::fromUtf8("pushButton_alpha2_dirP"));

        horizontalLayout_6->addWidget(pushButton_alpha2_dirP);

        groupBox_29 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_29->setObjectName(QString::fromUtf8("groupBox_29"));
        groupBox_29->setGeometry(QRect(1010, 290, 171, 131));
        layoutWidget7 = new QWidget(groupBox_29);
        layoutWidget7->setObjectName(QString::fromUtf8("layoutWidget7"));
        layoutWidget7->setGeometry(QRect(10, 40, 151, 81));
        gridLayout_9 = new QGridLayout(layoutWidget7);
        gridLayout_9->setObjectName(QString::fromUtf8("gridLayout_9"));
        gridLayout_9->setContentsMargins(0, 0, 0, 0);
        radioButton_alpha2_acc_default = new QRadioButton(layoutWidget7);
        radioButton_alpha2_acc_default->setObjectName(QString::fromUtf8("radioButton_alpha2_acc_default"));

        gridLayout_9->addWidget(radioButton_alpha2_acc_default, 0, 0, 1, 1);

        label_48 = new QLabel(layoutWidget7);
        label_48->setObjectName(QString::fromUtf8("label_48"));

        gridLayout_9->addWidget(label_48, 0, 1, 1, 1);

        radioButton_alpha2_acc_spec = new QRadioButton(layoutWidget7);
        radioButton_alpha2_acc_spec->setObjectName(QString::fromUtf8("radioButton_alpha2_acc_spec"));

        gridLayout_9->addWidget(radioButton_alpha2_acc_spec, 1, 0, 1, 1);

        lineEdit_alpha2_acc_spec = new QLineEdit(layoutWidget7);
        lineEdit_alpha2_acc_spec->setObjectName(QString::fromUtf8("lineEdit_alpha2_acc_spec"));
        lineEdit_alpha2_acc_spec->setEnabled(false);
        lineEdit_alpha2_acc_spec->setCursor(QCursor(Qt::IBeamCursor));
        lineEdit_alpha2_acc_spec->setReadOnly(false);

        gridLayout_9->addWidget(lineEdit_alpha2_acc_spec, 1, 1, 1, 1);

        groupBox_30 = new QGroupBox(scrollAreaWidgetContents);
        groupBox_30->setObjectName(QString::fromUtf8("groupBox_30"));
        groupBox_30->setGeometry(QRect(830, 430, 181, 111));
        lineEdit_alpha2_targetD = new QLineEdit(groupBox_30);
        lineEdit_alpha2_targetD->setObjectName(QString::fromUtf8("lineEdit_alpha2_targetD"));
        lineEdit_alpha2_targetD->setEnabled(false);
        lineEdit_alpha2_targetD->setGeometry(QRect(20, 50, 21, 25));
        lineEdit_alpha2_targetD->setMaxLength(3);
        lineEdit_alpha2_targetD->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_4 = new QLabel(groupBox_30);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(160, 50, 20, 20));
        lineEdit_alpha2_targetS = new QLineEdit(groupBox_30);
        lineEdit_alpha2_targetS->setObjectName(QString::fromUtf8("lineEdit_alpha2_targetS"));
        lineEdit_alpha2_targetS->setGeometry(QRect(110, 50, 51, 25));
        lineEdit_alpha2_targetS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha2_targetM = new QLineEdit(groupBox_30);
        lineEdit_alpha2_targetM->setObjectName(QString::fromUtf8("lineEdit_alpha2_targetM"));
        lineEdit_alpha2_targetM->setGeometry(QRect(50, 50, 51, 25));
        lineEdit_alpha2_targetM->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_5 = new QLabel(groupBox_30);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(40, 46, 16, 20));
        label_14 = new QLabel(groupBox_30);
        label_14->setObjectName(QString::fromUtf8("label_14"));
        label_14->setGeometry(QRect(50, 31, 72, 16));
        label_14->setAlignment(Qt::AlignCenter);
        label_6 = new QLabel(groupBox_30);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(100, 50, 16, 16));
        pushButton_alpha2_go = new QPushButton(groupBox_30);
        pushButton_alpha2_go->setObjectName(QString::fromUtf8("pushButton_alpha2_go"));
        pushButton_alpha2_go->setGeometry(QRect(70, 79, 51, 31));
        label_29 = new QLabel(scrollAreaWidgetContents);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(960, 0, 91, 31));
        label_29->setTextFormat(Qt::RichText);
        layoutWidget8 = new QWidget(scrollAreaWidgetContents);
        layoutWidget8->setObjectName(QString::fromUtf8("layoutWidget8"));
        layoutWidget8->setGeometry(QRect(31, 30, 351, 60));
        gridLayout = new QGridLayout(layoutWidget8);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_22 = new QLabel(layoutWidget8);
        label_22->setObjectName(QString::fromUtf8("label_22"));

        gridLayout->addWidget(label_22, 0, 0, 1, 1);

        horizontalLayout_7 = new QHBoxLayout();
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        lineEdit_tz_pos = new QLineEdit(layoutWidget8);
        lineEdit_tz_pos->setObjectName(QString::fromUtf8("lineEdit_tz_pos"));
        lineEdit_tz_pos->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tz_pos->setReadOnly(true);

        horizontalLayout_7->addWidget(lineEdit_tz_pos);

        label_7 = new QLabel(layoutWidget8);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        horizontalLayout_7->addWidget(label_7);


        gridLayout->addLayout(horizontalLayout_7, 0, 1, 1, 1);

        label_23 = new QLabel(layoutWidget8);
        label_23->setObjectName(QString::fromUtf8("label_23"));

        gridLayout->addWidget(label_23, 0, 2, 1, 1);

        horizontalLayout_9 = new QHBoxLayout();
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        lineEdit_tz_vel = new QLineEdit(layoutWidget8);
        lineEdit_tz_vel->setObjectName(QString::fromUtf8("lineEdit_tz_vel"));
        lineEdit_tz_vel->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tz_vel->setReadOnly(true);

        horizontalLayout_9->addWidget(lineEdit_tz_vel);

        label_9 = new QLabel(layoutWidget8);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_9->addWidget(label_9);


        gridLayout->addLayout(horizontalLayout_9, 0, 3, 1, 1);

        label_24 = new QLabel(layoutWidget8);
        label_24->setObjectName(QString::fromUtf8("label_24"));

        gridLayout->addWidget(label_24, 1, 0, 1, 1);

        horizontalLayout_8 = new QHBoxLayout();
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        lineEdit_tz_poserr = new QLineEdit(layoutWidget8);
        lineEdit_tz_poserr->setObjectName(QString::fromUtf8("lineEdit_tz_poserr"));
        lineEdit_tz_poserr->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_tz_poserr->setReadOnly(true);

        horizontalLayout_8->addWidget(lineEdit_tz_poserr);

        label_8 = new QLabel(layoutWidget8);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        horizontalLayout_8->addWidget(label_8);


        gridLayout->addLayout(horizontalLayout_8, 1, 1, 1, 1);

        horizontalSpacer_4 = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout->addItem(horizontalSpacer_4, 1, 2, 1, 2);

        layoutWidget9 = new QWidget(scrollAreaWidgetContents);
        layoutWidget9->setObjectName(QString::fromUtf8("layoutWidget9"));
        layoutWidget9->setGeometry(QRect(430, 31, 361, 60));
        gridLayout_2 = new QGridLayout(layoutWidget9);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        label_18 = new QLabel(layoutWidget9);
        label_18->setObjectName(QString::fromUtf8("label_18"));

        gridLayout_2->addWidget(label_18, 0, 0, 1, 1);

        horizontalLayout_10 = new QHBoxLayout();
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        lineEdit_alpha1_posM = new QLineEdit(layoutWidget9);
        lineEdit_alpha1_posM->setObjectName(QString::fromUtf8("lineEdit_alpha1_posM"));
        lineEdit_alpha1_posM->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha1_posM->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha1_posM->setReadOnly(true);

        horizontalLayout_10->addWidget(lineEdit_alpha1_posM);

        label_37 = new QLabel(layoutWidget9);
        label_37->setObjectName(QString::fromUtf8("label_37"));

        horizontalLayout_10->addWidget(label_37);


        gridLayout_2->addLayout(horizontalLayout_10, 0, 1, 1, 1);

        horizontalLayout_11 = new QHBoxLayout();
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        lineEdit_alpha1_posS = new QLineEdit(layoutWidget9);
        lineEdit_alpha1_posS->setObjectName(QString::fromUtf8("lineEdit_alpha1_posS"));
        lineEdit_alpha1_posS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha1_posS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha1_posS->setReadOnly(true);

        horizontalLayout_11->addWidget(lineEdit_alpha1_posS);

        label_35 = new QLabel(layoutWidget9);
        label_35->setObjectName(QString::fromUtf8("label_35"));

        horizontalLayout_11->addWidget(label_35);


        gridLayout_2->addLayout(horizontalLayout_11, 0, 2, 1, 1);

        label_19 = new QLabel(layoutWidget9);
        label_19->setObjectName(QString::fromUtf8("label_19"));

        gridLayout_2->addWidget(label_19, 0, 3, 1, 1);

        horizontalLayout_15 = new QHBoxLayout();
        horizontalLayout_15->setObjectName(QString::fromUtf8("horizontalLayout_15"));
        lineEdit_alpha1_velS = new QLineEdit(layoutWidget9);
        lineEdit_alpha1_velS->setObjectName(QString::fromUtf8("lineEdit_alpha1_velS"));
        lineEdit_alpha1_velS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha1_velS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha1_velS->setReadOnly(true);

        horizontalLayout_15->addWidget(lineEdit_alpha1_velS);

        label_31 = new QLabel(layoutWidget9);
        label_31->setObjectName(QString::fromUtf8("label_31"));

        horizontalLayout_15->addWidget(label_31);


        gridLayout_2->addLayout(horizontalLayout_15, 0, 4, 1, 1);

        label_20 = new QLabel(layoutWidget9);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_2->addWidget(label_20, 1, 0, 1, 1);

        horizontalLayout_12 = new QHBoxLayout();
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        lineEdit_alpha1_poserrS = new QLineEdit(layoutWidget9);
        lineEdit_alpha1_poserrS->setObjectName(QString::fromUtf8("lineEdit_alpha1_poserrS"));
        lineEdit_alpha1_poserrS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha1_poserrS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha1_poserrS->setReadOnly(true);

        horizontalLayout_12->addWidget(lineEdit_alpha1_poserrS);

        label_34 = new QLabel(layoutWidget9);
        label_34->setObjectName(QString::fromUtf8("label_34"));

        horizontalLayout_12->addWidget(label_34);


        gridLayout_2->addLayout(horizontalLayout_12, 1, 1, 1, 1);

        horizontalSpacer_3 = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_2->addItem(horizontalSpacer_3, 1, 3, 1, 2);

        layoutWidget_4 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(830, 30, 361, 60));
        gridLayout_3 = new QGridLayout(layoutWidget_4);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        label_26 = new QLabel(layoutWidget_4);
        label_26->setObjectName(QString::fromUtf8("label_26"));

        gridLayout_3->addWidget(label_26, 0, 0, 1, 1);

        horizontalLayout_13 = new QHBoxLayout();
        horizontalLayout_13->setObjectName(QString::fromUtf8("horizontalLayout_13"));
        lineEdit_alpha2_posM = new QLineEdit(layoutWidget_4);
        lineEdit_alpha2_posM->setObjectName(QString::fromUtf8("lineEdit_alpha2_posM"));
        lineEdit_alpha2_posM->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha2_posM->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha2_posM->setReadOnly(true);

        horizontalLayout_13->addWidget(lineEdit_alpha2_posM);

        label_38 = new QLabel(layoutWidget_4);
        label_38->setObjectName(QString::fromUtf8("label_38"));

        horizontalLayout_13->addWidget(label_38);


        gridLayout_3->addLayout(horizontalLayout_13, 0, 1, 1, 1);

        horizontalLayout_14 = new QHBoxLayout();
        horizontalLayout_14->setObjectName(QString::fromUtf8("horizontalLayout_14"));
        lineEdit_alpha2_posS = new QLineEdit(layoutWidget_4);
        lineEdit_alpha2_posS->setObjectName(QString::fromUtf8("lineEdit_alpha2_posS"));
        lineEdit_alpha2_posS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha2_posS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha2_posS->setReadOnly(true);

        horizontalLayout_14->addWidget(lineEdit_alpha2_posS);

        label_36 = new QLabel(layoutWidget_4);
        label_36->setObjectName(QString::fromUtf8("label_36"));

        horizontalLayout_14->addWidget(label_36);


        gridLayout_3->addLayout(horizontalLayout_14, 0, 2, 1, 1);

        label_27 = new QLabel(layoutWidget_4);
        label_27->setObjectName(QString::fromUtf8("label_27"));

        gridLayout_3->addWidget(label_27, 0, 3, 1, 1);

        horizontalLayout_16 = new QHBoxLayout();
        horizontalLayout_16->setObjectName(QString::fromUtf8("horizontalLayout_16"));
        lineEdit_alpha2_velS = new QLineEdit(layoutWidget_4);
        lineEdit_alpha2_velS->setObjectName(QString::fromUtf8("lineEdit_alpha2_velS"));
        lineEdit_alpha2_velS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha2_velS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha2_velS->setReadOnly(true);

        horizontalLayout_16->addWidget(lineEdit_alpha2_velS);

        label_32 = new QLabel(layoutWidget_4);
        label_32->setObjectName(QString::fromUtf8("label_32"));

        horizontalLayout_16->addWidget(label_32);


        gridLayout_3->addLayout(horizontalLayout_16, 0, 4, 1, 1);

        label_28 = new QLabel(layoutWidget_4);
        label_28->setObjectName(QString::fromUtf8("label_28"));

        gridLayout_3->addWidget(label_28, 1, 0, 1, 1);

        horizontalLayout_17 = new QHBoxLayout();
        horizontalLayout_17->setObjectName(QString::fromUtf8("horizontalLayout_17"));
        lineEdit_alpha2_poserrS = new QLineEdit(layoutWidget_4);
        lineEdit_alpha2_poserrS->setObjectName(QString::fromUtf8("lineEdit_alpha2_poserrS"));
        lineEdit_alpha2_poserrS->setCursor(QCursor(Qt::ArrowCursor));
        lineEdit_alpha2_poserrS->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        lineEdit_alpha2_poserrS->setReadOnly(true);

        horizontalLayout_17->addWidget(lineEdit_alpha2_poserrS);

        label_39 = new QLabel(layoutWidget_4);
        label_39->setObjectName(QString::fromUtf8("label_39"));

        horizontalLayout_17->addWidget(label_39);


        gridLayout_3->addLayout(horizontalLayout_17, 1, 1, 1, 1);

        horizontalSpacer_5 = new QSpacerItem(158, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer_5, 1, 3, 1, 2);

        layoutWidget_6 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_6->setObjectName(QString::fromUtf8("layoutWidget_6"));
        layoutWidget_6->setGeometry(QRect(440, 170, 231, 111));
        gridLayout_15 = new QGridLayout(layoutWidget_6);
        gridLayout_15->setObjectName(QString::fromUtf8("gridLayout_15"));
        gridLayout_15->setContentsMargins(0, 0, 0, 0);
        label_alpha1_homed = new QLabel(layoutWidget_6);
        label_alpha1_homed->setObjectName(QString::fromUtf8("label_alpha1_homed"));

        gridLayout_15->addWidget(label_alpha1_homed, 0, 0, 1, 1);

        label_54 = new QLabel(layoutWidget_6);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        gridLayout_15->addWidget(label_54, 0, 1, 1, 1);

        label_alpha1_soft_limitP = new QLabel(layoutWidget_6);
        label_alpha1_soft_limitP->setObjectName(QString::fromUtf8("label_alpha1_soft_limitP"));

        gridLayout_15->addWidget(label_alpha1_soft_limitP, 0, 2, 1, 1);

        label_55 = new QLabel(layoutWidget_6);
        label_55->setObjectName(QString::fromUtf8("label_55"));

        gridLayout_15->addWidget(label_55, 0, 3, 1, 1);

        label_alpha1_soft_limitM = new QLabel(layoutWidget_6);
        label_alpha1_soft_limitM->setObjectName(QString::fromUtf8("label_alpha1_soft_limitM"));

        gridLayout_15->addWidget(label_alpha1_soft_limitM, 1, 2, 1, 1);

        label_75 = new QLabel(layoutWidget_6);
        label_75->setObjectName(QString::fromUtf8("label_75"));

        gridLayout_15->addWidget(label_75, 1, 3, 1, 1);

        label_alpha1_vel_limit = new QLabel(layoutWidget_6);
        label_alpha1_vel_limit->setObjectName(QString::fromUtf8("label_alpha1_vel_limit"));

        gridLayout_15->addWidget(label_alpha1_vel_limit, 2, 0, 1, 1);

        label_76 = new QLabel(layoutWidget_6);
        label_76->setObjectName(QString::fromUtf8("label_76"));

        gridLayout_15->addWidget(label_76, 2, 1, 1, 1);

        label_alpha1_hard_limitP = new QLabel(layoutWidget_6);
        label_alpha1_hard_limitP->setObjectName(QString::fromUtf8("label_alpha1_hard_limitP"));

        gridLayout_15->addWidget(label_alpha1_hard_limitP, 2, 2, 1, 1);

        label_77 = new QLabel(layoutWidget_6);
        label_77->setObjectName(QString::fromUtf8("label_77"));

        gridLayout_15->addWidget(label_77, 2, 3, 1, 1);

        label_alpha1_acc_limit = new QLabel(layoutWidget_6);
        label_alpha1_acc_limit->setObjectName(QString::fromUtf8("label_alpha1_acc_limit"));

        gridLayout_15->addWidget(label_alpha1_acc_limit, 3, 0, 1, 1);

        label_78 = new QLabel(layoutWidget_6);
        label_78->setObjectName(QString::fromUtf8("label_78"));

        gridLayout_15->addWidget(label_78, 3, 1, 1, 1);

        label_alpha1_hard_limitM = new QLabel(layoutWidget_6);
        label_alpha1_hard_limitM->setObjectName(QString::fromUtf8("label_alpha1_hard_limitM"));

        gridLayout_15->addWidget(label_alpha1_hard_limitM, 3, 2, 1, 1);

        label_79 = new QLabel(layoutWidget_6);
        label_79->setObjectName(QString::fromUtf8("label_79"));

        gridLayout_15->addWidget(label_79, 3, 3, 1, 1);

        layoutWidget_7 = new QWidget(scrollAreaWidgetContents);
        layoutWidget_7->setObjectName(QString::fromUtf8("layoutWidget_7"));
        layoutWidget_7->setGeometry(QRect(840, 170, 231, 111));
        gridLayout_17 = new QGridLayout(layoutWidget_7);
        gridLayout_17->setObjectName(QString::fromUtf8("gridLayout_17"));
        gridLayout_17->setContentsMargins(0, 0, 0, 0);
        label_alpha2_homed = new QLabel(layoutWidget_7);
        label_alpha2_homed->setObjectName(QString::fromUtf8("label_alpha2_homed"));

        gridLayout_17->addWidget(label_alpha2_homed, 0, 0, 1, 1);

        label_80 = new QLabel(layoutWidget_7);
        label_80->setObjectName(QString::fromUtf8("label_80"));

        gridLayout_17->addWidget(label_80, 0, 1, 1, 1);

        label_alpha2_soft_limitP = new QLabel(layoutWidget_7);
        label_alpha2_soft_limitP->setObjectName(QString::fromUtf8("label_alpha2_soft_limitP"));

        gridLayout_17->addWidget(label_alpha2_soft_limitP, 0, 2, 1, 1);

        label_81 = new QLabel(layoutWidget_7);
        label_81->setObjectName(QString::fromUtf8("label_81"));

        gridLayout_17->addWidget(label_81, 0, 3, 1, 1);

        label_alpha2_soft_limitM = new QLabel(layoutWidget_7);
        label_alpha2_soft_limitM->setObjectName(QString::fromUtf8("label_alpha2_soft_limitM"));

        gridLayout_17->addWidget(label_alpha2_soft_limitM, 1, 2, 1, 1);

        label_83 = new QLabel(layoutWidget_7);
        label_83->setObjectName(QString::fromUtf8("label_83"));

        gridLayout_17->addWidget(label_83, 1, 3, 1, 1);

        label_alpha2_vel_limit = new QLabel(layoutWidget_7);
        label_alpha2_vel_limit->setObjectName(QString::fromUtf8("label_alpha2_vel_limit"));

        gridLayout_17->addWidget(label_alpha2_vel_limit, 2, 0, 1, 1);

        label_84 = new QLabel(layoutWidget_7);
        label_84->setObjectName(QString::fromUtf8("label_84"));

        gridLayout_17->addWidget(label_84, 2, 1, 1, 1);

        label_alpha2_hard_limitP = new QLabel(layoutWidget_7);
        label_alpha2_hard_limitP->setObjectName(QString::fromUtf8("label_alpha2_hard_limitP"));

        gridLayout_17->addWidget(label_alpha2_hard_limitP, 2, 2, 1, 1);

        label_85 = new QLabel(layoutWidget_7);
        label_85->setObjectName(QString::fromUtf8("label_85"));

        gridLayout_17->addWidget(label_85, 2, 3, 1, 1);

        label_alpha2_acc_limit = new QLabel(layoutWidget_7);
        label_alpha2_acc_limit->setObjectName(QString::fromUtf8("label_alpha2_acc_limit"));

        gridLayout_17->addWidget(label_alpha2_acc_limit, 3, 0, 1, 1);

        label_86 = new QLabel(layoutWidget_7);
        label_86->setObjectName(QString::fromUtf8("label_86"));

        gridLayout_17->addWidget(label_86, 3, 1, 1, 1);

        label_alpha2_hard_limitM = new QLabel(layoutWidget_7);
        label_alpha2_hard_limitM->setObjectName(QString::fromUtf8("label_alpha2_hard_limitM"));

        gridLayout_17->addWidget(label_alpha2_hard_limitM, 3, 2, 1, 1);

        label_87 = new QLabel(layoutWidget_7);
        label_87->setObjectName(QString::fromUtf8("label_87"));

        gridLayout_17->addWidget(label_87, 3, 3, 1, 1);

        DirectM2->setWidget(scrollAreaWidgetContents);

        retranslateUi(DirectM2);
        QObject::connect(radioButton_tz_step_spec, SIGNAL(toggled(bool)), lineEdit_tz_step_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_alpha1_step_spec, SIGNAL(toggled(bool)), lineEdit_alpha1_step_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_tz_vel_spec, SIGNAL(toggled(bool)), lineEdit_tz_vel_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_tz_acc_spec, SIGNAL(toggled(bool)), lineEdit_tz_acc_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_alpha1_vel_spec, SIGNAL(toggled(bool)), lineEdit_alpha1_vel_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_alpha1_acc_spec, SIGNAL(toggled(bool)), lineEdit_alpha1_acc_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_alpha2_vel_spec, SIGNAL(toggled(bool)), lineEdit_alpha2_vel_spec, SLOT(setEnabled(bool)));
        QObject::connect(radioButton_alpha2_acc_spec, SIGNAL(toggled(bool)), lineEdit_alpha2_acc_spec, SLOT(setEnabled(bool)));

        QMetaObject::connectSlotsByName(DirectM2);
    } // setupUi

    void retranslateUi(QScrollArea *DirectM2)
    {
        DirectM2->setWindowTitle(QApplication::translate("DirectM2", "Direct M2", 0, QApplication::UnicodeUTF8));
        groupBox_16->setTitle(QApplication::translate("DirectM2", "Positionning", 0, QApplication::UnicodeUTF8));
        pushButton_tz_go->setText(QApplication::translate("DirectM2", "Go", 0, QApplication::UnicodeUTF8));
        label_12->setText(QApplication::translate("DirectM2", "target point", 0, QApplication::UnicodeUTF8));
        label_10->setText(QApplication::translate("DirectM2", "mm", 0, QApplication::UnicodeUTF8));
        label_21->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600; color:#ff0000;\">ALPHA1</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        groupBox_13->setTitle(QApplication::translate("DirectM2", "Translation status", 0, QApplication::UnicodeUTF8));
        label_16->setText(QApplication::translate("DirectM2", "  Warning", 0, QApplication::UnicodeUTF8));
        pushButton_tz_warning->setText(QApplication::translate("DirectM2", "15", 0, QApplication::UnicodeUTF8));
        pushButton_tz_reset->setText(QApplication::translate("DirectM2", "Reset", 0, QApplication::UnicodeUTF8));
        label_tz_homed->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_homed->setText(QString());
        label_41->setText(QApplication::translate("DirectM2", "Homed", 0, QApplication::UnicodeUTF8));
        label_tz_soft_limitP->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_soft_limitP->setText(QString());
        label_42->setText(QApplication::translate("DirectM2", "Soft limit +", 0, QApplication::UnicodeUTF8));
        label_tz_brake->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_brake->setText(QString());
        label_44->setText(QApplication::translate("DirectM2", "Brake on", 0, QApplication::UnicodeUTF8));
        label_tz_soft_limitM->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_soft_limitM->setText(QString());
        label_45->setText(QApplication::translate("DirectM2", "Soft limit -", 0, QApplication::UnicodeUTF8));
        label_tz_vel_limit->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_vel_limit->setText(QString());
        label_47->setText(QApplication::translate("DirectM2", "Vel limit reached", 0, QApplication::UnicodeUTF8));
        label_tz_hard_limitP->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_hard_limitP->setText(QString());
        label_49->setText(QApplication::translate("DirectM2", "Hard limit +", 0, QApplication::UnicodeUTF8));
        label_tz_acc_limit->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_acc_limit->setText(QString());
        label_52->setText(QApplication::translate("DirectM2", "Acc limit reached", 0, QApplication::UnicodeUTF8));
        label_tz_hard_limitM->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_tz_hard_limitM->setText(QString());
        label_53->setText(QApplication::translate("DirectM2", "Hard limit -", 0, QApplication::UnicodeUTF8));
        groupBox_15->setTitle(QApplication::translate("DirectM2", "Acceleration (mm/s\302\262)", 0, QApplication::UnicodeUTF8));
        radioButton_tz_acc_default->setText(QApplication::translate("DirectM2", "Default", 0, QApplication::UnicodeUTF8));
        label_43->setText(QApplication::translate("DirectM2", "000 ", 0, QApplication::UnicodeUTF8));
        radioButton_tz_acc_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_17->setTitle(QApplication::translate("DirectM2", "Continuous", 0, QApplication::UnicodeUTF8));
        pushButton_tz_dirM->setText(QApplication::translate("DirectM2", "- Dir", 0, QApplication::UnicodeUTF8));
        pushButton_tz_dirP->setText(QApplication::translate("DirectM2", "+ Dir", 0, QApplication::UnicodeUTF8));
        groupBox_20->setTitle(QApplication::translate("DirectM2", "Continuous", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_dirM->setText(QApplication::translate("DirectM2", "- Dir", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_dirP->setText(QApplication::translate("DirectM2", "+ Dir", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_stop->setText(QApplication::translate("DirectM2", "STOP", 0, QApplication::UnicodeUTF8));
        groupBox_14->setTitle(QApplication::translate("DirectM2", "Velocity (mm/s)", 0, QApplication::UnicodeUTF8));
        radioButton_tz_vel_fast->setText(QApplication::translate("DirectM2", "Fast", 0, QApplication::UnicodeUTF8));
        radioButton_tz_vel_mid->setText(QApplication::translate("DirectM2", "Mid", 0, QApplication::UnicodeUTF8));
        radioButton_tz_vel_slow->setText(QApplication::translate("DirectM2", "Slow", 0, QApplication::UnicodeUTF8));
        radioButton_tz_vel_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        label_11->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600; color:#ff0000;\">TRANSLATION</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        groupBox_18->setTitle(QApplication::translate("DirectM2", "Step (mm)", 0, QApplication::UnicodeUTF8));
        radioButton_tz_step1->setText(QApplication::translate("DirectM2", "1", 0, QApplication::UnicodeUTF8));
        pushButton_tz_stepM->setText(QApplication::translate("DirectM2", "Step -", 0, QApplication::UnicodeUTF8));
        radioButton_tz_step01->setText(QApplication::translate("DirectM2", "0.1", 0, QApplication::UnicodeUTF8));
        pushButton_tz_stepP->setText(QApplication::translate("DirectM2", "Step +", 0, QApplication::UnicodeUTF8));
        radioButton_tz_step001->setText(QApplication::translate("DirectM2", "0.01", 0, QApplication::UnicodeUTF8));
        radioButton_tz_step_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        pushButton_tz_stop->setText(QApplication::translate("DirectM2", "STOP", 0, QApplication::UnicodeUTF8));
        pushButton_tz_axis->setText(QApplication::translate("DirectM2", "Axis\n"
"Enabled", 0, QApplication::UnicodeUTF8));
        pushButton_tz_home->setText(QApplication::translate("DirectM2", "Homing", 0, QApplication::UnicodeUTF8));
        pushButton_tz_park->setText(QApplication::translate("DirectM2", "Park", 0, QApplication::UnicodeUTF8));
        groupBox_22->setTitle(QApplication::translate("DirectM2", "Step (\")", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_step1->setText(QApplication::translate("DirectM2", "1", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_stepM->setText(QApplication::translate("DirectM2", "Step -", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_step01->setText(QApplication::translate("DirectM2", "0.1", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_stepP->setText(QApplication::translate("DirectM2", "Step +", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_step001->setText(QApplication::translate("DirectM2", "0.01", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_step_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_21->setTitle(QApplication::translate("DirectM2", "Velocity (\342\200\263/s)", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_vel_fast->setText(QApplication::translate("DirectM2", "Fast", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_vel_mid->setText(QApplication::translate("DirectM2", "Mid", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_vel_slow->setText(QApplication::translate("DirectM2", "Slow", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_vel_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_19->setTitle(QApplication::translate("DirectM2", "Alpha1 status", 0, QApplication::UnicodeUTF8));
        label_17->setText(QApplication::translate("DirectM2", "  Warning", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_warning->setText(QApplication::translate("DirectM2", "15", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_reset->setText(QApplication::translate("DirectM2", "Reset", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_axis->setText(QApplication::translate("DirectM2", "Axis\n"
"Enabled", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_home_2->setText(QApplication::translate("DirectM2", "Homing", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_park_2->setText(QApplication::translate("DirectM2", "Park", 0, QApplication::UnicodeUTF8));
        groupBox_24->setTitle(QApplication::translate("DirectM2", "Acceleration (\342\200\263/s\302\262)", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_acc_default->setText(QApplication::translate("DirectM2", "Default", 0, QApplication::UnicodeUTF8));
        label_46->setText(QApplication::translate("DirectM2", "000", 0, QApplication::UnicodeUTF8));
        radioButton_alpha1_acc_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_23->setTitle(QApplication::translate("DirectM2", "Positionning", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_targetM->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_targetS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("DirectM2", "\302\260", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("DirectM2", "\342\200\262", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("DirectM2", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_13->setText(QApplication::translate("DirectM2", "target point", 0, QApplication::UnicodeUTF8));
        pushButton_alpha1_go->setText(QApplication::translate("DirectM2", "Go", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_targetD->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        groupBox_25->setTitle(QApplication::translate("DirectM2", "Alpha2 status", 0, QApplication::UnicodeUTF8));
        label_25->setText(QApplication::translate("DirectM2", "  Warning", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_warning->setText(QApplication::translate("DirectM2", "15", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_reset->setText(QApplication::translate("DirectM2", "Reset", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_stop->setText(QApplication::translate("DirectM2", "STOP", 0, QApplication::UnicodeUTF8));
        groupBox_26->setTitle(QApplication::translate("DirectM2", "Step (\")", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_step1->setText(QApplication::translate("DirectM2", "1", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_stepM->setText(QApplication::translate("DirectM2", "Step -", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_step01->setText(QApplication::translate("DirectM2", "0.1", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_stepP->setText(QApplication::translate("DirectM2", "Step +", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_step001->setText(QApplication::translate("DirectM2", "0.01", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_step_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_27->setTitle(QApplication::translate("DirectM2", "Velocity (\342\200\263/s)", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_vel_fast->setText(QApplication::translate("DirectM2", "Fast", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_vel_mid->setText(QApplication::translate("DirectM2", "Mid", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_vel_slow->setText(QApplication::translate("DirectM2", "Slow", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_vel_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_axis->setText(QApplication::translate("DirectM2", "Axis\n"
"Enabled", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_home->setText(QApplication::translate("DirectM2", "Homing", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_park->setText(QApplication::translate("DirectM2", "Park", 0, QApplication::UnicodeUTF8));
        groupBox_28->setTitle(QApplication::translate("DirectM2", "Continuous", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_dirM->setText(QApplication::translate("DirectM2", "- Dir", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_dirP->setText(QApplication::translate("DirectM2", "+ Dir", 0, QApplication::UnicodeUTF8));
        groupBox_29->setTitle(QApplication::translate("DirectM2", "Acceleration (\342\200\263/s\302\262)", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_acc_default->setText(QApplication::translate("DirectM2", "Default", 0, QApplication::UnicodeUTF8));
        label_48->setText(QApplication::translate("DirectM2", "000", 0, QApplication::UnicodeUTF8));
        radioButton_alpha2_acc_spec->setText(QApplication::translate("DirectM2", "Specified", 0, QApplication::UnicodeUTF8));
        groupBox_30->setTitle(QApplication::translate("DirectM2", "Positionning", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_targetD->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_4->setText(QApplication::translate("DirectM2", "\342\200\263", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_targetS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_targetM->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_5->setText(QApplication::translate("DirectM2", "\302\260", 0, QApplication::UnicodeUTF8));
        label_14->setText(QApplication::translate("DirectM2", "target point", 0, QApplication::UnicodeUTF8));
        label_6->setText(QApplication::translate("DirectM2", "\342\200\262", 0, QApplication::UnicodeUTF8));
        pushButton_alpha2_go->setText(QApplication::translate("DirectM2", "Go", 0, QApplication::UnicodeUTF8));
        label_29->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:20pt; font-weight:600; color:#ff0000;\">ALPHA2</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_22->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Position:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("DirectM2", "mm", 0, QApplication::UnicodeUTF8));
        label_23->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Velocity:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        label_9->setText(QApplication::translate("DirectM2", "mm/s", 0, QApplication::UnicodeUTF8));
        label_24->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Pos error:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_tz_poserr->setText(QString());
        label_8->setText(QApplication::translate("DirectM2", "mm", 0, QApplication::UnicodeUTF8));
        label_18->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Position:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_posM->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_37->setText(QApplication::translate("DirectM2", "\342\200\262", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_posS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_35->setText(QApplication::translate("DirectM2", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_19->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Velocity:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_velS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_31->setText(QApplication::translate("DirectM2", "\342\200\263/s", 0, QApplication::UnicodeUTF8));
        label_20->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Pos error:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha1_poserrS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_34->setText(QApplication::translate("DirectM2", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_26->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Position:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_posM->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_38->setText(QApplication::translate("DirectM2", "\342\200\262", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_posS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_36->setText(QApplication::translate("DirectM2", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_27->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Velocity:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_velS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_32->setText(QApplication::translate("DirectM2", "\342\200\263/s", 0, QApplication::UnicodeUTF8));
        label_28->setText(QApplication::translate("DirectM2", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:10pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" color:#0055ff;\">Pos error:</span></p></body></html>", 0, QApplication::UnicodeUTF8));
        lineEdit_alpha2_poserrS->setText(QApplication::translate("DirectM2", "0", 0, QApplication::UnicodeUTF8));
        label_39->setText(QApplication::translate("DirectM2", "\342\200\263", 0, QApplication::UnicodeUTF8));
        label_alpha1_homed->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_homed->setText(QString());
        label_54->setText(QApplication::translate("DirectM2", "Homed", 0, QApplication::UnicodeUTF8));
        label_alpha1_soft_limitP->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_soft_limitP->setText(QString());
        label_55->setText(QApplication::translate("DirectM2", "Soft limit +", 0, QApplication::UnicodeUTF8));
        label_alpha1_soft_limitM->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_soft_limitM->setText(QString());
        label_75->setText(QApplication::translate("DirectM2", "Soft limit -", 0, QApplication::UnicodeUTF8));
        label_alpha1_vel_limit->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_vel_limit->setText(QString());
        label_76->setText(QApplication::translate("DirectM2", "Vel limit reached", 0, QApplication::UnicodeUTF8));
        label_alpha1_hard_limitP->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_hard_limitP->setText(QString());
        label_77->setText(QApplication::translate("DirectM2", "Hard limit +", 0, QApplication::UnicodeUTF8));
        label_alpha1_acc_limit->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_acc_limit->setText(QString());
        label_78->setText(QApplication::translate("DirectM2", "Acc limit reached", 0, QApplication::UnicodeUTF8));
        label_alpha1_hard_limitM->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha1_hard_limitM->setText(QString());
        label_79->setText(QApplication::translate("DirectM2", "Hard limit -", 0, QApplication::UnicodeUTF8));
        label_alpha2_homed->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(255, 0, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_homed->setText(QString());
        label_80->setText(QApplication::translate("DirectM2", "Homed", 0, QApplication::UnicodeUTF8));
        label_alpha2_soft_limitP->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_soft_limitP->setText(QString());
        label_81->setText(QApplication::translate("DirectM2", "Soft limit +", 0, QApplication::UnicodeUTF8));
        label_alpha2_soft_limitM->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_soft_limitM->setText(QString());
        label_83->setText(QApplication::translate("DirectM2", "Soft limit -", 0, QApplication::UnicodeUTF8));
        label_alpha2_vel_limit->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_vel_limit->setText(QString());
        label_84->setText(QApplication::translate("DirectM2", "Vel limit reached", 0, QApplication::UnicodeUTF8));
        label_alpha2_hard_limitP->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_hard_limitP->setText(QString());
        label_85->setText(QApplication::translate("DirectM2", "Hard limit +", 0, QApplication::UnicodeUTF8));
        label_alpha2_acc_limit->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_acc_limit->setText(QString());
        label_86->setText(QApplication::translate("DirectM2", "Acc limit reached", 0, QApplication::UnicodeUTF8));
        label_alpha2_hard_limitM->setStyleSheet(QApplication::translate("DirectM2", "background-color: rgb(0, 255, 0);", 0, QApplication::UnicodeUTF8));
        label_alpha2_hard_limitM->setText(QString());
        label_87->setText(QApplication::translate("DirectM2", "Hard limit -", 0, QApplication::UnicodeUTF8));
        Q_UNUSED(DirectM2);
    } // retranslateUi

};

namespace Ui {
    class DirectM2: public Ui_DirectM2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIRECT_M2_H
