//
// C++ Implementation: track_thread
//
// Description:
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "track_thread.h"
//#include "tracking.h"
#include <math.h>
#include "signs.h"
TrackStar trackstar;
//tracking,send out data to UMAC
int Time=0;//定时计数

QTimer *timer_tracking;
extern   long N_row;//存当前的行号（也就是当前时间），用于查star表
extern    long N_row_LAST;//存上次的行号（也就是当前时间），用于查star表
extern QString starTable[TABLE_NUM];
StarTarget target;
bool	flag_send=false;//禁止输出数据给UMAC(MA)
extern int firstPoint_delay;
extern double AZ_TrackError;//extern
extern double AZ_TrackTarget;//最终跟踪使用的传递AZ跟踪目标extern
extern double ALT_TrackError;//extern
extern double ALT_TrackTarget;//最终跟踪使用的传递ALT跟踪目标,extern

extern double AZ_TrackTargetNew;//跟踪使用的传递AZ跟踪目标,加偏置
extern double ALT_TrackTargetNew;//跟踪使用的传递ALT跟踪目标,加偏置
extern bool flag_firstPoint;//如果是刚刚追踪的第一点，则加大追踪时间，以减小加速度
//double dec_star,ha_star;//从lookup table得到，存于文件madata.txt给S－H,   ???????
//QString Ha,DEC;//时角、赤纬,给S-H(socket) ????
//char S_dec[15],S_ha[15];//赤纬,时角,(自己计算)写文件madata.txt给S-H   ?????
//QString S_dec,S_ha;//赤纬,时角,(自己计算)写文件madata.txt给S-H   ?????
double azPosReal_Degree_forError=0;//az实际位置,与AZ_TrackTarget同时在track（）中记录，用于求误差
double altPosReal_Degree_forError=0;//alt实际位置,与ALT_TrackTarget同时在track（）中记录，用于求误差
double altPosReal_Degree;//alt实际位置extern
double azPosReal_Degree;//az实际位置extern
extern double alt_offset,az_offset;//分别是由于光轴不准AZ和ALT的修正值//-25"和7"extern
double alt_offset_last=0,az_offset_last=0;
extern double alt_correct,az_correct;//extern
extern double az_correct_last,alt_correct_last;//extern

double Az_dError[10],Alt_dError[10];
int iError=0;
int iErrorStart=0;
bool flag_bRecordError=1;
extern bool flag_TrackingSave;//the flag of save tracking data

extern bool flag_TrackstarAzAlt;
long int floatNo=0;//发布命令的流水号extern
int flag_line=1;//从第一行启动(用于PC脱离UMAC 测试发送数据)
//for save
#define N 30     //matrix AzData,AzToUMAC rows
QString AzToUMAC[N][3];//just for save AzToUMAC.txt,debug //保存发给UMAC的每条命令，正式工作时注销
int Y=0;//counter for save AzToUMAC.txt

//point
double Az_model=0;
double Alt_model=0;
double AW=-4.7547;
double AN=-8.2328;
double CA=117.1813;
double IE=43.0447;
double IA=-144.0055;
double TF=20.0785;
double p219=0;

TrackThread::TrackThread ( Tracking * parent )
{
	m_parent = parent;
	timer_tracking = new QTimer;
}

void TrackThread::run()
{
	connect ( timer_tracking,SIGNAL ( timeout() ),this,SLOT ( sendDataToUMAC() ) );
	timer_tracking->start ( 1000 );
	exec();
}

void  TrackThread::sendDataToUMAC()
{

	double utc2=0,tmp_time=0;
	double utc=0;
	int h,m;//hour,miniute
	double second;//second
	QStringList  list;



	/////////////////////////////get UTC time/////////////////////////////////////
	QDateTime dt;
	dt=QDateTime::currentDateTime();
	QDate date;
	QTime time;
	date=dt.date();
	time=dt.time();


	//utc 中不是UTC时间，而是当地时间
	utc= ( time.hour() ) *3600+time.minute() *60.+time.second() +time.msec() /1000.0;//当前时间
	//////////////////求当前目标值/////////////
	//Time++;

	//if(Time==10)//1秒钟 发送1组
	//N_row=N_row++;
	{
		Time=0;

///////查表中对应此时间的位置值//////////////////////////////////////////////////
		for ( long j=N_row_LAST+5;j< ( TABLE_NUM-2 );j++ ) //从上次N_row记录开始读
		{

			list = starTable[j].split ( QRegExp ( "\\s+" ),QString::SkipEmptyParts );//以空格为基础拆分字符串


			target.cDate=list[0];
			target.cTime=list[1];
			target.cAzimuth=list[2];
			target.cAltitude=list[3];

			tmp_time=target.cTime.toDouble();
			h=int ( tmp_time/10000 );
			m=int ( ( tmp_time-h*10000 ) /100 );
			second=tmp_time-h*10000-m*100;
			utc2=h*3600+m*60+second;
			double delta_utc=utc-utc2;
			if ( fabs ( delta_utc ) <0.1 )
			{
				N_row=j;
				N_row_LAST=N_row;
				flag_send=true;//允许输出数据给UMAC
				target.cDate=list[0];
				target.cTime=list[1];
				target.cAzimuth=list[2];
				target.cAltitude=list[3];
				// S_ha=list[5];
				//S_dec=list[6];

				double az_1=target.cAzimuth.toDouble();
				double alt_1=target.cAltitude.toDouble();

				list = starTable[N_row+1].split ( QRegExp ( "\\s+" ),QString::SkipEmptyParts );//以空格为基础拆分字符串

				double az_2= target.cAzimuth.toDouble();
				double alt_2=target.cAltitude.toDouble();
				/////////////AZ  ALT  目标及时角、赤纬////////////////////////////
				AZ_TrackTarget=az_1+ ( az_2-az_1 ) *10*delta_utc;//AZ跟踪目标数据给AZ_TrackTarget，用于各个文件间数据交换
				ALT_TrackTarget=alt_1+ ( alt_2-alt_1 ) *10*delta_utc;
				//dec_star=S_dec.toDouble();
				//ha_star=S_ha.toDouble();
				azPosReal_Degree_forError=azPosReal_Degree;//取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差
				altPosReal_Degree_forError=altPosReal_Degree;//取得ALT_TrackTarget同时刻的实际位置，以备计算跟踪误差
				AZ_TrackError= ( AZ_TrackTarget-azPosReal_Degree_forError ) *3600;
				ALT_TrackError= ( ALT_TrackTarget-altPosReal_Degree_forError ) *3600;

				double A=AZ_TrackTarget*3.1415926535897932384626433832795/180.0;
				double E=ALT_TrackTarget*3.1415926535897932384626433832795/180.0;
				//	Az_model=AW*cos(A)*tan(E)+AN*sin(A)*tan(E)+CA/cos(E)+IA;
				//	Alt_model=-AW*sin(A)+AN*cos(A)-IE+TF*cos(E);

				if ( flag_bRecordError==1 )
				{
					Az_dError[iError]=AZ_TrackError;
					Alt_dError[iError]=ALT_TrackError;
					iError++;
					if ( iError==10 ) iError=0;
				}

				if ( fabs ( az_offset_last-az_offset ) >1 ||
				        fabs ( alt_offset_last-alt_offset ) >1 ||
				        fabs ( az_correct_last-az_correct ) >1 ||
				        fabs ( alt_correct_last-alt_correct ) >1 ) iErrorStart=100;
				iErrorStart++;
				if ( iErrorStart > 120 )
				{
					double az_AvError=0;
					double alt_AvError=0;
					for ( int ti=0; ti<10; ti++ )
					{
						az_AvError+=Az_dError[ti];
						alt_AvError+=Alt_dError[ti];
					}
					az_AvError/=10;
					alt_AvError/=10;
					az_AvError-=AZ_TrackError;
					alt_AvError-=ALT_TrackError;
					if ( fabs ( az_AvError ) >5 || fabs ( alt_AvError ) >5 )
					{
						iErrorStart=105;
						flag_bRecordError=0;
						az_correct-=az_AvError;
						alt_correct-=alt_AvError;
					}
					else flag_bRecordError=1;
				}

				az_offset_last=az_offset;
				alt_offset_last=alt_offset;
				az_correct_last=az_correct;
				alt_correct_last=alt_correct;
				if ( flag_TrackingSave )
				{
					//SaveDataNoRMS();//以方便MATLAB数据分析,
					//SaveAltDataNoRMS();
				}
				break;
			}

		}


	}


	/////////////////////判断星表是否结束///////////////////////////////////////////////////////////
	if ( ( 10+10+N_row ) > ( TABLE_NUM-firstPoint_delay*10 ) ||N_row==0 ) //设过第一点为30秒
		// if(N_row>(TABLE_NUM-6000))//
	{
		if ( timer_tracking->isActive () )
			timer_tracking->stop();

		flag_TrackstarAzAlt=false;
		QMessageBox msgBox ( QMessageBox::NoIcon,"Warning!","Lookup table end!" );

		msgBox.setText ( "Lookup table end!" );
		msgBox.setStyleSheet ( "QPushButton { background-color: rgb(255, 85, 0); color: rgb(85, 255, 0); }" );
		msgBox.exec();

		quit();//quit from thread


		// return;
	}




	ToUMAC();


}




void TrackThread::ToUMAC()
{

	// alt_offset=0;
//   az_offset=0;//分别是由于光轴不准AZ和ALT的修正值//-25"和7"extern


///////////////////与UMAC通讯///////////////////////////////////
	/*
	  CString s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s_out;
	CString TM1,TM2,TM3,TM4,TM5,TM6,TM7,TM8,TM9,TM10;
	  

	TCHAR buf[255];
	  TCHAR *p1,*p2;*/

	//
	int t1=0,t1_old=0;
	QString AZoutData;
	QString tmp,s1,s2,s3,s4;
	double tmp_val;
	QString t2="100";//TM
	s3=",";
	s4=";";
	QStringList  list;
	QString  s1_alt,s2_alt;
	QByteArray ba;
	const char *comm;
	QString TM1,TM2,TM3,TM4,TM5,TM6,TM7,TM8,TM9,TM10;
//P145 给UMAC标志，0：新数据(本程序在每次送出新位置前清零).1 2：没有新数据（由UMAC负责置1 2,要求第1组或第2组数据）
	QString str;
	SQUMAC::instance_p()->QcommCmdPMAC ( "P145",str );
	//if(( flag_line==1)&&flag_send)
	if ( !QString::compare ( str, "1" ) &&flag_send ) //check P145,p145=1
	{
		flag_send=false;//禁止输出数据给UMAC

//           flag_firstPoint=false;//取消第一点
		if ( flag_firstPoint ) //如果是刚刚追踪的第一点，则加大追踪时间，以减小加速度
		{
			t1=firstPoint_delay*1000;//时间ms
			flag_firstPoint=false;
		}
		else
		{
			t1=100;
		}

		//if(t1!=t1_old)
		{
			TM1="P140="+QString::number ( t1, 10 );
			TM2="P150="+t2;
			TM3="P160="+t2;
			TM4="P170="+t2;
			TM5="P180="+t2;
			TM6="P190="+t2;
			TM7="P200="+t2;
			TM8="P210="+t2;
			TM9="P220="+t2;
			TM10="P230="+t2;
		}
		// else
		// {
		//		TM1=TM2=TM3=TM4=TM5=TM6=TM7=TM8=TM9=TM10="";
		// }


		AZoutData="";
		s1="";
		s2="";
		s1_alt="";
		s2_alt="";
		for ( int i=0;i<=9;i++ )
		{
			list = starTable[10+N_row].split ( QRegExp ( "\\s+" ),QString::SkipEmptyParts );//以空格为基础拆分字符串
			target.cDate=list[0];
			target.cTime=list[1];
			target.cAzimuth=list[2];
			target.cAltitude=list[3];

			N_row++;

			switch ( i )
			{
				case 0: s1=TM1+s1+"P141=";break;
				case 1: s1=TM2+s1+"P151=";break;
				case 2: s1=TM3+s1+"P161=";break;
				case 3: s1=TM4+s1+"P171=";break;
				case 4: s1=TM5+s1+"P181=";break;
				case 5: s2=TM6+s2+"P191=";break;
				case 6: s2=TM7+s2+"P201=";break;
				case 7: s2=TM8+s2+"P211=";break;
				case 8: s2=TM9+s2+"P221=";break;
				case 9: s2=TM10+s2+"P231=";break;
			}
			//Az
			if ( i>=0&&i<=4 )
			{
				tmp_val=target.cAzimuth.toDouble();
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CCD校正值
				//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val+az_correct+az_offset+Az_model;
				if ( i==0 )
					AZ_TrackTargetNew=tmp_val/3600;//跟踪使用的传递AZ跟踪目标,加偏置
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//az
				s1=s1+tmp;
				if ( i==0 )
					AZoutData=AZoutData+target.cTime+s3+target.cAzimuth+s4;
			}
			if ( i>=5&&i<=9 )
			{
				tmp_val=target.cAzimuth.toDouble();
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CCD校正值
				tmp_val=tmp_val+az_correct+az_offset+Az_model;                                                       //az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//az
				s2=s2+tmp;
				if ( i==9 )
					AZoutData=AZoutData+target.cTime+s3+target.cAzimuth+s4;
			}

			switch ( i )
			{
				case 0: s1_alt=TM1+s1_alt+"P142=";break;
				case 1: s1_alt=TM2+s1_alt+"P152=";break;
				case 2: s1_alt=TM3+s1_alt+"P162=";break;
				case 3: s1_alt=TM4+s1_alt+"P172=";break;
				case 4: s1_alt=TM5+s1_alt+"P182=";break;
				case 5: s2_alt=TM6+s2_alt+"P192=";break;
				case 6: s2_alt=TM7+s2_alt+"P202=";break;
				case 7: s2_alt=TM8+s2_alt+"P212=";break;
				case 8: s2_alt=TM9+s2_alt+"P222=";break;
				case 9: s2_alt=TM10+s2_alt+"P232=";break;//alt
			}
			//ALT
			if ( i>=0&&i<=4 )
			{
				tmp_val=target.cAltitude.toDouble();
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CD校正值
				tmp_val=tmp_val+alt_correct+alt_offset+Alt_model;//az_offset单位：秒，az_correct单位：度
				if ( i==0 )
					ALT_TrackTargetNew=tmp_val/3600;//跟踪使用的传递ALT跟踪目标,加偏置
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//alt
				s1_alt=s1_alt+tmp;

			}
			if ( i>=5&&i<=9 )
			{
				tmp_val=target.cAltitude.toDouble();
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CCD校正值
				//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val+alt_correct+alt_offset+Alt_model;//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//alt
				s2_alt=s2_alt+tmp;
			}
		}




		trackstar.cCmdtoAz=s1+s2;
		trackstar.cCmdtoAlt=s1_alt+s2_alt;
		ba= s1.toLatin1();
		//comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//AZ 前5个
		ba= s1_alt.toLatin1();
		//comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );////ALT 前5个
		SQUMAC::instance_p()->QcommCmdPMAC ( "P145=0",str );
		ba= s2.toLatin1();
		//comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//AZ 后5个

		ba= s2_alt.toLatin1();
		//comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//ALT 后5个


		floatNo++;//发布命令的流水号
		//  qDebug()<<"P145=1"<<N_row;
		//      qDebug()<<"az:"<<s1<<s2;

		//    qDebug()<<"alt:"<<s1_alt<<s2_alt;


		//         AzToUMAC[Y][0]=trackstar.cDateTime;
		//       tmp=QString::number(N_row, 10);
		//     AzToUMAC[Y][1]="N="+tmp+",";
		//    tmp=QString::number(Time, 10);
		//    AzToUMAC[Y][1]=AzToUMAC[Y][1]+tmp;
		// AzToUMAC[Y][2]=AZoutData;

		//	Y++;

		flag_line=2;
	}
	//////////2//////////
	//else if(( flag_line==2)&&flag_send)
	if ( !QString::compare ( str, "2" ) &&flag_send ) //check P145,p145=2

	{
		flag_send=false;//禁止输出数据给UMAC

		if ( flag_firstPoint ) //如果是刚刚追踪的第一点，则加大追踪时间，以减小加速度
		{
			t1=firstPoint_delay*1000;//时间ms
			flag_firstPoint=false;
		}
		else
		{
			t1=100;
		}
		//if(t1_old!=t1)
		{
			TM1="P240="+QString::number ( t1, 10 );
			TM2="P250="+t2;
			TM3="P260="+t2;
			TM4="P270="+t2;
			TM5="P280="+t2;
			TM6="P290="+t2;
			TM7="P300="+t2;
			TM8="P310="+t2;
			TM9="P320="+t2;
			TM10="P330="+t2;
		}
		//else
		//{
		//	TM1=TM2=TM3=TM4=TM5=TM6=TM7=TM8=TM9=TM10="";
		//}
		t1_old=t1;
		AZoutData="";
		s1="";
		s2="";
		s1_alt="";
		s2_alt="";
		for ( int i=0;i<=9;i++ )
		{
			list = starTable[10+N_row].split ( QRegExp ( "\\s+" ),QString::SkipEmptyParts );//以空格为基础拆分字符串
			target.cDate=list[0];
			target.cTime=list[1];
			target.cAzimuth=list[2];
			target.cAltitude=list[3];
			N_row++;

			switch ( i )
			{
				case 0: s1=TM1+s1+"P241=";break;
				case 1: s1=TM2+s1+"P251=";break;
				case 2: s1=TM3+s1+"P261=";break;
				case 3: s1=TM4+s1+"P271=";break;
				case 4: s1=TM5+s1+"P281=";break;
				case 5: s2=TM6+s2+"P291=";break;
				case 6: s2=TM7+s2+"P301=";break;
				case 7: s2=TM8+s2+"P311=";break;
				case 8: s2=TM9+s2+"P321=";break;
				case 9: s2=TM10+s2+"P331=";break;
			}

			if ( i>=0 && i<=4 )
			{
				tmp_val=target.cAzimuth.toDouble();//az
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CCD校正值
				tmp_val=tmp_val+az_correct+az_offset+Az_model;
				if ( i==0 )
					AZ_TrackTargetNew=tmp_val/3600;//跟踪使用的传递AZ跟踪目标,加偏置
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//az
				s1=s1+tmp;
				if ( i==0 )
					AZoutData=AZoutData+target.cTime+s3+target.cAzimuth+s4;
			}
			if ( i>=5 && i<=9 )
			{
				tmp_val=target.cAzimuth.toDouble();//az
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CCD校正值
				//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val+az_correct+az_offset+Az_model;
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//az
				s2=s2+tmp;
				if ( i==9 )
					AZoutData=AZoutData+target.cTime+s3+target.cAzimuth+s4;
			}

			switch ( i )
			{
				case 0: s1_alt=TM1+s1_alt+"P242=";break;
				case 1: s1_alt=TM2+s1_alt+"P252=";break;
				case 2: s1_alt=TM3+s1_alt+"P262=";break;
				case 3: s1_alt=TM4+s1_alt+"P272=";break;
				case 4: s1_alt=TM5+s1_alt+"P282=";break;
				case 5: s2_alt=TM6+s2_alt+"P292=";break;
				case 6: s2_alt=TM7+s2_alt+"P302=";break;
				case 7: s2_alt=TM8+s2_alt+"P312=";break;
				case 8: s2_alt=TM9+s2_alt+"P322=";break;
				case 9: s2_alt=TM10+s2_alt+"P332=";break;//alt
			}

			//ALT
			if ( i>=0 && i<=4 )
			{
				tmp_val=target.cAltitude.toDouble();
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋CCD校正值
				//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val+alt_correct+alt_offset+Alt_model;//az_offset单位：秒，az_correct单位：度
				if ( i==0 )
					ALT_TrackTargetNew=tmp_val/3600;//跟踪使用的传递ALT跟踪目标,加偏置
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//alt
				s1_alt=s1_alt+tmp;
			}
			if ( i>=5 && i<=9 )
			{
				tmp_val=target.cAltitude.toDouble();
				tmp_val=tmp_val*3600;//cts：位置＋自定义的偏移量＋上海台CCD校正值
				//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val+alt_correct+alt_offset+Alt_model;//az_offset单位：秒，az_correct单位：度
				tmp_val=tmp_val/CTS;
				tmp=QString::number ( long ( tmp_val ), 10 );//alt
				s2_alt=s2_alt+tmp;
			}

		}

		trackstar.cCmdtoAz=s1+s2;
		trackstar.cCmdtoAlt=s1_alt+s2_alt;

		ba= s1.toLatin1();
		comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//AZ 前5个
		ba= s1_alt.toLatin1();
		comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//ALT 前5个
		SQUMAC::instance_p()->QcommCmdPMAC ( "P145=0",str );
		ba= s2.toLatin1();
		comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//AZ 后5个

		ba= s2_alt.toLatin1();
		comm = ba.data();
		SQUMAC::instance_p()->QcommCmdPMAC ( ba,str );//ALT 后5个

		floatNo++;//发布命令的流水号
		//  qDebug()<<"P145=2"<<N_row;
		//  qDebug()<<"az:"<<s1<<s2;
		// qDebug()<<"alt:"<<s1_alt<<s2_alt;

		//  if(Y<=29)
		// {
		//  AzToUMAC[Y][0]=trackstar.cDateTime;
		//tmp=QString::number(N_row, 10);
		//AzToUMAC[Y][1]="N="+tmp+",";
		// tmp=QString::number(Time, 10);
		// AzToUMAC[Y][1]=AzToUMAC[Y][1]+tmp;
		//AzToUMAC[Y][2]=AZoutData;

		// }
		flag_line=1;
		//Y++;
	}


}
