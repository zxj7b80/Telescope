//
// C++ Interface: diag_azalt
//
// Description: 
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef DIAG_AZALT_H
#define DIAG_AZALT_H
#include <QtGui>
#include "ui_diag_azalt.h"
class MainWindow;
class DiagAzalt:public QWidget,private Ui::DiagAzalt
{
	Q_OBJECT
	public:
		DiagAzalt ( MainWindow *parent );
		virtual ~DiagAzalt();
		MainWindow *m_parent;
	protected:
		virtual void closeEvent ( QCloseEvent *event );
	private:
		QTimer *timer;
//		void initUi();
//		void connectDevice();
	private slots:
		void updateInterface();
};
#endif