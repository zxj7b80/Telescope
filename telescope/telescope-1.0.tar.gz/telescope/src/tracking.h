//
// C++ Interface: tracking
//
// Description: 
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef TRACKING_H
#define TRACKING_H

#include <QtGui>
#include "ui_tracking.h"
class TrackThread;
class CalculateThread;
class MainWindow;
class Tracking:public QScrollArea,private Ui::Tracking
{
	Q_OBJECT
	public:
		Tracking(MainWindow *parent);
		virtual ~Tracking();
		MainWindow *m_parent;
		CalculateThread *calculate_thread;
		TrackThread *track_thread;
		QTimer *timer_save_track_data;
		QTimer *timer_show_track_info;
	protected:
		virtual void closeEvent ( QCloseEvent *event );
	public:
		void initUi();
		void connectSignals();
		bool readStarTable();
		void cmdOCS(QHash<QString,QString>);
	private slots:
		void updateInterface(QHash<QString,QString> map);
		void showTrackInfo();
		void on_pushButton_track_clicked();
		void on_pushButton_stop_clicked();
		void on_pushButton_calculate_clicked();
		void on_calculate_thread_finished();
		bool saveStarTable();
		bool saveTrackData();
		bool storeTrackData();
		bool storeAzTrackRMS();
		bool storeAltTrackRMS();
		bool storeAzTrackNoRMS();
		bool storeAltTrackNoRMS();
};
#endif