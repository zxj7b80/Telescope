//
// C++ Implementation: direct_azalt
//
// Description:
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "main_window.h"
#include "direct_azalt.h"
#include "signs.h"
#include "server.h"
#define ERROR   5
DirectAzalt::DirectAzalt ( MainWindow *parent):az_error(ERROR,false),az_error_info(ERROR,""),alt1_error(ERROR,false),alt1_error_info(ERROR,""),alt2_error(ERROR,false),alt2_error_info(ERROR,"")/*:QScrollArea(parent)*/
{
	m_parent = parent;
	setupUi ( this );
//	az_error.pushback(false);
	SQUMAC::instance_p()->timer_directazalt->start(500);
	connect(SQUMAC::instance_p(),SIGNAL(UMACInfoThrown(QHash<QString,QString>)),this,SLOT(updateInterface(QHash<QString,QString>)));
	connectSignals();
	timer_az = new QTimer();
	connect(timer_az,SIGNAL(timeout()),this,SLOT(infoAzOCS()));
	timer_alt = new QTimer();
	connect(timer_alt,SIGNAL(timeout()),this,SLOT(infoAltOCS()));
//	initUi();
}

DirectAzalt::~DirectAzalt()
{
	qDebug("DirectAzalt");
	deleteLater();
//	direct_azalt_thread->deleteLater();
}

void DirectAzalt::connectSignals()
{

}
void DirectAzalt::initUi()
{
	switch ( SMySetting::instance_p()->value ( "az_alt/az_vel" ).toInt() )
	{
		case VEL_FAST:radioButton_az_vel_fast->setChecked ( TRUE );break;
		case VEL_MID: radioButton_az_vel_mid->setChecked ( TRUE );break;
		case VEL_SLOW:radioButton_az_vel_slow->setChecked ( TRUE );break;
		case VEL_SPEC:radioButton_az_vel_spec->setChecked ( TRUE );break;
		default:break;
	}
	switch ( SMySetting::instance_p()->value ( "az_alt/az_acc" ).toInt() )
	{
		case ACC_DEFAULT:radioButton_az_acc_default->setChecked ( TRUE );break;
		case ACC_SPEC:radioButton_az_acc_spec->setChecked ( TRUE );break;
		default:break;
	}
	switch ( SMySetting::instance_p()->value ( "az_alt/az_step" ).toInt() )
	{
		case STEP1:radioButton_az_step1->setChecked ( TRUE );break;
		case STEP01:radioButton_az_step01->setChecked ( TRUE );break;
		case STEP001:radioButton_az_step001->setChecked ( TRUE );break;
		case STEP_SPEC:radioButton_az_step_spec->setChecked ( TRUE );break;
		default:break;
	}
	switch ( SMySetting::instance_p()->value ( "az_alt/alt_vel" ).toInt() )
	{
		case VEL_FAST:radioButton_alt_vel_fast->setChecked ( TRUE );break;
		case VEL_MID: radioButton_alt_vel_mid->setChecked ( TRUE );break;
		case VEL_SLOW:radioButton_alt_vel_slow->setChecked ( TRUE );break;
		case VEL_SPEC:radioButton_alt_vel_spec->setChecked ( TRUE );break;
		default:break;
	}
	switch ( SMySetting::instance_p()->value ( "az_alt/alt_acc" ).toInt() )
	{
		case ACC_DEFAULT:radioButton_alt_acc_default->setChecked ( TRUE );break;
		case ACC_SPEC:radioButton_alt_acc_spec->setChecked ( TRUE );break;
		default:break;
	}
	switch ( SMySetting::instance_p()->value ( "az_alt/alt_step" ).toInt() )
	{
		case STEP1:radioButton_alt_step1->setChecked ( TRUE );break;
		case STEP01:radioButton_alt_step01->setChecked ( TRUE );break;
		case STEP001:radioButton_alt_step001->setChecked ( TRUE );break;
		case STEP_SPEC:radioButton_alt_step_spec->setChecked ( TRUE );break;
		default:break;
	}
}
void DirectAzalt::closeEvent ( QCloseEvent *event )
{
	parentWidget()->hide();
	event->ignore();
}

void DirectAzalt::cmdOCS(QHash<QString,QString> cmd)
{
	QString ExeStatus;
	if(cmd["CMD"]==CHECK_AZ){
		if(az_error[0]==false)
		return ;}
	if(cmd["CMD"]==START_AZ){

		az_target = cmd["POS"].toDouble();
		int Az_d=int ( az_target );
		int Az_m=int ( ( az_target-Az_d ) *60 );
		float Az_s= ( ( az_target-Az_d ) *60-Az_m ) *60;//转化AZ

		lineEdit_az_targetD->setText ( QString::number(Az_d) ); //度

		lineEdit_az_targetM->setText ( QString::number(Az_m) );//分

		lineEdit_az_targetS->setText ( QString::number(Az_s,'f',3) );//秒
//		on_pushButton_az_go_clicked();

		QString s_temp;
		QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );
		qDebug() << s_datetime;
		s_temp = QString("<RelatedCmdCUID=")+START_AZ;
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=START><bExeStatus=true>" );
		m_parent->server->writeData(s_temp);
		timer_az->start(5000);return ;}
	if (cmd["CMD"]==STOP_AZ){
		timer_az->stop();
//		on_pushButton_az_stop_clicked();
		QString s_temp;
		QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );
        
		s_temp = QString("<RelatedCmdCUID=")+STOP_AZ;
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=DONE><bExeStatus=true>" );
		m_parent->server->writeData(s_temp);return;};
	if(cmd["CMD"]==CHECK_ALT){
		if(alt1_error[0]=false)
		return ;}
	if(cmd["CMD"]==START_ALT){
		az_target = cmd["POS"].toDouble();
		int Alt_d=int ( alt_target );
		int Alt_m=int ( ( alt_target-Alt_d ) *60 );
		float Alt_s= ( ( alt_target-Alt_d ) *60-Alt_m ) *60;//转化AZ

		lineEdit_alt_targetD->setText ( QString::number(Alt_d) ); //度

		lineEdit_alt_targetM->setText ( QString::number(Alt_m) );//分

		lineEdit_alt_targetS->setText ( QString::number(Alt_s,'f',3) );//秒
//		on_pushButton_alt_go_clicked();

		QString s_temp;
		QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );
        
		s_temp = QString("<RelatedCmdCUID=")+START_ALT;
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=START><bExeStatus=true>" );
		m_parent->server->writeData(s_temp);
		timer_alt->start(5000);return ;}
	if (cmd["CMD"]==STOP_ALT){
		timer_alt->stop();
//		on_pushButton_alt_stop_clicked();
		QString s_temp;
		QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );
        
		s_temp = QString("<RelatedCmdCUID=")+STOP_ALT;
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=DONE><bExeStatus=true>" );
		m_parent->server->writeData(s_temp);return;};
}

void DirectAzalt::infoAzOCS()
{
	QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );
	if ( fabs ( az_real-az_target ) <=0.01 ) //秒
	{
//		timer_az->stop();
		QString s_temp = "<RelatedCmdCUID=";
		s_temp.append(START_AZ);
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=DONE><bExeStatus=true>" );
		m_parent->server->writeData(s_temp);
	}
	else
	{
		QString s_temp = "<RelatedCmdCUID=";
		s_temp.append(START_AZ);
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><RV=0><Info=OK><Pos=" );
		s_temp.append(QString::number(az_real,'f',8));
                s_temp.append ("><ExeStatus=ACTIVE><bExeStatus=false>");
		m_parent->server->writeData(s_temp);
	}
}

void DirectAzalt::infoAltOCS()
{
	QString s_datetime = QDateTime::currentDateTime().toString ( "yyyy.MM.dd-hh:mm:ss" );
	if ( fabs ( alt_real-alt_target ) <=0.01 ) //秒
	{
//		timer_alt->stop();
		QString s_temp = "<RelatedCmdCUID=";
		s_temp.append(START_ALT);
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><ExeStatus=DONE><bExeStatus=true>" );
		m_parent->server->writeData(s_temp);
	}
	else
	{
		QString s_temp = "<RelatedCmdCUID=";
		s_temp.append(START_ALT);
		s_temp.append ( "><StatusCUID=" );
		s_temp.append ( s_datetime );
		s_temp.append ( "><RV=0><Info=OK><Pos=" );
		s_temp.append(QString::number(alt_real,'f',8));
                s_temp.append ("><ExeStatus=ACTIVE><bExeStatus=false>");
		m_parent->server->writeData(s_temp);
	}
}

void DirectAzalt::writeErrorToOCS(QString error)
{
	
}

void DirectAzalt::updateInterface(QHash<QString,QString> map)
{
/*********************AZ ALT pos,poserr,vel*********************************************************/
	double az_pos = (map["m161"].toDouble()/3072.0)*CTS;
	double az_pos_real = ((map["m162"].toDouble()+map["m164"].toDouble())/3072.0)*CTS;//arcsec
	double az_vel = (map["m174"].toDouble()/3072.0)*CTS*1000*2;//  "/s

	int az_posD = static_cast<int>(az_pos_real/3600);
	int az_posM = static_cast<int>((az_pos_real/3600-az_posD)*60);
	double az_posS = ((az_pos_real/3600-az_posD)*60-az_posM)*60;
	double az_poserr = az_pos-az_pos_real;
	az_real = az_posD + az_posM/60.0 + az_posS/3600.0;

	lineEdit_az_posD->setText(QString::number(az_posD));
	lineEdit_az_posM->setText(QString::number(az_posM));
	lineEdit_az_posS->setText(QString::number(az_posS,'f',2));
	lineEdit_az_poserr->setText(QString::number(az_poserr,'f',2));
	lineEdit_az_vel->setText(QString::number(az_vel,'f',2));

	double alt_pos = (map["m261"].toDouble()/3072.0)*CTS;
	double alt_pos_real = ((map["m262"].toDouble()+map["m264"].toDouble())/3072.0)*CTS;//arcsec
	double alt_vel = (map["m274"].toDouble()/3072.0)*CTS*1000*2;//  "/s

	int alt_posD = static_cast<int>(alt_pos_real/3600);
	int alt_posM = static_cast<int>((alt_pos_real/3600-alt_posD)*60);
	double alt_posS = ((alt_pos_real/3600-alt_posD)*60-alt_posM)*60;
	double alt_poserr = alt_pos-az_pos_real;
	alt_real = alt_posD + alt_posM/60.0 + alt_posS/3600.0;

	lineEdit_alt_posD->setText(QString::number(alt_posD));
	lineEdit_alt_posM->setText(QString::number(alt_posM));
	lineEdit_alt_posS->setText(QString::number(alt_posS,'f',2));
	lineEdit_alt_poserr->setText(QString::number(alt_poserr,'f',2));
	lineEdit_alt_vel->setText(QString::number(alt_vel,'f',2));

/******************************AZ ALT ampli**************************************************/
	if(map["m154"] != "1")//AZ AMPLI,equal to "1" means OK
	{
		az_error[0]=true;
		az_error[1]=true;
		az_error_info[1]="Az Ampli Fault.";
		label_az_ampli_fault->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		az_error[0]=false;
		label_az_ampli_fault->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m254"] != "1")//ALT AMPLI1
	{
		alt1_error[0]=true;
		alt1_error[1]=true;
		alt1_error_info[1]="Alt Ampli1 Fault.";
		label_alt_ampli1_fault->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		alt1_error[0]=false;
		label_alt_ampli1_fault->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m354"] != "1")//ALT AMPLI2
	{
		alt2_error[0]=true;
		alt2_error[1]=true;
		alt2_error_info[1]="Alt Ampli2 Fault.";
		label_alt_ampli2_fault->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		alt2_error[0]=false;
		label_alt_ampli2_fault->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

/****************************AZ ALT loop closed************************************************/
	if(map["m138"] == "0")//AZ loop,equal to "0" means closed.
	{
		az_error[0]=false;
		label_az_loop->setStyleSheet("background-color: rgb(0, 255, 0)");
	}
	else
	{
		az_error[0]=true;
		az_error[2]=true;
		az_error_info[2]="Az Ampli Disabled.";
		label_az_loop->setStyleSheet("background-color: rgb(255, 0, 0)");
	}

	if(map["m238"] == "0")//ALT loop1
	{
		alt1_error[0]=false;
		label_alt_loop1->setStyleSheet("background-color: rgb(0, 255, 0)");
	}
	else
	{
		alt1_error[0]=true;
		alt1_error[2]=true;
		alt1_error_info[2]="Alt Ampli1 Disabled.";
		label_alt_loop1->setStyleSheet("background-color: rgb(255, 0, 0)");
	}

	if(map["m338"] == "0")//ALT loop2
	{
		alt2_error[0]=false;
		label_alt_loop2->setStyleSheet("background-color: rgb(0, 255, 0)");
	}
	else
	{
		alt2_error[0]=true;
		alt2_error[2]=true;
		alt2_error_info[2]="Alt Ampli2 Disabled.";
		label_alt_loop2->setStyleSheet("background-color: rgb(255, 0, 0)");
	}

/**************************AZ ALT error*****************************************/
	if(map["m142"] == "1")//AZ ,equal to "1" means error
	{
		az_error[0]=true;
		az_error[3]=true;
		az_error_info[3]="Az Error.";
		label_az_error->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		az_error[0]=false;
		label_az_error->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m242"] == "1")//ALT 1,
	{
		alt1_error[0]=true;
		alt1_error[3]=true;
		alt1_error_info[3]="Alt1 Error.";
		label_alt_error1->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		alt1_error[0]=false;
		label_alt_error1->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m342"] == "1")//ALT 2
	{
		alt2_error[0]=true;
		alt2_error[3]=true;
		alt2_error_info[3]="Alt2 Error.";
		label_alt_error2->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		alt2_error[0]=false;
		label_alt_error2->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

/**************************AZ ALT warning*****************************************/
	if(map["m141"] == "1")//AZ ,equal to "1" means warning
	{
		label_az_warning->setStyleSheet("background-color: rgb(255, 255, 110)");
	}
	else
	{
		label_az_warning->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m241"] == "1")//ALT 1,
	{
		label_alt_warning1->setStyleSheet("background-color: rgb(255, 255, 110)");
	}
	else
	{
		label_alt_warning1->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m341"] == "1")//ALT 2
	{
		label_alt_warning2->setStyleSheet("background-color: rgb(255, 255, 110)");
	}
	else
	{
		label_alt_warning2->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

/****************************AZ ALT homing*******************************************/
	
}

void DirectAzalt::on_pushButton_az_enable_clicked()
{
	QString str;
	char cmd[255];
	sprintf ( cmd,"ENABLE PLC11" );  // ENABLE AZ MOTOR 1#
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_pushButton_az_disable_clicked()
{
	QString str;
	char cmd[255];
	sprintf ( cmd,"ENABLE PLC16" );  // DISABLE AZ MOTOR 1#
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_pushButton_az_home_clicked()
{
	QString str;
	SQUMAC::instance_p()->QcommCmdPMAC ( "DISABLE PLC5",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "P29=0",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "P17=3",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "ENABLE PLC5",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "P801=0",str );//flag
}

void DirectAzalt::on_radioButton_az_vel_fast_toggled ( bool on )
{
	if ( on )
	{
		char cmd[255];
		QString str;
		az_vel = SMySetting::instance_p()->value("az_alt/az_vel_fast").toDouble()/(CTS*1000);
		sprintf ( cmd,"I122=%f",az_vel );
		SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	}
}

void DirectAzalt::on_radioButton_az_vel_mid_toggled ( bool on )
{
	if ( on )
	{
		char cmd[255];
		QString str;
		az_vel = SMySetting::instance_p()->value("az_alt/az_vel_mid").toDouble()/(CTS*1000);
		sprintf ( cmd,"I122=%f",az_vel );
		SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	}
}

void DirectAzalt::on_radioButton_az_vel_slow_toggled ( bool on )
{
	if ( on )
	{
		char cmd[255];
		QString str;
		az_vel = SMySetting::instance_p()->value("az_alt/az_vel_slow").toDouble()/(CTS*1000);
		sprintf ( cmd,"I122=%f",az_vel );
		SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	}
}

void DirectAzalt::on_lineEdit_az_vel_spec_returnPressed()
{
//	emit az_vel_spec ( lineEdit_az_vel_spec->text().toFloat() );
	char cmd[255];
	QString str;
	az_vel = lineEdit_az_vel_spec->text().toFloat()/(CTS*1000);
	sprintf ( cmd,"I122=%f",az_vel );
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	
}

void DirectAzalt::on_radioButton_az_acc_default_toggled ( bool on )
{
	if ( on )
		qDebug ( "default\n" );
}

void DirectAzalt::on_lineEdit_az_acc_spec_returnPressed()
{
//	emit az_acc_spec ( lineEdit_az_acc_spec->text().toFloat() );
}

void DirectAzalt::on_pushButton_az_go_clicked()
{
	on_lineEdit_az_vel_spec_returnPressed();
	char cmd[255];
	QString str;
	az_target = (lineEdit_az_targetD->text().toFloat()*3600+lineEdit_az_targetM->text().toFloat()*60+lineEdit_az_targetS->text().toFloat())/CTS;
	SQUMAC::instance_p()->QcommCmdPMAC ( "P130=-5600P131=11500P132=11600P133=550",str );
	sprintf ( cmd,"#1J=%f",az_target );
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_pushButton_az_stop_clicked()
{
	QString str;
	SQUMAC::instance_p()->QcommCmdPMAC ( "#1K",str );
}

void DirectAzalt::on_pushButton_alt_enable_clicked()
{
	QString str;
	char cmd[255];
	sprintf ( cmd,"ENABLE PLC9" );  // ENABLE ALT MOTOR 2# 3#
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_pushButton_alt_disable_clicked()
{
	QString str;
	char cmd[255];
	sprintf ( cmd,"ENABLE PLC15" );  // DISABLE ALT MOTOR 2# 3#
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_pushButton_alt_home_clicked()
{
	QString str;
	SQUMAC::instance_p()->QcommCmdPMAC ( "DISABLE PLC6",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "P64=0",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "P18=3",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "ENABLE PLC6",str );
	SQUMAC::instance_p()->QcommCmdPMAC ( "P807=0",str );//flag
}

void DirectAzalt::on_radioButton_alt_vel_fast_toggled ( bool on )
{
	if ( on )
	{
		char cmd[255];
		QString str;
		alt_vel = SMySetting::instance_p()->value("az_alt/alt_vel_fast").toDouble()/(CTS*1000);
		sprintf ( cmd,"I222=%fI322=%f",alt_vel,alt_vel );
		SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	}
}

void DirectAzalt::on_radioButton_alt_vel_mid_toggled ( bool on )
{
	if ( on )
	{
		char cmd[255];
		QString str;
		alt_vel = SMySetting::instance_p()->value("az_alt/alt_vel_mid").toDouble()/(CTS*1000);
		sprintf ( cmd,"I222=%fI322=%f",alt_vel,alt_vel );
		SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	}
}

void DirectAzalt::on_radioButton_alt_vel_slow_toggled ( bool on )
{
	if ( on )
	{
		char cmd[255];
		QString str;
		alt_vel = SMySetting::instance_p()->value("az_alt/alt_vel_slow").toDouble()/(CTS*1000);
		sprintf ( cmd,"I222=%fI322=%f",alt_vel,alt_vel );
		SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
	}
}


void DirectAzalt::on_lineEdit_alt_vel_spec_returnPressed()
{
//	emit alt_vel_spec ( lineEdit_alt_vel_spec->text().toFloat() );
	char cmd[255];
	QString str;
	alt_vel = lineEdit_alt_vel_spec->text().toFloat()/(CTS*1000);
	sprintf ( cmd,"I222=%fI322=%f",alt_vel,alt_vel );
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_radioButton_alt_acc_default_toggled ( bool on )
{
	if ( on )
		qDebug ( "default\n" );
}

void DirectAzalt::on_lineEdit_alt_acc_spec_returnPressed()
{
//	emit alt_acc_spec ( lineEdit_alt_acc_spec->text().toFloat() );
}

void DirectAzalt::on_pushButton_alt_go_clicked()
{
	on_lineEdit_alt_vel_spec_returnPressed();
	char cmd[255];
	QString str;
	alt_target = (lineEdit_alt_targetD->text().toFloat()*3600+lineEdit_alt_targetM->text().toFloat()*60+lineEdit_alt_targetS->text().toFloat())/CTS;
	SQUMAC::instance_p()->QcommCmdPMAC ( "P130=-5600P131=11500P132=11600P133=550",str );
	sprintf ( cmd,"#2J=%f",alt_target );
	SQUMAC::instance_p()->QcommCmdPMAC ( cmd,str );
}

void DirectAzalt::on_pushButton_alt_stop_clicked()
{
	QString str;
	SQUMAC::instance_p()->QcommCmdPMAC ( "#2K",str );
}
