//
// C++ Implementation: tracking
//
// Description: 
//
//
// Author: donglongchao <donglongchao@163.com>, (C) 2010
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "main_window.h"
#include "tracking.h"
#include "signs.h"
#include "track_thread.h"
#include "calculate_thread.h"
//#include "/home/ysh/telescope/TelControl/star/astro.h"
//#include "/home/ysh/telescope/TelControl/star/circum.h"
//#include "StarTest.cpp"
extern double azPosReal_Degree;//az实际位置extern
extern double altPosReal_Degree;
extern   double RA_h,RA_m,RA_s;//RA of star
extern 	double DEC_d,DEC_m,DEC_s;//Dec of star
extern      double Temperature,Pressure;//mBa;
extern         int cal_flag;//0:no calculate star,1:caculate start,2:calculate finished

bool flag_TrackStarByOCS_MA=false;//OCS ask MA to begin tracking star
bool flag_TrackStarStopByOCS_MA=false;//OCS ask MA to stop tracking star

QTimer *timer1;//show data
QTimer *timer1_correctError;//
QTimer *timer1_saveTrackingData;
bool flag_TrackstarAzAlt=false;// flag of track az alt
//star table
//extern double AZ[TABLE_NUM],ALT[TABLE_NUM],FR[TABLE_NUM],HA[TABLE_NUM],DEC[TABLE_NUM];
extern	DateTime DT[TABLE_NUM];//save day and time structure
//extern static int cal_flag;//0:no calculate star,1:caculate start,2:calculate finished
extern double AZ[TABLE_NUM],ALT[TABLE_NUM],FR[TABLE_NUM],HA[TABLE_NUM],DEC[TABLE_NUM];
///////////star////////////////
extern QString path;
QVector<QString> starTable(TABLE_NUM);
//CString Ha,Dec;//时角、赤纬,给SMountClientToOCSThread-H(socket)
char S_dec[15],S_ha[15];//赤纬,时角,(自己计算)写文件madata.txt给S-H

double dfTim=0;
/* 2009.9
double ra,Dec;//ra and dec at epoch of date
double ha,alt,az,fpa,ha1,dec1,ha_2,ha1_2,dec1_2,fpa2;//hour angle,altitude and azimuth
double utc,deltaUT,lst0,lst,lst0_2;
Now np;

double utc2,lst2,alt2,az2=0;
double dec_star,ha_star;//save,degree,hour,
double mjd0,mjd1,mjd1_2;//mjd0 modified julian date, counted from J1900.0
double lsn,rsn,lsn2,rsn2;//true geoc lng of sun,dist from sun to earth
*/
int ALT_d=0,ALT_m=0;
double ALT_s=0;
//save
#define M 30
int secondsAz=0,secondsAz_old=0;//save data per second
int secondsAlt=0,secondsAlt_old=0;////save alt data per second
double AzData_tracking[M][5];//save data
double AltData_tracking[M][5];//save data
QString AzDataTime_tracking[M];
QString AltDataTime_tracking[M];
extern double azPosReal_Degree_forError;//az实际位置,与AZ_TrackTarget同时在track（）中记录，用于求误差
extern double altPosReal_Degree_forError;//alt实际位置,与ALT_TrackTarget同时在track（）中记录，用于求误差

bool flag_TrackingSave=false;
int PtrAlt=0;//save ALT file when PtrgAlt=M
int Ptr=0;// save AZ file when Ptrg=M
// star guider
double Az_guidedata=0;		
double Alt_guidedata=0;		
double azFolErr=0,altFolErr=0;		
//tracking
double AZ_TrackError;//
double AZ_TrackTarget=0;//最终跟踪使用的传递AZ跟踪目标
double ALT_TrackError;//
double ALT_TrackTarget;//最终跟踪使用的传递ALT跟踪目标,
double alt_offset=0,az_offset=0;//分别是由于光轴不准AZ和ALT的修正值//-25"和7"
double AZ_TrackTargetNew=0;//跟踪使用的传递AZ跟踪目标,加偏置
double ALT_TrackTargetNew=0;//跟踪使用的传递ALT跟踪目标,加偏置
extern int flag_line;
bool flag_firstPoint=true;//如果是刚刚追踪的第一点，则加大追踪时间，以减小加速度
extern StarTarget target;
int firstPoint_delay=60;
bool flag_bStartTrack=0;
long N_row_LAST=0;//存上次的行号（也就是当前时间），用于查star表
long N_row=0;//存当前的行号，用于查star表

double alt_correct=0,az_correct=0 ;//extern 
double az_correct_last=0,alt_correct_last=0;//extern 


Tracking::Tracking(MainWindow *parent)
{
	m_parent = parent;
	setupUi(this);
	lineEdit_RAH->setValidator(new QIntValidator(0,24,this));
	lineEdit_RAM->setValidator(new QIntValidator(0,60,this));
	lineEdit_RAS->setValidator(new QIntValidator(0,60,this));
	lineEdit_DECD->setValidator(new QIntValidator(0,360,this));
	lineEdit_DECM->setValidator(new QIntValidator(0,60,this));
	lineEdit_DECS->setValidator(new QIntValidator(0,60,this));
	connect(SQUMAC::instance_p(),SIGNAL(UMACInfoThrown(QHash<QString,QString>)),this,SLOT(updateInterface(QHash<QString,QString>)));
	timer_save_track_data = new QTimer;
	connect(timer_save_track_data,SIGNAL(timeout()),this,SLOT(saveTrackData()));
	timer_show_track_info = new QTimer;
	connect(timer_show_track_info,SIGNAL(timeout()),this,SLOT(showTrackInfo()));
}

Tracking::~Tracking()
{
	qDebug("tracking");
	timer_save_track_data->deleteLater();
	timer_show_track_info->deleteLater();
}

void Tracking::closeEvent ( QCloseEvent *event )
{
	parentWidget()->hide();
	event->ignore();
}
void Tracking::cmdOCS(QHash<QString,QString> cmd)
{
	if(cmd["CMD"]==START_TRACK)
		return;
	if(cmd["CMD"]==STOP_TRACK)
		return;
}

void Tracking::updateInterface(QHash<QString,QString> map)
{
	double az_pos_real = ((map["m162"].toDouble()+map["m164"].toDouble())/3072.0)*CTS;//arcsec

	int az_posD = static_cast<int>(az_pos_real/3600);
	int az_posM = static_cast<int>((az_pos_real/3600-az_posD)*60);
	double az_posS = ((az_pos_real/3600-az_posD)*60-az_posM)*60;
	
	if ( az_posD!=0 )
		az_posM=abs ( az_posM );
	if ( az_posD!=0||az_posM!=0 )
		az_posS=fabs ( az_posS );

	lineEdit_az_posD->setText(QString::number(az_posD));
	lineEdit_az_posM->setText(QString::number(az_posM));
	lineEdit_az_posS->setText(QString::number(az_posS,'f',2));

	double alt_pos_real = ((map["m262"].toDouble()+map["m264"].toDouble())/3072.0)*CTS;//arcsec

	int alt_posD = static_cast<int>(alt_pos_real/3600);
	int alt_posM = static_cast<int>((alt_pos_real/3600-alt_posD)*60);
	double alt_posS = ((alt_pos_real/3600-alt_posD)*60-alt_posM)*60;
	
	if ( alt_posD!=0 )
		alt_posM=abs ( alt_posM );
	if ( alt_posD!=0||alt_posM!=0 )
		alt_posS=fabs ( alt_posS );

	lineEdit_alt_posD->setText(QString::number(alt_posD));
	lineEdit_alt_posM->setText(QString::number(alt_posM));
	lineEdit_alt_posS->setText(QString::number(alt_posS,'f',2));


	/******************************AZ ALT ampli**************************************************/
	if(map["m154"] != "1")//AZ AMPLI,equal to "1" means OK
	{
		label_az_ampli_enabled->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		label_az_ampli_enabled->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m254"] != "1")//ALT AMPLI1
	{
		label_alt_ampli1_enabled->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		label_alt_ampli1_enabled->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

	if(map["m354"] != "1")//ALT AMPLI2
	{
		label_alt_ampli2_enabled->setStyleSheet("background-color: rgb(255, 0, 0)");
	}
	else
	{
		label_alt_ampli2_enabled->setStyleSheet("background-color: rgb(0, 255, 0)");
	}

/****************************AZ ALT loop closed************************************************/
// 	if(map["m138"] == "0")//AZ loop,equal to "0" means closed.
// 	{
// 		label_az_loop->setStyleSheet("background-color: rgb(0, 255, 0)");
// 	}
// 	else
// 	{
// 		label_az_loop->setStyleSheet("background-color: rgb(255, 0, 0)");
// 	}
// 
// 	if(map["m238"] == "0")//ALT loop1
// 	{
// 		label_alt_loop1->setStyleSheet("background-color: rgb(0, 255, 0)");
// 	}
// 	else
// 	{
// 		label_alt_loop1->setStyleSheet("background-color: rgb(255, 0, 0)");
// 	}
// 
// 	if(map["338"] == "0")//ALT loop2
// 	{
// 		label_alt_loop2->setStyleSheet("background-color: rgb(0, 255, 0)");
// 	}
// 	else
// 	{
// 		label_alt_loop2->setStyleSheet("background-color: rgb(255, 0, 0)");
// 	}
}

void Tracking::showTrackInfo()
{
	QHash<QString,QString> info_show;
	char s[255];

	int AZ_d=0,AZ_m=0, ALT_d=0,ALT_m=0;
	double AZ_s=0,ALT_s=0;

	sprintf ( s,"%ld",N_row );
	label_track_line->setText ( s );//the number of tracking star table
//	label_track_line->setStyleSheet ( "color:rgb(255, 255, 255)" );

	/////////////////////show Az target/////////////////////////////
	AZ_d=int ( AZ_TrackTarget );//star table
	AZ_m=int ( ( AZ_TrackTarget-AZ_d ) *60 );
	AZ_s= ( ( AZ_TrackTarget-AZ_d ) *60-AZ_m ) *60;//转化AZ 和ALT
	AZ_m=abs ( AZ_m );
	AZ_s=fabs ( AZ_s );

	lineEdit_az_starD->setText(QString::number(AZ_d));
	lineEdit_az_starM->setText(QString::number(AZ_m));
	lineEdit_az_starS->setText(QString::number(AZ_s,'f',2));

	info_show.insert("AZ_TARGET",QString::number(AZ_d)+tr("° ")+QString::number(AZ_m)+tr("′")+QString::number(AZ_s,'f',2)+tr("″"));
	AZ_d=int ( AZ_TrackTargetNew );//star table +correct
	AZ_m=int ( ( AZ_TrackTargetNew-AZ_d ) *60 );
	AZ_s= ( ( AZ_TrackTargetNew-AZ_d ) *60-AZ_m ) *60;//转化AZ 和ALT
	AZ_m=abs ( AZ_m );
	AZ_s=fabs ( AZ_s );
	
	lineEdit_az_targetD->setText(QString::number(AZ_d));
	lineEdit_az_targetM->setText(QString::number(AZ_m));
	lineEdit_az_targetS->setText(QString::number(AZ_s,'f',2));

	info_show.insert("AZ_POSITION",QString::number(AZ_d)+tr("° ")+QString::number(AZ_m)+tr("′")+QString::number(AZ_s,'f',2)+tr("″"));
	///////////////////////////show ALT target///////////////////////////////////////////
	ALT_d=int ( ALT_TrackTarget );
	ALT_m=int ( ( ALT_TrackTarget-ALT_d ) *60 );
	ALT_s= ( ( ALT_TrackTarget-ALT_d ) *60-ALT_m ) *60;
	ALT_m=abs ( ALT_m );
	ALT_s=fabs ( ALT_s );

	lineEdit_alt_starD->setText(QString::number(ALT_d));
	lineEdit_alt_starM->setText(QString::number(ALT_m));
	lineEdit_alt_starS->setText(QString::number(ALT_s,'f',2));

	info_show.insert("ALT_TARGET",QString::number(ALT_d)+tr("° ")+QString::number(ALT_m)+tr("′")+QString::number(ALT_s,'f',2)+tr("″"));

	ALT_d=int ( ALT_TrackTargetNew );
	ALT_m=int ( ( ALT_TrackTargetNew-ALT_d ) *60 );
	ALT_s= ( ( ALT_TrackTargetNew-ALT_d ) *60-ALT_m ) *60;
	ALT_m=abs ( ALT_m );
	ALT_s=fabs ( ALT_s );

	lineEdit_alt_targetD->setText(QString::number(ALT_d));
	lineEdit_alt_targetM->setText(QString::number(ALT_m));
	lineEdit_alt_targetS->setText(QString::number(ALT_s,'f',2));

	info_show.insert("ALT_POSITION",QString::number(ALT_d)+tr("° ")+QString::number(ALT_m)+tr("′")+QString::number(ALT_s,'f',2)+tr("″"));
 ///////////////////////////////////////////////显示导星数据///////////////////////////////////////
	 alt_correct=0;
	 az_correct=0 ;//extern

	sprintf(s,"%5.3f",az_correct);//az_correct单位为度
	lineEdit_az_auto->setText(s);
//	AzAutoguiderLabel->setStyleSheet ( "color:rgb(255, 255, 0)" );
//	AzAutoguiderLabel->setFont ( QFont ( "Times", 14 ) );

	sprintf(s,"%5.3f",alt_correct);//alt_correct单位为度
        lineEdit_alt_auto->setText(s);
//	AltAutoguiderLabel->setStyleSheet ( "color:rgb(255, 255, 0)" );
//	AltAutoguiderLabel->setFont ( QFont ( "Times", 14 ) );
	
        ///////////////////////////show tracking error///////////////////////////////////////////
        sprintf(s, "%5.2f",AZ_TrackError);//AZ track error
        lineEdit_az_trackerr->setText ( s );
//	AzTrackErrorLabel->setStyleSheet ( "color:rgb(255, 255, 0)" );
//	AzTrackErrorLabel->setFont ( QFont ( "Times", 14 ) );
	info_show.insert("AZ_ERROR",QString::number(AZ_TrackError,'f',2)+tr("″"));

        sprintf(s, "%5.2f",ALT_TrackError);//AZ track error
        lineEdit_alt_trackerr->setText ( s );
//	AltTrackErrorLabel->setStyleSheet ( "color:rgb(255, 255, 0)" );
//	AltTrackErrorLabel->setFont ( QFont ( "Times", 14 ) );
	info_show.insert("ALT_ERROR",QString::number(ALT_TrackError,'f',2)+tr("″"));

	//////////////////得到时间AZ 和ALT的偏置量////////////////////////////////
	az_offset=lineEdit_az_offset->text().toDouble();//  "
	alt_offset=lineEdit_alt_offset->text().toDouble();//  "
	qDebug() <<info_show["AZ_TARGET"];
	m_parent->updateInterface(info_show);
}
void Tracking::on_pushButton_track_clicked()
{
// 	if(readStarTable() != true)
// 		return;
// 	track_thread = new TrackThread(this);
// 	track_thread->start();
// 	pushButton_track->setText("Tracking...");
// 	pushButton_stop->setEnabled(true);
// 	QString str;
// 	SQUMAC::instance_p()->QcommCmdPMAC("ENABLE PLC12",str);//PLC12 UMAC parameters for tracking  
// 	// qumacTr->QcommCmdPMAC("P145=1",str);//开始跟踪,缓冲区标志1
// 	SQUMAC::instance_p()->QcommCmdPMAC ( "&1B2A",str );//停止UMAC的motion2
// 	SQUMAC::instance_p()->QcommCmdPMAC ( "&1B2R",str );//执行UMAC的motion2
	timer_save_track_data->start(1000);
	timer_show_track_info->start(1000);
}

bool Tracking::saveTrackData()
{
	static int count = 0;
	QDateTime dt=QDateTime::currentDateTime();
	QString dtstr;
	dtstr=dt.toString ( "yyyy-MM-dd hh:mm:ss" );
	if(count <= 29)
	{
		AzData_tracking[count][0]=azPosReal_Degree_forError;//实际位置（取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差）
		AzData_tracking[count][1]=AZ_TrackTarget;//AZ 目标   
		AzData_tracking[count][2]=(AZ_TrackTarget-azPosReal_Degree_forError)*3600;    //跟踪误差(与星位置比)AZ_TrackError
                //AzData_tracking[Ptr][2]=AZ_TrackError;    //跟踪误差(与星位置比)AZ_TrackError
		AzData_tracking[count][3]=azFolErr;////following error
		AzData_tracking[count][4]=Az_guidedata;//
		AzDataTime_tracking[count]=dtstr;

		AltData_tracking[count][0]=altPosReal_Degree_forError;//实际位置（取得ALT_TrackTarget同时刻的实际位置，以备计算跟踪误差）
		AltData_tracking[count][1]=ALT_TrackTarget; //ALT_TrackTarget  
                AltData_tracking[count][2]=(ALT_TrackTarget-altPosReal_Degree_forError)*3600;    //跟踪误差(与星位置比)AZ_TrackError
		//AltData_tracking[PtrAlt][2]=ALT_TrackError;    //跟踪误差(与星位置比)AZ_TrackError
		AltData_tracking[count][3]=altFolErr;////following error
		AltData_tracking[count][4]=Alt_guidedata;//
		AltDataTime_tracking[count]=dtstr;

		count++;
//qDebug()<<dtstr;
		//AzData[N][0]:  目标位置 （星表）                       //
		//AzData[N][1]:  实际位置 (实时)
		//AzData[N][2]:  跟踪误差(与星位置比) AZ_TrackError
		//AzData[N][3]:实际位置（取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差）
		//AzData[N][4]:  目标位置 （星表＋导星＋偏置 命令位置）
//		secondsAz_old=secondsAz;
		return true;
	}
	else 
	{
		count=0;
		return storeTrackData();
	}
}

bool Tracking::storeTrackData()
{
	storeAzTrackNoRMS();
	storeAzTrackRMS();
	storeAltTrackNoRMS();
	return storeAltTrackRMS();
}
bool Tracking::storeAzTrackNoRMS() //打印AztrackNoRMS.txt
{
	char s_0[400] ;
	char s_1[60] ;
	char s_2[60];

//////////////保存文件/////////////////////
//QString fileName = QFileDialog::getOpenFileName ( this );
//QString fileName ="/home/ysh/AzData.txt";
	QString fileName =QDir::currentPath()+"/AzTrackNoRMS.txt";
qDebug()<<fileName;
	QFile file ( fileName );
	if ( !file.open ( QFile::Append|QFile::Truncate ) )
	{
		QMessageBox::warning ( this,
		                       tr ( "Warn" ),
		                       tr ( "open error!" ),
		                       QMessageBox::Yes );
		return false;
	}
	QTextStream out ( &file );
//sprintf ( s_0," yyyymmdd  hhmmss      AZ        ALT          FR          HA        DEC \n" );
	//out<<s_0;
	for ( int i=0;i<M;i++ )
	{
		//AzData_tracking,double AltData_tracking[M][5];//save data
		//QString AzDataTime_tracking
		sprintf ( s_1,"  %10.6f",AzData_tracking[i][0] ); //azPosReal_Degree_forError;//实际位置（取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差）  position（UMAC取出,"）
		sprintf ( s_2,"  %10.6f",AzData_tracking[i][2] );//AZ_TrackError,track error,单位：秒 (AZ_TrackTarget-azPosReal_Degree)*3600
		

		sprintf ( s_0,"%s%s  ",s_1,s_2);

		out<<s_0+AzDataTime_tracking[i]+"\n";
	}


	file.close();
	return true;

}

bool Tracking::storeAzTrackRMS() //打印AzTrackRMS.txt
{
	char s_0[400] ;
	char s_1[60] ;
	char s_2[60];
	char s_3[60];
	int j;
       /////////////////////////RMS///////////////
	////////////tracking error/////////////////////////////////////////
	//get speed
	double speed=(AzData_tracking[M-1][0]-AzData_tracking[0][0])*3600/M;
                      
//get RMS of tracking error
	double Xi=0,Yi=0;
		
	for(j=0;j<M;j++)//// M:   matrix AltData_tracking rows
	{
		Xi=AzData_tracking[j][2]+Xi;
	}
	
	Xi=Xi/M;
	
	for(j=0;j<M;j++)
	{
		Yi=(AzData_tracking[j][2]-Xi)*(AzData_tracking[j][2]-Xi)+Yi;
	}
	Yi=sqrt(Yi/M);
	
	
	//计算误差峰谷值
	double min,max;
	double PV;
	max=min=AzData_tracking[0][2];
	
	for(j=0;j<M;j++) //
	{
		if(max<=AzData_tracking[j][2])
		{
			max=AzData_tracking[j][2];
		}
		if(min>AzData_tracking[j][2])
		{
			min=AzData_tracking[j][2];
			
		} 	
	}
	PV=max-min;



//////////////保存文件/////////////////////
//QString fileName = QFileDialog::getOpenFileName ( this );
//QString fileName ="/home/ysh/AzData.txt";
	QString fileName =QDir::currentPath()+"/AzTrackRMS.txt";
// qDebug()<<fileName<<path;
	QFile file ( fileName );
	if ( !file.open ( QFile::Append|QFile::Truncate ) )
	{
		QMessageBox::warning ( this,
		                       tr ( "Warn" ),
		                       tr ( "open error!" ),
		                       QMessageBox::Yes );
		return false;
	}
	QTextStream out ( &file );
//sprintf ( s_0," yyyymmdd  hhmmss      AZ        ALT          FR          HA        DEC \n" );
	//out<<s_0;
	for ( int i=0;i<M;i++ )
	{
		//AzData_tracking,double AltData_tracking[M][5];//save data
		//QString AzDataTime_tracking

                sprintf ( s_3,"  %10.6f",AzData_tracking[i][1] );//AZ TARGET

		sprintf ( s_1,"  %10.6f",AzData_tracking[i][0] ); //altPosReal_Degree_forError;//实际位置（取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差）  position（UMAC取出,"）
		sprintf ( s_2,"  %10.3f",AzData_tracking[i][2] );//track error,单位：秒(ALT_TrackTarget-altPosReal_Degree)*3600
		sprintf ( s_0,"%s%s%s  ",s_3,s_1,s_2);
		out<<s_0+AzDataTime_tracking[i]+"\n";
	}

 		sprintf(s_1,"speed= %6.3f ''/s,",speed);
		sprintf(s_2," RMS = %6.4f ''",Yi);
                sprintf(s_3," PV= %6.4f ''",PV);
              	sprintf ( s_0,"%s%s%s\n",s_1,s_2,s_3);
		out<<s_0;
	file.close();
	return true;


}

bool Tracking::storeAltTrackNoRMS() //打印AltTrackNoRMS.txt
{
	char s_0[400] ;
	char s_1[60] ;
	char s_2[60];

//////////////保存文件/////////////////////
//QString fileName = QFileDialog::getOpenFileName ( this );
//QString fileName ="/home/ysh/AzData.txt";
	QString fileName =QDir::currentPath()+"/AltTrackNoRMS.txt";
// qDebug()<<fileName<<path;
	QFile file ( fileName );
	if ( !file.open ( QFile::Append|QFile::Truncate ) )
	{
		QMessageBox::warning ( this,
		                       tr ( "Warn" ),
		                       tr ( "open error!" ),
		                       QMessageBox::Yes );
		return false;
	}
	QTextStream out ( &file );
//sprintf ( s_0," yyyymmdd  hhmmss      AZ        ALT          FR          HA        DEC \n" );
	//out<<s_0;
	for ( int i=0;i<M;i++ )
	{
		//AzData_tracking,double AltData_tracking[M][5];//save data
		//QString AzDataTime_tracking
		sprintf ( s_1,"  %10.6f",AltData_tracking[i][0] ); //altPosReal_Degree_forError;//实际位置（取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差）  position（UMAC取出,"）
		sprintf ( s_2,"  %10.6f",AltData_tracking[i][2] );//track error,单位：秒(ALT_TrackTarget-altPosReal_Degree)*3600
		sprintf ( s_0,"%s%s  ",s_1,s_2);
		out<<s_0+AltDataTime_tracking[i]+"\n";
	}


	file.close();
	return true;


}

bool Tracking::storeAltTrackRMS() //打印AltTrackRMS.txt
{
	char s_0[400] ;
	char s_1[60] ;
	char s_2[60];
	char s_3[60];
int j;
       /////////////////////////RMS///////////////
	////////////tracking error/////////////////////////////////////////
	//get speed
	double speed=(AltData_tracking[M-1][0]-AltData_tracking[0][0])*3600/M;
                      
//get RMS of tracking error
	double Xi=0,Yi=0;
		
	for(j=0;j<M;j++)//// M:   matrix AltData_tracking rows
	{
		Xi=AltData_tracking[j][2]+Xi;
	}
	
	Xi=Xi/M;
	
	for(j=0;j<M;j++)
	{
		Yi=(AltData_tracking[j][2]-Xi)*(AltData_tracking[j][2]-Xi)+Yi;
	}
	Yi=sqrt(Yi/M);
	
	
	//计算误差峰谷值
	double min,max;
	double PV;
	max=min=AltData_tracking[0][2];
	
	for(j=0;j<M;j++) //
	{
		if(max<=AltData_tracking[j][2])
		{
			max=AltData_tracking[j][2];
		}
		if(min>AltData_tracking[j][2])
		{
			min=AltData_tracking[j][2];
			
		} 	
	}
	PV=max-min;



//////////////保存文件/////////////////////
//QString fileName = QFileDialog::getOpenFileName ( this );
//QString fileName ="/home/ysh/AzData.txt";
	QString fileName =QDir::currentPath()+"/AltTrackRMS.txt";
// qDebug()<<fileName<<path;
	QFile file ( fileName );
	if ( !file.open ( QFile::Append|QFile::Truncate ) )
	{
		QMessageBox::warning ( this,
		                       tr ( "Warn" ),
		                       tr ( "open error!" ),
		                       QMessageBox::Yes );
		return false;
	}
	QTextStream out ( &file );
//sprintf ( s_0," yyyymmdd  hhmmss      AZ        ALT          FR          HA        DEC \n" );
	//out<<s_0;
	for ( int i=0;i<M;i++ )
	{
		//AzData_tracking,double AltData_tracking[M][5];//save data
		//QString AzDataTime_tracking
                sprintf ( s_3,"  %10.6f",AltData_tracking[i][1] );//target
		sprintf ( s_1,"  %10.6f",AltData_tracking[i][0] ); //altPosReal_Degree_forError;//实际位置（取得AZ_TrackTarget同时刻的实际位置，以备计算跟踪误差）  position（UMAC取出,"）
		sprintf ( s_2,"  %10.3f",AltData_tracking[i][2] );//track error,单位：秒(ALT_TrackTarget-altPosReal_Degree)*3600
		sprintf ( s_0,"%s%s%s  ",s_3,s_1,s_2);
		out<<s_0+AltDataTime_tracking[i]+"\n";
	}

 	sprintf(s_1,"speed= %6.3f ''/s,",speed);
		sprintf(s_2," RMS = %6.4f ''",Yi);
                sprintf(s_3," PV= %6.4f ''",PV);
              	sprintf ( s_0,"%s%s%s\n",s_1,s_2,s_3);
		out<<s_0;
	file.close();
	return true;


}

void Tracking::on_pushButton_stop_clicked()
{
	QString str;
	track_thread->exit();
	SQUMAC::instance_p()->QcommCmdPMAC ( "&1B2A",str );//停止UMAC的motion2
        SQUMAC::instance_p()->QcommCmdPMAC("ENABLE PLC13",str);//PLC13 UMAC parameters for going  
	pushButton_track->setText("Track");
	timer_save_track_data->stop();
	timer_show_track_info->stop();
}

void Tracking::on_pushButton_calculate_clicked()
{
	calculate_thread = new CalculateThread(	lineEdit_RAH->text().toDouble(),
						lineEdit_RAM->text().toDouble(),
						lineEdit_RAS->text().toDouble(),
						lineEdit_DECD->text().toDouble(),
						lineEdit_DECM->text().toDouble(),
						lineEdit_DECS->text().toDouble());
	connect(calculate_thread,SIGNAL(finished()),this,SLOT(on_calculate_thread_finished()));
	calculate_thread->start();
	label_calculate_status->setText("Calculating...");
	pushButton_calculate->setEnabled(false);

}

void Tracking::on_calculate_thread_finished()
{
	label_calculate_status->setText("Calculated");
	saveStarTable();
	pushButton_calculate->setEnabled(true);
	pushButton_track->setEnabled(true);
	calculate_thread->deleteLater();
}

bool Tracking::readStarTable()
{
	QString fileName = QDir::currentPath()+"/starTable.txt";
	long long num=0;
	QFile file ( fileName );
	if ( !file.open ( QFile::ReadOnly ) )
	{
		QMessageBox msgBox ( QMessageBox::NoIcon,"Warning!","open error!" );
		msgBox.setText ( "open error!" );
		msgBox.setStyleSheet ( "QPushButton { background-color: rgb(255, 85, 0); color: rgb(85, 255, 0); }" );
		msgBox.exec();

		return FALSE;
	}

/////////////////////////////每次读TABLE_NUM=108000行////////////////////
	QTextStream stream ( &file );
//MultiLineEdit1->setText( t.read() );
	QString line;
	stream.readLine();//抛弃第一行
	//while ( !stream.atEnd())
	for ( num=0;num<TABLE_NUM;num++ )
	{
		starTable.append( stream.readLine()); // 不包括“\n”的一行文本

	}
	qDebug() << starTable[0];
	file.close();
	return true;
}

bool Tracking::saveStarTable()
{
	char s_0[400] ;
	char s_1[60] ;
	char s_2[60];
	char s_3[20];
	char s_4[20];
	char s_5[20];
	char s_6[20];
	char s_7[20];
//	long num=0;
	long i=0;
	double seconds=0;
	QString fileName = QFileDialog::getOpenFileName ( this );
	qDebug("unchoosed....");
	QFile file ( fileName );
	if ( !file.open ( QFile::WriteOnly|QFile::Truncate ) )
	{
		return false;
	}
	QTextStream out ( &file );
	sprintf ( s_0,"  yyyymmdd   hhmmss       AZ          ALT          FR            HA          DEC \n" );
	out<<s_0;


	for ( i=0;i<TABLE_NUM;i++ )
	{
		sprintf ( s_1,"  %d%02d%02d",calculate_thread->DT[i].year,calculate_thread->DT[i].month,calculate_thread->DT[i].day );//yyyymmdd
		seconds=calculate_thread->DT[i].second+float ( calculate_thread->DT[i].msec/1000.0 );
		sprintf ( s_2,"  %02d%02d%04.1f",calculate_thread->DT[i].hour,calculate_thread->DT[i].minute,seconds );//hhmmss
		sprintf ( s_3,"  %10.7f",calculate_thread->AZ[i] );
		sprintf ( s_4,"  %10.7f",calculate_thread->ALT[i] );
		sprintf ( s_5,"  %10.7f",calculate_thread->HA[i] );
		sprintf ( s_6,"  %10.7f",calculate_thread->DEC[i] );
		sprintf ( s_7,"  %10.7f",calculate_thread->FR[i] );
		sprintf ( s_0,"%s%s%s%s%s%s%s\n",s_1,s_2,s_3,s_4,s_7,s_5,s_6 );

		out<<s_0;
	}

	file.close();
	return true;
}
